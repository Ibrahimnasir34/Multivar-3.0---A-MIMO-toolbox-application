function varargout = cnplot(SYS)
% CNPLOT  Plots the condition number of a MIMO system with respect to frequency.
%
% SYNTAX
% cnplot(SYS)
% (a)   cnplot(SYS) plots condition number versus frequency for a MIMO system model.
%        
% (b)   [CN, W] = cnplot(SYS) returns the vector of condition number 
%       values, CN and vector of frequency values, W  that would have been
%       plotted for the  condition number versus frequency plot of the 
%       MIMO model.
% See also SIGMA

% *************************************************************************
% Author:           Crystal Blackwell 
% Email:            Crystal.Blackwell@sta.uwi.edu
% Created:          January 2013; 
% Last revision:    29-June-2013;
% Useful websites:
%
% MATLAB VERSIONS USED IN PROGRAMMING PROCESS: 
% - MATLAB R2013a
%
% *************************************************************************
% NATIVE MATLAB FUNCTIONS USED TO CREATE THIS FUNCTION:
% sigma             size                max                 min
% plot              set                 gca                 xlabel
% ylabel            title
% *************************************************************************

    % Check number of outputs
    if nargout ==0 || nargout == 2
        
        % Check number of inputs
        if nargin == 1
            
            % Check if system input is valid
            modnum = modtyptest(SYS);
            if modnum == 0 
                % Display error message if system input is invalid
                error('Multivar 1.0: Incompatible / Invalid system input.')
            else
                % Obtain vector of singular values and frequency values
                [SV, W] = sigma(SYS);
                % Preallocate CN vector
                CN = ones(size(W));
                for a = 1: length(W)                    
                    % Determine condition number for each frequency value.
                    CN(a)= mag2db(max(SV(:,a))/ min(SV(:,a)));
                end


                switch nargout
                    case 0 % if no output argument, generate plot
                        % Create vector of the threshold value
                        CNf = mag2db(10) * ones(size(CN));
                        
                        % Plot the condition number (blue) and threshold
                        % value (red) versus frequency
                        plot(W, CN, 'b', W, CNf, 'r');
                        legend('Condition Number in dB','Threshold (CN = 20 dB)') 
                        set(gca, 'XScale','log','FontName','Helvetica','FontSize',8, 'XColor', [0.4 0.4 0.4], 'YColor', [0.4 0.4 0.4]);     
                        xlabel('Frequency (rads/s)', 'Color', [0 0 0])
                        ylabel('Condition Number (dB)', 'Color', [0 0 0])
                        title('Plot of Condition Number versus frequency')                    
                    case 2 % if there are two output argument assign values to vectors
                        varargout{1} = CN;
                        varargout{2} = W;
                    otherwise
                end
            end
        else
            % Display error if incorrect number of inputs
            narginchk(1,1)
        end
    else
        error('Incorrect number of output arguments.')
    end 
end









