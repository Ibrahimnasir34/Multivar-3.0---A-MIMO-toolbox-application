function d = coefpol(A)
% COEFPOL  generates the Coefficients of characteristic equation.
% 
% SYNTAX
% d = COEFPOL(A) returns the Coefficients of characteristic equation in a 
% vector d.

% *************************************************************************
% Author:           Crystal Blackwell 
% Email:            Crystal.Blackwell@sta.uwi.edu
% Created:          January 2013; 
% Last revision:    29-June-2013;
% Useful websites:
%
% MATLAB VERSIONS USED IN PROGRAMMING PROCESS: 
% - MATLAB R2013a
%
% *************************************************************************
% NATIVE MATLAB FUNCTIONS USED TO CREATE THIS FUNCTION:
% eig                       zeros                        size             
% *************************************************************************

    % Check if square
    [m,n] = size(A);
    if m == n
        % Vector of the eigenvalues of matrix A.
        z = eig(A);
        % Preallocation of vector
        c = zeros(n+1,1); 

        c(1) = 1;
        for j = 1:n
            c(2:j+1) = c(2:j+1)-z(j)*c(1:j);
        end
        
        d = zeros(1, n+1);
        % n + 2 is the sum of the pairs of elements in the c and d sequence
        for k = 1: n + 1
            d(n + 2 - k) = c(k);
        end
    else
        error('Matrix must be square.');
    end
end