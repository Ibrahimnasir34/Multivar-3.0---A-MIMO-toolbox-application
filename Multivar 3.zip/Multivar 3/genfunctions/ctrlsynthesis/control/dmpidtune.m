function C = dmpidtune(G, type, U, V)
GV = G * V;
[m, p] = size(GV);
if m <p
    a = m;
else
    a = p;
end

C = tf(zeros(a));
Do = U';

for k = 1: 1: a
    ioGV  = GV(k, k);
    ioC = pidtune(ioGV,type); 
    C(k, k) = ioC /Do(k,k);
end



