function varargout = vcn(S)
% VCN  varies the number of elements used from the diagonal of a diagonal 
% matrix that used to generate the condition number. The minimum condition 
% number that can be produced for each possible size of the subset of the 
% diagonal elements in the diagonal matrix. May be used to find the effect 
% of reducing the number of control loops in a MIMO on the condition number. 
% By varying number of loops in the MIMO system that may be controlled at 
% the same time. 
%
% SYNTAX
% (a)   vcn(S) plots a horizontal bar graph of the information.
%        
% (b)   [CN, NL] = vcn(S) returns the vector cn of condition numbers and 
%       vector nl which contains the number of loops corresponding to each 
%       element of cn.
%
%
% FUNCTION INPUT ARGUMENTS
% S  - diagonal matrix with real elements. The singular values on the
% diagonal are non-negative and sorted according to magnitude with the
% largest value in the top left of the matrix.

% FUNCTION OUTPUT ARGUMENTS
% CN  - vector containing the condition numbers corresponding to output
% vector NL.
% NL  - vector containing the number of loops in thep process that are 
% controlled.

% *************************************************************************
% Author:           Crystal Blackwell 
% Email:            Crystal.Blackwell@sta.uwi.edu
% Created:          January 2013; 
% Last revision:    29-June-2013;
% Useful websites:
%
% MATLAB VERSIONS USED IN PROGRAMMING PROCESS: 
% - MATLAB R2013a
%
% *************************************************************************
% NATIVE MATLAB FUNCTIONS USED TO CREATE THIS FUNCTION:
% nargout           diag                size                min
% min               barh                gca                 xlabel
% ylabel            title               error                        
% *************************************************************************

    % if there are the correct number of arguments...
    if nargout ==0 || nargout == 2
        if nargin == 1
            v = diag(S);
            [m, r] = size(v);
            x = 0;
            y = 0;

            % for each number of loops controlled
            for n = m : -1 : 2
                % determining the possible condition numbers for the particular 
                % number of loops being controlled
                for b = n : 1 : m
                    a = b - n + 1;
                    x = x + 1;
                    calc(x) = v(a) / v(b);
                end
                % extracting the smallest condition number for the particular 
                % number of loops and storing the information in an output vector.
                y = y + 1;
                CN(y) = min(calc);
                NL(y) = n;
            end   

            switch nargout
                case 0
                    barh(NL, CN)
                    set(gca,'FontName','Helvetica','FontSize',8, 'XColor', [0.4 0.4 0.4], 'YColor', [0.4 0.4 0.4]);     
                    ylabel('Number of control loops', 'Color', [0 0 0])
                    xlabel('Condition Number', 'Color', [0 0 0])
                    title('Plot of Condition Number versus the number of controlled loops')
                case 2
                    varargout{1} = CN;
                    varargout{2} = NL;
                otherwise
            end
        else
            narginchk(1,1)
        end
    else
        error('Incorrect number of output arguments')
    end   
end

