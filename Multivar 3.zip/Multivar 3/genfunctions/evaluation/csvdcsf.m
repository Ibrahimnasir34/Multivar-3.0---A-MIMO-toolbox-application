function [Ti, Si, To, So] = csvdcsf(Do, C, Di, G)
    Fp = Di * C * Do;
    
    Ti = Fp*G / (eye(size(Fp*G)) + Fp*G);
    Si = inv(eye(size(Fp*G)) + Fp*G);
    To = G*Fp / (eye(size(G*Fp)) + G*Fp);               
    So = inv(eye(size(G*Fp)) + G*Fp);
end