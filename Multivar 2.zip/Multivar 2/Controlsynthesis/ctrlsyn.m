function varargout = ctrlsyn(varargin)
% CTRLSYN MATLAB code for ctrlsyn.fig
%      CTRLSYN, by itself, creates a new CTRLSYN or raises the existing
%      singleton*.
%
%      H = CTRLSYN returns the handle to a new CTRLSYN or the handle to
%      the existing singleton*.
%
%      CTRLSYN('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in CTRLSYN.M with the given input arguments.
%
%      CTRLSYN('Property','Value',...) creates a new CTRLSYN or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before ctrlsyn_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to ctrlsyn_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help ctrlsyn

% Last Modified by GUIDE v2.5 29-Nov-2013 12:23:10

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @ctrlsyn_OpeningFcn, ...
                   'gui_OutputFcn',  @ctrlsyn_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before ctrlsyn is made visible.
function ctrlsyn_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to ctrlsyn (see VARARGIN)

% Choose default command line output for ctrlsyn
handles.output = hObject;

% Get root application data
mstruct = getappdata(0, 'mlvappdata');

% Set position and size and title
set(handles.output, 'OuterPosition',mstruct.windowposition, 'Name', mstruct.gtitle);

% Set handle of previous page as gui/figure application data
setappdata(handles.output,'hprevpage',mstruct.phandlerecord(length(mstruct.phandlerecord)));

% Update the page handle record in the structure and then save structure as root application data
mstruct.phandlerecord = [mstruct.phandlerecord, handles.output];
setappdata(0, 'mlvappdata', mstruct)

% set struct from root application data as gui/figure application data
setappdata(handles.output, 'gstruct', mstruct);

% Set Defaults
% Determine number of inputs and outputs
[m,n] = size(mstruct.systemmodel);

% Create two input and output sets
outptset = 1 : 1 : m;
inptset = 1 : 1 : n;

% Let number of loops be the smaller between no of inputs and outputs
% set table defaults
if n <= m % no of inputs is less than or equal to no of outputs
    ptab = cell(n,2); % create empty cell array
    % set 1 to 1 pairing as default with no of pairs equal to no of inputs
    coldata = arrayfun(@num2str, inptset,'UniformOutput', 0);
    ptab(:,1) = coldata;
    ptab(:,2) = coldata;
    outopt = arrayfun(@num2str, outptset,'UniformOutput', 0);
    columnformat = {'char', outopt}; % create options for output popups in table
else % no of inputs is greater than no of outputs
    ptab = cell(m,2); % create empty cell array
    coldata = arrayfun(@num2str, outptset,'UniformOutput', 0);
    % set 1 to 1 pairing as default with no of pairs equal to no of outputs
    ptab(:,1) = coldata;
    ptab(:,2) = coldata;
    inopt = arrayfun(@num2str, inptset,'UniformOutput', 0);
    columnformat = {inopt, 'char'}; % create options for input popups in table
end

columnname = {'Input', 'Output'};
set(handles.t_iopairing, 'Data',ptab,'ColumnName', columnname,...
            'ColumnFormat', columnformat,'ColumnEditable', true,...
            'RowName',[]);


% set values of popup menus
set(handles.decoppop,'String', {'State Feedback Decoupling','SVD Decoupling'}, 'Value', 1 )
set(handles.ctrlpop,'String', {'Output Feedback Control (PID)', 'State Feedback Control (Pole Placement)'}, 'Value', 1)

% disable decoupling options
set(handles.dcheck,'Value',0)
set(handles.decoppop, 'Enable', 'off')
set(handles.detext, 'Enable', 'off')


% disable control options
set(handles.ccheck,'Value',0)
set(handles.ctrlpop, 'Enable', 'off')
set(handles.cetext, 'Enable', 'off')

% disable NEXT butt
set(handles.nextbutt, 'Enable', 'off')
    
% Update handles structure
guidata(hObject, handles);

% UIWAIT makes ctrlsyn wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = ctrlsyn_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in go_back.
function go_back_Callback(hObject, eventdata, handles)
% hObject    handle to go_back (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get structure from gui/figure application data
mstruct = getappdata(handles.output,'gstruct');

% Update/modify structure
% Get rid of the handle of the current figure
mstruct.phandlerecord = mstruct.phandlerecord(1: length(mstruct.phandlerecord) - 1);

% Get position of the current GUI window 
mstruct.windowposition = get(gcf,'OuterPosition');

% Update root application data
setappdata(0, 'mlvappdata', mstruct);

% Get handle of previous page from figure appdata
% Activate previous gui window and delete the handle of the current window
set(getappdata(handles.output,'hprevpage'), 'OuterPosition',mstruct.windowposition,'Visible', 'On');
set(handles.output, 'Visible', 'Off');
delete(handles.output)


% --- Executes when user attempts to close figure1.
function figure1_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: delete(hObject) closes the figure

% display a question dialog box 
selection = questdlg('Are you sure you want to close Multivar?','Close Request Function','Yes','No','Yes'); 

switch selection, 
    case 'Yes'     
        % delete all figures related to multivar
          mstruct = getappdata(handles.output,'gstruct');  
          delete(mstruct.phandlerecord) 
          exit_multivar
    case 'No'
       % Do nothing
end


% --- Executes on selection change in decoppop.
function decoppop_Callback(hObject, eventdata, handles)
% hObject    handle to decoppop (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns decoppop contents as cell array
%        contents{get(hObject,'Value')} returns selected item from decoppop

% Get figure/gui application data
mstruct = getappdata(handles.output, 'gstruct');

if hasdelay(mstruct.systemmodel) == 1 % time delays present
    if get(handles.decoppop, 'Value') == 1 || get(handles.ctrlpop, 'Value') == 2
        set(handles.nextbutt, 'Enable', 'off')
        % Show emessage
        emessage = 'MULTIVAR: ';
        emessage = [emessage, 'In order to use state feedback decoupling (with or without full order estimator), the system model must not contain time delays. '];
        set(handles.msgbox, 'String', emessage)
    else
        set(handles.nextbutt, 'Enable', 'on') 
        set(handles.msgbox, 'String', '')
    end
else
    set(handles.nextbutt, 'Enable', 'on')
    set(handles.msgbox, 'String', '')
end 

% Update handles structure
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function decoppop_CreateFcn(hObject, eventdata, handles)
% hObject    handle to decoppop (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in ctrlpop.
function ctrlpop_Callback(hObject, eventdata, handles)
% hObject    handle to ctrlpop (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns ctrlpop contents as cell array
%        contents{get(hObject,'Value')} returns selected item from ctrlpop

% Get figure/gui application data
mstruct = getappdata(handles.output, 'gstruct');

if hasdelay(mstruct.systemmodel) == 1 % time delays present
    if get(handles.decoppop, 'Value') == 1 || get(handles.ctrlpop, 'Value') == 2
        set(handles.nextbutt, 'Enable', 'off')
        % Show emessage
        emessage = 'MULTIVAR: ';
        emessage = [emessage, 'In order to use state feedback decoupling (with or without full order estimator), the system model must not contain time delays. '];
        set(handles.msgbox, 'String', emessage)
    else
        set(handles.nextbutt, 'Enable', 'on') 
        set(handles.msgbox, 'String', '')
    end
else
    set(handles.nextbutt, 'Enable', 'on')
    set(handles.msgbox, 'String', '')
end 
              
% Update handles structure
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function ctrlpop_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ctrlpop (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in nextbutt.
function nextbutt_Callback(hObject, eventdata, handles)
% hObject    handle to nextbutt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Change data from string to matrix
tabdata = get(handles.t_iopairing, 'Data');
tpairing = cell2mat(cellfun(@str2num, tabdata,'UniformOutput', 0));

% Check for repeated values in the inputs
if length(unique(tpairing(:,1))) < length(tpairing(:,1))
    inpchk = 0;
else
    inpchk = 1;
end

% Check for repeated values in the outputs
if length(unique(tpairing(:,2))) < length(tpairing(:,2))
    outpchk = 0;
else
    outpchk = 1;
end 

% If there are no repeated values if the columns of the table,  proceed
% else error message
if  inpchk == 1 && outpchk == 1
    % Clear message box
    set(handles.msgbox, 'String', '')
        
    % Get figure/gui application data
    mstruct = getappdata(handles.output, 'gstruct');
    mstruct.iopairing = tpairing;
    
    % Rearrange inputs and outputs for both models according to the pairing table
    % rearrage original model
    mstruct.arrsysmodel = sysarrange(mstruct.systemmodel,tpairing);
    mstruct.controlmodel = mstruct.arrsysmodel;
    if isempty(mstruct.approxmodel) == 1
        % empty because pade approximation was skipped
        % do nothing
    else
        % rearrage approximate model
        mstruct.arrapproxmodel = sysarrange(mstruct.approxmodel,tpairing);
    end

    % Update window position in structure
    mstruct.windowposition = get(gcf,'OuterPosition');

    % if decoupling is enabled, determine the decoupling method
    if get(handles.dcheck,'Value')== 1
        dmethod = get(handles.decoppop, 'Value');
    else
        dmethod = 'None';
    end
    
    % if control is enabled, determine the control method
    if get(handles.ccheck,'Value')== 1
        cmethod = get(handles.ctrlpop, 'Value');
    else
        cmethod = 'None';
    end
    
    
    if hasdelay(mstruct.arrsysmodel) == 1 % time delays present
        exectrl = 1;
        % Clear message box
        set(handles.msgbox, 'String', '')
        emessage = 'MULTIVAR: ';
        if dmethod == 1   % State feedback decoupling
            exectrl = 0;
            % Show emessage and disable next button
            emessage = [emessage, 'In order to use state feedback decoupling (with or without full order estimator), the system model must not contain time delays. '];
            set(handles.msgbox, 'String', emessage)
            set(handles.nextbutt, 'Enable', 'off')
        end
            
        if cmethod == 2 % State Feedback Control
            exectrl = 0;
            % Show emessage and diable next button
            emessage = [emessage, 'In order to use state feedback control (with or without full order estimator), the system model must not contain time delays.'];
            set(handles.msgbox, 'String', emessage)
            set(handles.nextbutt, 'Enable', 'off')
        end        
    else % no time delays
        exectrl = 1;
        % Clear message box and enable next button
        set(handles.msgbox, 'String', '')
        set(handles.nextbutt, 'Enable', 'on')

    end
            
    
    % set control synthesis sequence
    mstruct.controlsyn = {dmethod, cmethod};

    % Update root application data
    setappdata(0, 'mlvappdata', mstruct);

    % Activate new GUI window and close the last window
    % if decoupling is enabled, go to appropriate page
    if get(handles.dcheck,'Value')== 1
        switch dmethod
            case 1
                if exectrl == 1
                    % clear message box
                    set(handles.msgbox, 'String', '')                    
                    % To State Feedback Decoupling GUI page
                    set(sfbdec, 'Visible', 'On');
                    set(handles.output, 'Visible', 'Off');
                end

            case 2
                if exectrl == 1
                    % clear message box
                    set(handles.msgbox, 'String', '')  
                    % To SVD Decoupling GUI page
                    set(svddec, 'Visible', 'On');
                    set(handles.output, 'Visible', 'Off');
                end
            otherwise
        end
    else
    % if decoupling is disabled, go to appropriate page
        switch cmethod
            case 1
                if exectrl == 1                
                    % clear message box
                    set(handles.msgbox, 'String', '')
                    % To PID Control GUI page
                    set(pidcon, 'Visible', 'On');
                    set(handles.output, 'Visible', 'Off');
                end
            case 2
                if exectrl == 1
                    % clear message box
                    set(handles.msgbox, 'String', '')                    
                    % To State Feedback Control GUI page
                    set(sfbctrl, 'Visible', 'On');
                    set(handles.output, 'Visible', 'Off');
                end
            otherwise
        end
    end   
 
else
    % Error Message
    set(handles.msgbox, 'String', 'MULTIVAR: Input and output mapping must be 1-to-1.')
end

% Update handles structure
guidata(hObject, handles);


% --- Executes on button press in dcheck.
function dcheck_Callback(hObject, eventdata, handles)
% hObject    handle to dcheck (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of dcheck
% Get figure/gui application data
mstruct = getappdata(handles.output, 'gstruct');
if get(handles.dcheck, 'Value') == 1
    set(handles.decoppop, 'Enable', 'on')
    set(handles.detext, 'Enable', 'on') 
    set(handles.msgbox, 'String', '')
else
    set(handles.decoppop, 'Enable', 'off')
    set(handles.detext, 'Enable', 'off')
end

if hasdelay(mstruct.systemmodel) == 1 % time delays present
    if get(handles.decoppop, 'Value') == 1 || get(handles.ctrlpop, 'Value') == 2
        set(handles.nextbutt, 'Enable', 'off')
        % Show emessage
        emessage = 'MULTIVAR: ';
        emessage = [emessage, 'In order to use state feedback decoupling (with or without full order estimator), the system model must not contain time delays. '];
        set(handles.msgbox, 'String', emessage)
    else
        set(handles.nextbutt, 'Enable', 'on') 
        set(handles.msgbox, 'String', '')
    end
else
    set(handles.nextbutt, 'Enable', 'on')
    set(handles.msgbox, 'String', '')
end 
              
% Update handles structure
guidata(hObject, handles);

function msgbox_Callback(hObject, eventdata, handles)
% hObject    handle to msgbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of msgbox as text
%        str2double(get(hObject,'String')) returns contents of msgbox as a double


% --- Executes during object creation, after setting all properties.
function msgbox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to msgbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in liopbutt.
function liopbutt_Callback(hObject, eventdata, handles)
% hObject    handle to liopbutt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% clear message box
set(handles.msgbox, 'String', '')

% Import input output pairing recommendation
mstruct2 = getappdata(0, 'mlvanaldata');

if isempty(mstruct2.iopairing) == 1
    % Error Message
    set(handles.msgbox, 'String', ['MULTIVAR: No saved pairing ',...
    'recommendation. You may save a IO pairing recommendation from the ',...
    'IO pairing section on the Analysis mainpage, or you may manually create ',...
    'your own pairing using the table above.'])
else
    % Clear message box
    set(handles.msgbox, 'String', '')

    iopdata = mstruct2.iopairing;
    ptab = arrayfun(@num2str, iopdata,'UniformOutput', 0);

    % Display in table
    set(handles.t_iopairing, 'Data',ptab)
end
% Update handles structure
guidata(hObject, handles);


% --- Executes on button press in ccheck.
function ccheck_Callback(hObject, eventdata, handles)
% hObject    handle to ccheck (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of ccheck

% Get figure/gui application data
mstruct = getappdata(handles.output, 'gstruct');

if get(handles.ccheck, 'Value') == 1
    set(handles.ctrlpop, 'Enable', 'on')
    set(handles.cetext, 'Enable', 'on') 
    set(handles.msgbox, 'String', '')
else
    set(handles.ctrlpop, 'Enable', 'off')
    set(handles.cetext, 'Enable', 'off')
end

if hasdelay(mstruct.systemmodel) == 1 % time delays present
    if get(handles.decoppop, 'Value') == 1 || get(handles.ctrlpop, 'Value') == 2
        set(handles.nextbutt, 'Enable', 'off')
        % Show emessage
        emessage = 'MULTIVAR: ';
        emessage = [emessage, 'In order to use state feedback decoupling (with or without full order estimator), the system model must not contain time delays. '];
        set(handles.msgbox, 'String', emessage)
    else
        set(handles.nextbutt, 'Enable', 'on') 
        set(handles.msgbox, 'String', '')
    end
else
    set(handles.nextbutt, 'Enable', 'on')
    set(handles.msgbox, 'String', '')
end 
            
% Update handles structure
guidata(hObject, handles);
