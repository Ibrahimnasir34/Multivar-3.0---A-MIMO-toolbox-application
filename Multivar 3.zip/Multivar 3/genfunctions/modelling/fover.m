function fover(prj) 
    upath = userpath;
    upath = upath(1:length(upath) -1);
    switch prj
        case 'ft'
            [FileName,PathName] = uigetfile('*.mat','Select the .mat file', [upath, '\Multivar 1.0\Projectfolders\Functional Testing']);
            PathName2 = [upath, '\Mimotools\Mimotools\'];
            PathName3 = [upath,'\Mimotool\model\ftesting\'];
        case 'cs'
            [FileName,PathName] = uigetfile('*.mat','Select the .mat file', [upath, '\Multivar 1.0\Projectfolders\Case Studies']);
            PathName2 = [upath,'\Mimotools\Mimotools\'];
            PathName3 = [upath,'\Mimotool\model\cstudies\'];
        otherwise
    end
    
    slfmpath = [PathName, FileName];
    G = importdata(slfmpath);         
    slfmpath2 = [PathName2, FileName];
    slfmpath3 = [PathName3, FileName];
    slfmpath4 = [PathName3, FileName(1: length(FileName)- 4),'m.mat'];
            
    switch class(G)
        case 'ss'
            A = G.a;
            B = G.b;
            C = G.c;
            D = G.d;
            InN = G.InputName;
            OtN = G.OutputName;
            StN = G.StateName;

            save(slfmpath2, 'A', 'B', 'C', 'D', 'InN', 'OtN', 'StN', '-v7.3')
            save(slfmpath3, 'A', 'B', 'C', 'D', 'InN', 'OtN', 'StN', '-v7.3')
            display([FileName, ' converted for R2010 for MMT and MIMOtool use'])
            
        case 'tf'
            N = G.num;
            De = G.den;
            T = G.ioDelay; 
            InN = G.InputName;
            OtN = G.OutputName;
            
            H = ss(G);
            A = H.a;
            B = H.b;
            C = H.c;
            D = H.d;            
                       
            if hasdelay(G) == 1
                save(slfmpath2, 'N', 'De', 'T', 'InN', 'OtN','-v7.3')
                save(slfmpath3, 'A', 'B', 'C', 'D', 'T', 'InN', 'OtN','-v7.3')
                
                M = ss(G, 'minimal');
                A = M.a;
                B = M.b;
                C = M.c;
                D = M.d;
                save(slfmpath4, 'A', 'B', 'C', 'D', 'T', 'InN', 'OtN','-v7.3')
            else
                save(slfmpath2, 'N', 'De', 'InN', 'OtN','-v7.3')
                save(slfmpath3, 'A', 'B', 'C', 'D', 'InN', 'OtN','-v7.3')
                
                M = ss(G, 'minimal');
                A = M.a;
                B = M.b;
                C = M.c;
                D = M.d;                
                save(slfmpath4, 'A', 'B', 'C', 'D', 'InN', 'OtN','-v7.3')
            end
            display([FileName, ' converted for R2010 for MMT and MIMOtool use'])
            
        case 'zpk'
            Z = G.z;
            P = G.p;
            K = G.k;
            T = G.ioDelay;
            InN = G.InputName;
            OtN = G.OutputName;
            
            H = ss(G);
            A = H.a;
            B = H.b;
            C = H.c;
            D = H.d;           

            if hasdelay(G) == 1
                save(slfmpath2, 'Z', 'P', 'K', 'T', 'InN', 'OtN','-v7.3')
                save(slfmpath3, 'A', 'B', 'C', 'D', 'T', 'InN', 'OtN','-v7.3')
                
                M = ss(G, 'minimal');
                A = M.a;
                B = M.b;
                C = M.c;
                D = M.d;                
                save(slfmpath4, 'A', 'B', 'C', 'D', 'T', 'InN', 'OtN','-v7.3')
            else
                save(slfmpath2, 'Z', 'P', 'K', 'InN', 'OtN','-v7.3')
                save(slfmpath3, 'A', 'B', 'C', 'D', 'InN', 'OtN','-v7.3')
                
                M = ss(G, 'minimal');
                A = M.a;
                B = M.b;
                C = M.c;
                D = M.d;                
                save(slfmpath4, 'A', 'B', 'C', 'D', 'InN', 'OtN','-v7.3')
            end            
            display([FileName, ' converted for R2010 for MMT and MIMOtool use'])
            
        otherwise
            display([FileName, ' is not a valid input.'])
    end
end