function [ISE,OISE,IAE,OIAE,ITAE,OITAE,ITSE,OITSE] = pfindices(sys)   
% PFINDICES  Calculates performance index matrices and the overall performance 
% indices for the system SYS. (i.e. ISE,OISE,IAE,OIAE,ITAE,OITAE,ITSE,OITSE).
%
% SYNTAX
% [ISE,OISE,IAE,OIAE,ITAE,OITAE,ITSE,OITSE] = pfindices(SYS)   
% (a)   [ISE,OISE,IAE,OIAE,ITAE,OITAE,ITSE,OITSE] = pfindices(SYS) outputs
%       the ISE, the overall ISE index (OISE), the IAE, the overall IAE index
%       (OIAE), the ITSE, the overall ITSE index (OITSE) and the the ITAE, the 
%       overall ITAE index (OITAE) for the system SYS.       
% 

% *************************************************************************
% Author:           Crystal Blackwell 
% Email:            Crystal.Blackwell@sta.uwi.edu
% Created:          January 2013; 
% Last revision:    29-June-2013;
% Useful websites:
%
% MATLAB VERSIONS USED IN PROGRAMMING PROCESS: 
% - MATLAB R2013a
%
% *************************************************************************
% NATIVE MATLAB FUNCTIONS USED TO CREATE THIS FUNCTION:
% % error                        
% *************************************************************************

    % Check if sys is a model
    switch class(sys)
        case 'tf'
            chk1  = 1;
        case 'ss'
            chk1  = 1;
        case 'zpk'
            chk1  = 1;
        otherwise
            chk1  = 0;
    end

    if chk1 == 0 
           error('Multivar: Model must be tf, ss or zpk.')
    else
        [ISE, OISE] = pfindex(sys,'ISE');   
        [IAE, OIAE] = pfindex(sys,'IAE');   
        [ITAE, OITAE] = pfindex(sys,'ITAE');  
        [ITSE, OITSE] = pfindex(sys,'ITSE');   
    end
end