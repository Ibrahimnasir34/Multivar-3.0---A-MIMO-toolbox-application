function [PImat, PI] = pfindex(sys,PIsel) 
% PFINDEX  Calculates the designated overall performance index PI and the 
% performance index matrix PImat for the system SYS. ISE, IAE, ITSE, ITAE
% performance indexes can be chosen.
%
% SYNTAX
% [PImat, PI] = pfindex(SYS,PIsel)
% (a)   [PImat, PI] = pfindex(SYS,'ISE') the overall ISE index, PI and the 
%       ISE index matrix, PImat for the system SYS,
%        
% (b)   [PImat, PI] = pfindex(SYS,'IAE') the overall IAE index, PI and the 
%       IAE index matrix, PImat for the system SYS,
%  
% (c)   [PImat, PI] = pfindex(SYS,'ITSE') the overall ITSE index, PI and 
%       the ITSE index matrix, PImat for the system SYS,
% 
% (d)   [PImat, PI] = pfindex(SYS,'ITAE') the overall ITAE index, PI and  
%       the ITAE index matrix, PImat for the system SYS,
% 

% *************************************************************************
% Author:           Crystal Blackwell 
% Email:            Crystal.Blackwell@sta.uwi.edu
% Created:          January 2013; 
% Last revision:    29-June-2013;
% Useful websites:
%
% MATLAB VERSIONS USED IN PROGRAMMING PROCESS: 
% - MATLAB R2013a
%
% *************************************************************************
% NATIVE MATLAB FUNCTIONS USED TO CREATE THIS FUNCTION:
% class             size                zeros               step
% error             dcgain              sum                 
% *************************************************************************

    % Check if sys is a model
    switch class(sys)
        case 'tf'
            chk1  = 1;
        case 'ss'
            chk1  = 1;
        case 'zpk'
            chk1  = 1;
        otherwise
            chk1  = 0;
    end


    % Check if PIsel string is valid
    switch PIsel
        case 'ISE'
            chk2  = 1;
        case 'IAE'
            chk2  = 1;
        case 'ITAE'
            chk2  = 1;
        case 'ITSE'
            chk2  = 1;
        otherwise
            chk2  = 0;
    end
    
    if chk1 == 0 || chk2 == 0
       if chk1 == 0
           error('Multivar: Model must be tf, ss or zpk.')
       end
       if chk2 == 0
           error('Multivar: Please indicate an appropriate performance index.')
       end
    else
        % Determine dimensions of system
        [m,n] = size(sys);

        % Create an output matrix of the same size
        PImat = zeros(m,n);

        % Obtain sample values for step response
        [y,t] = step(sys);
      
        % Determine steady state value
        yss = dcgain(sys);

        % For each I/O response to a step input... 
        for outnum = 1:m
            for innum = 1:n              
                % determine control error                
                e = yss(outnum,innum) - y(:,outnum,innum);

                % performance calculation
                switch PIsel
                    case 'ISE'
                        PImat(outnum, innum) = trapz(t, e.^2);
                    case 'IAE'
                        PImat(outnum, innum) = trapz(t, abs(e));
                    case 'ITAE'
                        PImat(outnum, innum) = trapz(t, t.*abs(e));
                    case 'ITSE'
                        PImat(outnum, innum) = trapz(t, t.*(e.^2));
                end
            end
        end

        % Determining the overall Performance Index
        PI = sum(sum(PImat,1),2);
    end
end