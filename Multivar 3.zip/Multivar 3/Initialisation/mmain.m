function varargout = mmain(varargin)
% MMAIN MATLAB code for mmain.fig
%      MMAIN, by itself, creates a new MMAIN or raises the existing
%      singleton*.
%
%      H = MMAIN returns the handle to a new MMAIN or the handle to
%      the existing singleton*.
%
%      MMAIN('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in MMAIN.M with the given input arguments.
%
%      MMAIN('Property','Value',...) creates a new MMAIN or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before mmain_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to mmain_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help mmain

% Last Modified by GUIDE v2.5 13-Oct-2017 04:02:51

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @mmain_OpeningFcn, ...
                   'gui_OutputFcn',  @mmain_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before mmain is made visible.
function mmain_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to mmain (see VARARGIN)

% Choose default command line output for mmain
handles.output = hObject;

%Get root application data
mstruct = getappdata(0, 'mlvappdata');

% Set position and size and title
set(0, 'Units', 'normalized')
scsz = get(0, 'ScreenSize');
scaling = 0.9;
posl  = scsz(3)-scaling;
posb = scsz(4)-scaling;
set(handles.output, 'OuterPosition',[posl, posb, scaling, scaling], 'Name', mstruct.gtitle);

% Update the page handle record in the structure and then save structure as root application data
mstruct.phandlerecord = [handles.output];
setappdata(0, 'mlvappdata', mstruct)

% set struct from root application data as gui/figure application data
setappdata(handles.output, 'gstruct', mstruct);

% Start button is disabled
set(handles.mstart, 'Enable', 'off')

% Verify that the version of Matlab is greater than 7.10
minver = '7.10'; 
if verLessThan('matlab', minver)
    %Code to run under specificed MATLAB version or later here
    emessage = ['Multivar: Matlab version is not suitable for running', mstruct.mlvstring,'. This toolbox was designed to operate with Matlab versions ', minver, ' (or higher).'];
    set(handles.msgbox, 'String', emessage, 'ForegroundColor', [1 0 0])
else
    %Code to run under specified MATLAB version or later
    % Tick MATLAB checkbox
    set(handles.mattool,'Value',1);
    
    % creating strings for message box for mandatory toolboxes
    emessage1 = 'Control System Toolbox; ';
    emessage2 = 'Symbolic Math Toolbox; ';
    % cell array containing the names of each mandatory toolbox
    emvector = {emessage1,  emessage2};
    % vector of flags corressponding to emvector  
    flgvector1 = zeros(size(emvector));
    
    % creating strings for message box for optional toolboxes
    opmessage1 = 'Simulink Toolbox; ';      
    % cell array containing the names of each optional toolbox
    opmvector = {opmessage1};
    % vector of flags corressponding to opmvector   
    flgvector2 = zeros(size(opmvector));
    
   
    % Check for toolboxes  
    % Check for mandatory toolboxes (Control System, Symbolic math)
    
    % Check for Control toolbox
    if isempty(ver('control'))
    else
        set(handles.cstool,'Value',1);
        flgvector1(1) = 1;
    end
    % Check for Symbolic Math toolbox
    if isempty(ver('symbolic'))
    else
        set(handles.smtool,'Value',1);
        flgvector1(2) = 1;
    end
    
       
    % if mandatory toolboxes are present enable start button
    if flgvector1 == ones(size(flgvector1))
        % enable start button
        set(handles.mstart, 'Enable', 'on')
      
        % Check for optional toolboxes for increased functionality (Simulink, Simulink Design, Robust control)
        % Check for Simulink toolbox
        if isempty(ver('simulink'))
        else
            set(handles.smltool,'Value',1);
            flgvector2(1) = 1;
         end
    
        
        if (flgvector2 == ones(size(flgvector2)))
            % Generate full functionality error message
            emessage = 'Multivar is fully operational. Please press start to begin.';
            set(handles.msgbox, 'String', emessage, 'ForegroundColor', [0 0 1])
        else  
            % Generate limited functionality error message
            emessage = 'Multivar has limited functionality because of the absence of the following toolboxes: ';
            for a = 1: 1 : length(flgvector2) 
                if flgvector2(a) == 0
                    emessage = [emessage, opmvector(a)];                
                end
            end
            set(handles.msgbox, 'String', emessage, 'ForegroundColor', [1 0 0])   
        end
    else
        % Madatory toolboxes absent
        emessage = 'Multivar cannot function because of the absence of the following toolboxes:';
        for a = 1: 1 : length(flgvector1) 
            if flgvector1(a) == 0
                emessage = [emessage, emvector(a)];                
            end
        end
        set(handles.msgbox, 'String', emessage,'ForegroundColor', [1 0 0])
    end     
end

        
% Update handles structure
guidata(hObject, handles);

% UIWAIT makes mmain wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = mmain_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;

% --- Executes on button press in mattool.
function mattool_Callback(hObject, eventdata, handles)
% hObject    handle to mattool (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of mattool


% --- Executes on button press in cstool.
function cstool_Callback(hObject, eventdata, handles)
% hObject    handle to cstool (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of cstool


% --- Executes on button press in smtool.
function smtool_Callback(hObject, eventdata, handles)
% hObject    handle to smtool (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of smtool


% --- Executes on button press in smltool.
function smltool_Callback(hObject, eventdata, handles)
% hObject    handle to smltool (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of smltool


% --- Executes on button press in mstart.
function mstart_Callback(hObject, eventdata, handles)
% hObject    handle to mstart (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Display Loading message in message box
set(handles.msgbox, 'String','Loading ...')

% Get position struct from gui/figure application data.
mstruct = getappdata(handles.output, 'gstruct');

% Update window position in structure
mstruct.windowposition = get(gcf,'OuterPosition');

% Update root application data
setappdata(0, 'mlvappdata', mstruct);

% Clear message box
set(handles.msgbox, 'String','')

% Activate new GUI window and hide the last window
set(cbproject, 'Visible', 'On');
set(handles.output, 'Visible', 'Off');



% --- Executes when user attempts to close figure1.
function figure1_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: delete(hObject) closes the figure

% display a question dialog box 
selection = questdlg('Are you sure you want to close Multivar?','Close Request Function','Yes','No','Yes'); 

switch selection, 
    case 'Yes'     
        % delete all figures related to multivar
          mstruct = getappdata(handles.output,'gstruct');  
          delete(mstruct.phandlerecord) 
          exit_multivar
    case 'No'
       % Do nothing
end


function msgbox_Callback(hObject, eventdata, handles)
% hObject    handle to msgbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of msgbox as text
%        str2double(get(hObject,'String')) returns contents of msgbox as a double


% --- Executes during object creation, after setting all properties.
function msgbox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to msgbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
