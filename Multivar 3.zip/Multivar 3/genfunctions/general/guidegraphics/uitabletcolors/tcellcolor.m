function tcellcolor(thandle, indata, ocolors)
% TCELLCOLOR  uses a data matrix and a text colour matrix to set the data 
% and the colour of the text in a uitable respectively.
% 
% SYNTAX
% tcellcolor(THANDLE, INDATA, OCOLORS)sets uitable with handle THANDLE 
% with the data provided in INDATA and the colours specified by the text
% colour matrix OCOLORS. INDATA and OCOLORS must be the same size. 
% INDATA is a numeric matrix or a cell array of strings and OCOLORS must be 
% a cell array of strings. 
% See also KCSF, KCSFCOLORS, KOSF, KOSFCOLORS

% *************************************************************************
% Author:           Crystal Blackwell 
% Email:            Crystal.Blackwell@sta.uwi.edu
% Created:          January 2013; 
% Last revision:    29-June-2013;
% Useful websites:
%
% MATLAB VERSIONS USED IN PROGRAMMING PROCESS: 
% - MATLAB R2013a
%
% *************************************************************************
% NATIVE MATLAB FUNCTIONS USED TO CREATE THIS FUNCTION:
% nargin                    nargout                     error
% narginchk                 nargoutchk                  ismatrix
% size                      cell                        iscellstr
% iscell                    ishandle                    num2str 
% set
% *************************************************************************

    %check for correct number of outputs
    if nargout == 0
        %check for correct number of inputs
        if nargin == 3
            % Check if thandle is a valid handle
            if ishandle(thandle) == 1
                % Check if indata is a matrix
                if ismatrix(indata)== 1 || iscellstr(indata)== 1 
                    % Check if ocolors is a cell array of strings
                    if iscellstr(ocolors) == 1
                        % Check that indata and ocolors are the same size
                        numi = size(indata);
                        numc = size(ocolors);                        
                        if numi == numc
                            % Preallocate cell array
                            celldata = cell(numi);
                            for m = 1: numi(1)
                                for n = 1:numi(2)
                                    % Format data and colour for each cell
                                    % of html table celldata
                                    if iscell(indata)== 1 
                                        celldata{m,n} = colText(indata{m,n}, ocolors{m,n});
                                    else
                                        celldata{m,n} = colText(indata(m,n), ocolors{m,n});
                                    end
                                end
                            end
                            % Set html table as data for designated uitable                            
                            set(thandle, 'Data', celldata);
                        else
                            error('Multivar 1.0: Dimensions of input arguments indata and ocolors must match.')
                        end
                    else
                    	error('Multivar 1.0: Input argument ocolors must be a cell array of strings.')
                    end
                else
                    error('Multivar 1.0: Input argument indata must be a numeric matrix or a cell array of strings.')
                end                        
            else
                error('Multivar 1.0: thandle argument must be a valid handle and object must be a uitable.')
            end
        else
            % Display error if incorrect number of inputs
            narginchk(3,3)
        end
    else
        % Display error if incorrect number of outputs
        nargoutchk(0,0)
    end
end

function outHtml = colText(inText, inColor)
    if isnumeric(inText) == 1
        inText = num2str(inText);  
    end   
    % return a HTML string with colored font
    outHtml = ['<html><font color="',inColor,'">', inText,'</font></html>'];
end

