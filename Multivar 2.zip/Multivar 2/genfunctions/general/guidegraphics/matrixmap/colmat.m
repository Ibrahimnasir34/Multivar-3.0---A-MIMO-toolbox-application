function colmat(rsize, csize, rpos, cpos)
% COLMAT  draws a matrix map showing the position of the indicated element in the matrix.
% 
% SYNTAX
% colmat(rsize, csize, rpos, cpos)draws a matrix map of dimension rsize by
% csize and shows the position of the element located at (rpos, cpos) in
% the matrix. All input arguments must be positive whole numbers. 
% See also IMAGESC

% *************************************************************************
% Author:           Crystal Blackwell 
% Email:            Crystal.Blackwell@sta.uwi.edu
% Created:          January 2013; 
% Last revision:    29-June-2013;
% Useful websites:
%
% MATLAB VERSIONS USED IN PROGRAMMING PROCESS: 
% - MATLAB R2013a
%
% *************************************************************************
% NATIVE MATLAB FUNCTIONS USED TO CREATE THIS FUNCTION:
% nargin                    nargout                     error
% narginchk                 nargoutchk                  isscalar
% size                      imagesc                     zeros
% colormap                  gca                         
% *************************************************************************
% MULTIVAR FUNCTIONS USED TO CREATE THIS FUNCTION:
% isposwnum
% *************************************************************************

    % Check for correct number of output arguments
    if nargout == 0
        
        % Check that there are four arguments
        if nargin == 4
            
            % Check that all inputs are numeric
            if isscalar(rsize) == 1 && isscalar(csize) == 1 && isscalar(rpos) == 1 && isscalar(cpos) == 1 
                
                % Check that all input arguments are positive integers
                minput = [rsize, csize, rpos, cpos];
                if isposwnum(minput)== ones(size(minput))

                    % Check that rsize is greater than or equal to rpos
                    if rsize >= rpos

                        % Check that csize is greater than or equal to cpos
                        if csize >= cpos

                            % Create matrix and indicate current position in matrix
                            A = zeros(rsize, csize);
                            A(rpos, cpos) = 1;
                            
                            % Create coloured matrix
                            imagesc(A);
                            colormap(summer(2));
                            set(gca,'XTick', 0.5 :1: csize + 0.5,'YTick', 0.5:1:rsize + 0.5, 'TickLength',[0 0], 'XAxisLocation', 'bottom','YAxisLocation', 'right', 'GridLineStyle', '-')
                            grid on
                            blanx = {''};
                            set(gca,'XTickLabel', blanx,'YTickLabel', blanx)

                        else
                            error('Input variable csize must be greater than or equal to input variable cpos.')
                        end

                    else
                        error('Input variable rsize must be greater than or equal to input variable rpos.')
                    end

                else
                    error('All input arguments must be positive integers.')
                end
            else
                error('All input arguments must be scalar.')
            end            
        else
           % Display error if incorrect number of inputs
           narginchk(4, 4)
        end
    else
       % Display error if incorrect number of outputs
       nargoutchk(0, 0)
    end
end



