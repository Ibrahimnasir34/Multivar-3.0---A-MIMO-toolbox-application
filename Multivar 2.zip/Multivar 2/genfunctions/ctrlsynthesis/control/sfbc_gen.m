function csys = sfbc_gen(sys, K, N)
% SFBC_GEN  generates a state feedback control system for a system model 
% without time delays (tf, ss, zpk) using the state feedback gain matrix, K
% and the input gain matrix, N.
% 
% SYNTAX
% csys = sfbc_gen(sys, K, N) returns the state feedback control system 
% after inputing  state feedback gain matrix, K, the input gain matrix,
% N and the system model which must contain no delays.
% See also SFBC.

% *************************************************************************
% Author:           Crystal Blackwell 
% Email:            Crystal.Blackwell@sta.uwi.edu
% Created:          January 2013; 
% Last revision:    29-June-2013;
% Useful websites:
%
% MATLAB VERSIONS USED IN PROGRAMMING PROCESS: 
% - MATLAB R2013a
%
% *************************************************************************
% NATIVE MATLAB FUNCTIONS USED TO CREATE THIS FUNCTION:
% nargin                    nargout                     error
% narginchk                 nargoutchk                  size
% length                    ss                          isnumeric 
% *************************************************************************
% MULTIVAR FUNCTIONS USED TO CREATE THIS FUNCTION:
% modtyptest                iosnames
% *************************************************************************  
    
    % Check for correct number of output arguments
    if nargout == 1
        
        % Check for correct number of input arguments
        if nargin == 3

            % Check type of model
            modnum = modtyptest(sys);
            if modnum == 2 || modnum == 4 || modnum == 6
                cflag = 1; % set cflag high
                if modnum == 4  % if system is a state space model
                    % Do nothing
                else
                    sys = ss(sys); % Convert to state space
                end
            else
                cflag = 0; % set cflag low
            end
            
            % determining dimensions of original system
            [m, p] = size(sys);
            n = length(sys.a);
            
            % check if K is the right size and is numeric
            [ki, kj] = size(K);
            if ki == p && kj == n && isnumeric(K) == 1
                kflag = 1;
            else
                kflag = 0;
            end
            
            % check if N is the right size and is numeric
            [ni, nj] = size(N);
            if ni == p && nj == m && isnumeric(N) == 1
                nflag = 1;
            else
                nflag = 0;
            end
            

            if cflag == 1 && kflag == 1  && nflag == 1 % if inputs are acceptable    
                % Assign names to un-named variables
                sys = iosnames(sys);

                % Evaluating the control system
                Ahat = sys.a - (sys.b * K);
                Bhat = sys.b * N;
                Chat = sys.c - (sys.d * K);
                Dhat = sys.d * N;
                csys = ss(Ahat, Bhat, Chat, Dhat);

                % Determining variable names from original system
                inname = sys.InputName;
                outname = sys.OutputName;
                statname = sys.StateName;

                % determining dimensions of control system
                [md, rd] = size(csys);
                nd = length(csys.a);

                % determining names for control system
                inname = inname(1: rd); 
                outname = outname(1: md);
                statname = statname(1:nd);


                % Assigning variable names to control system
                % Inputs
                for g = 1: 1: length(inname)
                    inname{g} = [inname{g}, '_c'];
                end      
                csys.InputName = inname;

                % Outputs
                for h = 1: 1: length(outname)
                    outname{h} = [outname{h}];
                end  
                csys.OutputName = outname;

                % States
                for f = 1: 1: length(statname)
                	statname{f} = [statname{f}];
                end  
                csys.StateName = statname;
            else
                emessage = 'Multivar 1.0:';
                if cflag == 0
                    emessage = [emessage, 'System must be of type tf, ss, or zpk and must not contain time delays. '];
                end
                if kflag == 0
                    emessage = [emessage, 'K matrix must be of dimension r x n where r is the number of inputs and n is the number of states. '];
                end      
                if nflag == 0
                    emessage = [emessage, 'N matrix must be of dimension r x m where r is the number of inputs and n is the number of outputs. '];
                end                      
                error(emessage)
            end
            
        else
            % Display error if incorrect number of inputs
            narginchk(3, 3)
        end
        
    else
        % Display error if incorrect number of outputs
        nargoutchk(1, 1)
    end                
 
end