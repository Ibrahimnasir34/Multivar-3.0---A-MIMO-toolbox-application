function [Abar, Bbar, Cbar, Dbar, T, fb] = ccf(sys)
% CCF  generates the Controllable Canonical Form(CCF)of a supplied 
% MIMO system.
% 
% SYNTAX
% [Abar, Bbar, Cbar, Dbar, T, fb] = ccf(sys) returns the Controllable
% Canonical Form(CCF) of the MIMO system SYS and its matrices Abar, Bbar, 
% Cbar, Dbar, the Transformation matrix T and the feedback fb in the event
% that the similarity transformation could not be performed.

% *************************************************************************
% Author:           Crystal Blackwell 
% Email:            Crystal.Blackwell@sta.uwi.edu
% Created:          January 2013; 
% Last revision:    29-June-2013;
% Useful websites:
%
% MATLAB VERSIONS USED IN PROGRAMMING PROCESS: 
% - MATLAB R2013a
%
% *************************************************************************
% NATIVE MATLAB FUNCTIONS USED TO CREATE THIS FUNCTION:
% class                     ctrb                        size
% det                       inv                         ss2ss                     
% *************************************************************************

    % Check if input argument is a state-space system
    if strcmp(class(sys), 'ss') == 1
        A = sys.a;
        B = sys.b;
        C = sys.c;
        D = sys.d;
        
        Co = ctrb(sys);
        % If Co has an inverse...
        [a, b] = size(Co);
        if a ==b && det(Co) ~=0
            [M, p] = m_matrix(A);
            iT = Co * M;
            T = inv(iT);
            sysT = ss2ss(sys,T);
            Abar = sysT.a;
            Bbar = sysT.b;
            Cbar = sysT.c;
            Dbar = sysT.d;
            fb = 1;
        else
            Abar = [];
            Bbar = [];
            Cbar = [];
            Dbar = [];
            T = [];
            fb = 0;
        end
    else         
        error('Multivar 1.0: System must be in state space form.')
    end
end





