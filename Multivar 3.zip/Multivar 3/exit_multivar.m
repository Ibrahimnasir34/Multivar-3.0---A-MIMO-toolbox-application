function exit_multivar   
    % Get root application data 
    mstruct = getappdata(0, 'mlvappdata');
    
    % Check to see if multivar is open
    if isempty(mstruct) == 1
        % Display message
        disp('Multivar is NOT open.')
    else
        % Execute code depending on current mode
        switch mstruct.mlvmode
            % GUI Mode
            case 1
                % Generate the list of folders and remove them from the search
                % path
                allfolders = genpath(mstruct.mlvlocation);
                rmpath(allfolders);
                
                % Add Multivar folder once more
                addpath(mstruct.mlvlocation);
                
                % Remove root application data
                rmappdata(0,'mlvappdata') 

                % Display message
                disp('MULTIVAR GUI MODE EXITED.')

            % Function Mode    
            case 2
                % Generate the list of folders and remove them from the search
                % path
                gfpath = [mstruct.mlvlocation, '\genfunctions'];
                pffpath = [mstruct.mlvlocation, '\Projectfolders'];
                
                allfolders = genpath(gfpath);
                allfolders2 = genpath(pffpath);

                rmpath(allfolders);
                rmpath(allfolders2);

                % Add Multivar folder once more
                addpath(mstruct.mlvlocation);                
                
                % Remove root application data
                rmappdata(0,'mlvappdata') 

                % Display message                
                disp('MULTIVAR FUNCTION MODE EXITED.')
            otherwise
        end
    end
end