function varargout = padedisplay(varargin)
% PADEDISPLAY M-file for padedisplay.fig
%      PADEDISPLAY, by itself, creates a new PADEDISPLAY or raises the existing
%      singleton*.
%
%      H = PADEDISPLAY returns the handle to a new PADEDISPLAY or the handle to
%      the existing singleton*.
%
%      PADEDISPLAY('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in PADEDISPLAY.M with the given input arguments.
%
%      PADEDISPLAY('Property','Value',...) creates a new PADEDISPLAY or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before padedisplay_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to padedisplay_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help padedisplay

% Last Modified by GUIDE v2.5 11-May-2014 01:39:18

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @padedisplay_OpeningFcn, ...
                   'gui_OutputFcn',  @padedisplay_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before padedisplay is made visible.
function padedisplay_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to padedisplay (see VARARGIN)

% Choose default command line output for padedisplay
handles.output = hObject;

% Get root application data
mstruct = getappdata(0, 'mlvappdata');

% Set position and size and title
set(handles.output, 'OuterPosition',mstruct.windowposition, 'Name', mstruct.gtitle);

% Set handle of previous page as gui/figure application data
setappdata(handles.output,'hprevpage',mstruct.phandlerecord(length(mstruct.phandlerecord)));

% Update the page handle record in the structure and then save structure as root application data
mstruct.phandlerecord = [mstruct.phandlerecord, handles.output];
setappdata(0, 'mlvappdata', mstruct)

% Determine approximate models 
if get(handles.minchk, 'Value') == 1
   pade_tfsys = minreal(mstruct.approxmodel);
   pade_sssys = ss(mstruct.approxmodel, 'minimal');
else
   pade_tfsys = mstruct.approxmodel;
   pade_sssys = ss(mstruct.approxmodel);
end

% save edited structure as gui page application data
setappdata(handles.output, 'gstruct', mstruct);

% Display text
sys_text1 = evalc('pade_tfsys');
tlines1 = strsplit(sys_text1,'\n');
set(handles.tdisp1,'FontName', 'Monospaced', 'String',tlines1);

sys_text2 = evalc('pade_sssys');
tlines2 = strsplit(sys_text2,'\n');
set(handles.tdisp2,'FontName', 'Monospaced', 'String',tlines2);

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes padedisplay wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = padedisplay_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in nextbutt.
function nextbutt_Callback(hObject, eventdata, handles)
% hObject    handle to nextbutt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get struct from gui/figure application data.
mstruct = getappdata(handles.output, 'gstruct');

% Update window position in structure
mstruct.windowposition = get(gcf,'OuterPosition');

% Update root application data
setappdata(0, 'mlvappdata', mstruct);

% Activate new GUI window and close the last window
set(anal_gui, 'Visible', 'On');
set(handles.output, 'Visible', 'Off');

% Update handles structure
guidata(hObject, handles);


% --- Executes on button press in goback.
function goback_Callback(hObject, eventdata, handles)
% hObject    handle to goback (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get structure from gui/figure application data
mstruct = getappdata(handles.output,'gstruct');

% Update/modify structure
% Get rid of the handle of the current figure
mstruct.phandlerecord = mstruct.phandlerecord(1: length(mstruct.phandlerecord) - 1);

% Get position of the current GUI window 
mstruct.windowposition = get(gcf,'OuterPosition');

% Update root application data
setappdata(0, 'mlvappdata', mstruct);

% Get handle of previous page from figure appdata
% Activate previous gui window and delete the handle of the current window
set(getappdata(handles.output,'hprevpage'), 'OuterPosition',mstruct.windowposition,'Visible', 'On');
set(handles.output, 'Visible', 'Off');
delete(handles.output)


% --- Executes when user attempts to close figure1.
function figure1_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: delete(hObject) closes the figure

% display a question dialog box 
selection = questdlg('Are you sure you want to close Multivar?','Close Request Function','Yes','No','Yes'); 

switch selection, 
    case 'Yes'     
        % delete all figures related to multivar
          mstruct = getappdata(handles.output,'gstruct');  
          delete(mstruct.phandlerecord) 
          exit_multivar
    case 'No'
       % Do nothing
end


% --- Executes on button press in minchk.
function minchk_Callback(hObject, eventdata, handles)
% hObject    handle to minchk (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of minchk

% get gui/figure application data
mstruct = getappdata(handles.output, 'gstruct');

% Determine approximate models 
if get(handles.minchk, 'Value') == 1
   pade_tfsys = minreal(mstruct.approxmodel);
   pade_sssys = ss(mstruct.approxmodel, 'minimal');
else
   pade_tfsys = mstruct.approxmodel;
   pade_sssys = ss(mstruct.approxmodel);
end

% Display text
sys_text1 = evalc('pade_tfsys');
tlines1 = strsplit(sys_text1,'\n');
set(handles.tdisp1,'FontName', 'Monospaced', 'String',tlines1);

sys_text2 = evalc('pade_sssys');
tlines2 = strsplit(sys_text2,'\n');
set(handles.tdisp2,'FontName', 'Monospaced', 'String',tlines2);


% --- Executes on selection change in tdisp2.
function tdisp2_Callback(hObject, eventdata, handles)
% hObject    handle to tdisp2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns tdisp2 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from tdisp2


% --- Executes during object creation, after setting all properties.
function tdisp2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to tdisp2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in tdisp1.
function tdisp1_Callback(hObject, eventdata, handles)
% hObject    handle to tdisp1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns tdisp1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from tdisp1


% --- Executes during object creation, after setting all properties.
function tdisp1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to tdisp1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
