function cs2sim(mlvlocation, controlsyn, decopinfo,controlinfo, plantmod)         
    % TOP DOWN MDL GENERATION
    % create and open new simulink model 'mysys'
    mdlname = 'mysys';
    new_system(mdlname)
    open_system(mdlname);
        
    % create and position new subsystem 'MIMO Control System'
    blkname = [mdlname,'/MIMO Control System'];
    bsize = 150;
    mimox = 10;
    mimoy = 10;
    wmimo = bsize;
    hmimo = bsize/2;
    add_block('built-in/Subsystem', blkname, 'Position',[mimox,mimoy, mimox + wmimo, mimoy + hmimo])    
  
    % Create control portion of the model
    switch controlsyn{2}
        case 1 % PID Control     
            % pid control model
            ctname = 'pidcs_model'; 
            
        case 2 % State Feedback Control 
            
            switch length(controlinfo)
                case 4
                    % State Feedback Control model without estimator
                    ctname = 'sfbc_ne_model'; 
                case 5
                    % State Feedback Control model with estimator
                    ctname = 'sfbc_e_model'; 
            end 
            
        case 'None'
    end
    
    % if there is a control stage
    if controlsyn{2}  == 1 || controlsyn{2}  == 2
        
        % load the designated control model into memory without making its model window visible
        mdlpath = [mlvlocation,'\Controlevaluation\fsimulink\',ctname, '.slx'];
        load_system(mdlpath)

        % copy content of designated control model to subsystem 'MIMO Control system'
        Simulink.SubSystem.deleteContents(blkname)
        Simulink.BlockDiagram.copyContentsToSubSystem(ctname, blkname)

        % open subsystem 'MIMO Control System'
        open_system(blkname)  
        
        % Put in the values of the control elements
        switch controlsyn{2}
            case 1 % PID Control
                % Upload PID controller values to designated system
                cblkname1 = [blkname, '/PID Controller'];                
                estring1 = revalsys(plantmod);
                set_param(cblkname1,'sys', estring1)         
                
            case 2 % State Feedback Control
                % Insert K matrix
                K = controlinfo{1};
                estring1 = mat2str(K);
                cblkname1 = [blkname, '/K'];                                       
                set_param(cblkname1,  'Gain', estring1)
                
                % Insert N matrix
                N = controlinfo{2};
                estring2 = mat2str(N);
                cblkname2 = [blkname, '/N']; 
                set_param(cblkname2,  'Gain', estring2)
                
                % If there is an estimator, insert it
                if length(controlinfo) == 5
                    est = controlinfo{5};
                    estring3 = revalsys(est);
                    cblkname3 = [blkname, '/Full Order Observer'];                     
                    set_param(cblkname3,'sys', estring3)  
                end
        end
                            
        % Update address 
        blkname = [blkname, '/Subsystem'];
    end
            
    % Create decoupling portion of the model
    switch controlsyn{1}
        
        case 1 % State Feedback Decoupling            
            switch length(decopinfo)
                case 3
                    % State Feedback Decoupling model without estimator
                    dcname = 'sfbc_ne_model'; 
                case 4
                    % State Feedback Decoupling model without estimator
                    dcname = 'sfbc_e_model'; 
            end         
            
        case 2 % SVD Decoupling 
            
            % SVD decoupling model
            dcname = 'svdd_model';           
            
        case 'None'
    end    
    
    % if there is a decoupling stage
    if controlsyn{1}  == 1 || controlsyn{1}  == 2
        
        % load the designated decoupling model into memory without making its model window visible
        mdlpath = [mlvlocation,'\Controlevaluation\fsimulink\',dcname, '.slx'];
        load_system(mdlpath)

        % copy content of the state feedback decoupling model (no estimator) to the Subsystem  or to the MIMO Control system if there was no control stage            
        Simulink.SubSystem.deleteContents(blkname)
        Simulink.BlockDiagram.copyContentsToSubSystem(dcname, blkname)

        % open subsystem
        open_system(blkname)
        
        % Put in the values of the decoupling elements
        switch controlsyn{1}
            case 1 % State Feedback Decoupling
                % Insert F matrix
                F = decopinfo{1};
                estring1 = mat2str(F);
                cblkname1 = [blkname, '/F'];                                       
                set_param(cblkname1,  'Gain', estring1)
                
                % Insert G matrix
                G = decopinfo{2};
                estring2 = mat2str(G);
                cblkname2 = [blkname, '/G']; 
                set_param(cblkname2,  'Gain', estring2)
                
                % If there is an estimator, insert it
                if length(decopinfo) == 5
                    est = decopinfo{5};
                    estring3 = revalsys(est);
                    cblkname3 = [blkname, '/Full Order Observer'];                     
                    set_param(cblkname3,'sys', estring3)  
                end                
                
            case 2 % SVD Decoupling
                % Insert Precomp matrix
                precomp = decopinfo{1};
                estring1 = mat2str(precomp);
                cblkname1 = [blkname, '/Pre-Compensator'];                                       
                set_param(cblkname1,  'Gain', estring1)
                
                % Insert Postcomp matrix
                postcomp = decopinfo{2};
                estring2 = mat2str(postcomp);
                cblkname2 = [blkname, '/Post-Compensator']; 
                set_param(cblkname2,  'Gain', estring2)                
        end        
        
        % Update address 
        blkname = [blkname, '/Subsystem'];
    end
   
        
    % Plant model template 
    switch modtyptest(sys)
        case 1
            modname = 'ltimod_ns';
        case 2
            modname = 'ltimod_ns';               
        case 4
            modname = 'ltimod_s';                
        case 5
            modname = 'ltimod_ns';                
        case 6
            modname = 'ltimod_ns';                       
        otherwise
    end
        
    % load the designated plant model into memory without making its model window visible
    mdlpath = [mlvlocation,'\Controlevaluation\fsimulink\',modname, '.slx'];
    load_system(mdlpath)

    % copy content of plant model to subsystem 
    Simulink.SubSystem.deleteContents(blkname)
    Simulink.BlockDiagram.copyContentsToSubSystem(modname, blkname)

    % open subsystem
    open_system(blkname)

    % Update Address
    blkname = [blkname, '/LTI System'];
    
    % Upload system model to LTI system
    estring = revalsys(plantmod);
    set_param(blkname, 'sys', estring) 
           
end
    


                            
