function X = isemptycell(Y)
% ISEMPTYCELL  determines whether elements in a cell array of strings is
% empty.
% Useful for determining whether input and output names were assigned to a
% system.
% 
% SYNTAX
% (a)   isemptycell(Y) returns a logical array in which a 1 is returned if 
% the element in Y is a positive whole number and 0 otherwise. 
%        
% (b)   X = isemptycell(Y) a logical array X in which a 1 is returned if 
% the element in Y is a positive whole number and 0 otherwise

% *************************************************************************
% Author:           Crystal Blackwell 
% Email:            Crystal.Blackwell@sta.uwi.edu
% Created:          January 2013; 
% Last revision:    29-June-2013;
% Useful websites:
%
% MATLAB VERSIONS USED IN PROGRAMMING PROCESS: 
% - MATLAB R2013a
%
% *************************************************************************
% NATIVE MATLAB FUNCTIONS USED TO CREATE THIS FUNCTION:
% nargin                    nargout                     error
% narginchk                 nargoutchk                  iscell
% cellfun                   cell2mat                         
% *************************************************************************


    % Check for correct number of output arguments
    if nargout <= 1
        % Check for correct number of input arguments
        if nargin == 1 
            % Check if y is a number
            if iscell(Y) == 1
                X = cellfun(@isempty, Y, 'UniformOutput', 0);
                X = cell2mat(X);
            else
                % Display error if input is not a cell array
                error('Input argument must be cell array.')                    
            end
        else
            % Display error if incorrect number of inputs
            narginchk(1, 1)
        end
    else
        % Display error if incorrect number of outputs
        nargoutchk(0, 1)
    end
end
