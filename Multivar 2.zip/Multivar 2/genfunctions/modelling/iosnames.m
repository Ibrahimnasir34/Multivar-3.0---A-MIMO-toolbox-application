function sys = iosnames(sys)
% IOSNAMES  Assigns default variable names to un-named variables in a MIMO 
% system of type of type tf, zpk and ss. Named variables remain unmodified.
% This function is used to make the input-output pairing and decoupling 
% processes easier as these two processes rely on names being assigned to 
% all system variables.
% 
% SYNTAX
% (a)   iosnames(SYS) return MIMO system type tf, zpk and ss with variable names assigned to 
% un-named variables.
% 
% (b)   SYS = iosnames(SYS) assigns variable names to un-named variables in MIMO
% system SYS of type tf, zpk and ss.
% 
% (c)   SYS1 = iosnames(SYS) generates copy of the system, SYS1, with names 
% assigned to the un-named variables. 
% 
% See also MODTYPTEST, SYSARRANGE.

% *************************************************************************
% Author:           Crystal Blackwell 
% Email:            Crystal.Blackwell@sta.uwi.edu
% Created:          January 2013; 
% Last revision:    29-June-2013;
% Useful websites:
%
% MATLAB VERSIONS USED IN PROGRAMMING PROCESS: 
% - MATLAB R2013a
%
% *************************************************************************
% NATIVE MATLAB FUNCTIONS USED TO CREATE THIS FUNCTION:
% class                     length                      isempty
% nargin                    nargout                     narginchk 
% nargoutchk
% *************************************************************************
% MULTIVAR FUNCTIONS USED TO CREATE THIS FUNCTION:
% modtyptest
% *************************************************************************


    % Check for correct number of output arguments
    if nargout <= 1
        % Check for correct number of input arguments
        if nargin == 1 

            % determines the type of system and sets flag
            modnum = modtyptest(sys);

            % For tf, ss, zpk systems
            if modnum == 1 || modnum == 2 || modnum == 3 || modnum == 4 || modnum == 5 || modnum == 6 
                % For input names
                % obtain the variable names
                m_innames = sys.InputName;
                lenmin = length(m_innames);
                for b = 1:1:lenmin
                    % if empty, assign name
                    if isempty(m_innames{b})
                        m_innames{b} = ['U', num2str(b)];         
                    end
                end
                % Assign Names
                sys.InputName = m_innames;    

                % For output names
                % obtain the variable names
                m_outnames = sys.OutputName;
                lenmout = length(m_outnames);
                for c = 1:1:lenmout
                    % if empty, assign name
                    if isempty(m_outnames{c})
                        m_outnames{c} = ['Y', num2str(c)];
                    end
                end
                % Assign Names
                sys.OutputName = m_outnames;

                % For ss systems only
                if  modnum == 3 || modnum == 4 
                    % For state names
                    % obtain the variable names
                    m_stanames = sys.StateName;
                    lenmsta = length(m_stanames);
                    for d = 1:1:lenmsta
                        % if empty, assign name
                        if isempty(m_stanames{d})
                            m_stanames{d} = ['X', num2str(d)];
                        end
                    end 
                    % Assign Names
                    sys.StateName = m_stanames;
                end
            else
                error('Multivar 1.0: Input system is not compatible will Multivar.')
            end   
        else
            % Display error if incorrect number of inputs
            narginchk(1, 1)
        end
    else
        % Display error if incorrect number of outputs
        nargoutchk(0, 1)
    end

end

