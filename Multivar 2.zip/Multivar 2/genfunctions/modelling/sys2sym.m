function g = sys2sym(G)
%SYS2SYM  Converts ss, tf, or zpk system to Symbolic Transfer Function
%conversion.
% 
% SYNTAX
% (a)    g = sys2sym(G) returns a symbolic transfer function g after
% converting the LTI MIMO system SYS. G can contain ioDelays.
% 
% See also POLY2SYM, GNYQUIST.

% *************************************************************************
% Author:           Crystal Blackwell 
% Email:            Crystal.Blackwell@sta.uwi.edu
% Created:          January 2013; 
% Last revision:    29-June-2013;
% Useful websites:
%
% MATLAB VERSIONS USED IN PROGRAMMING PROCESS: 
% - MATLAB R2013a
%
% *************************************************************************
% NATIVE MATLAB FUNCTIONS USED TO CREATE THIS FUNCTION:
% nargin            nargout             sym                 size                      
% zeros             poly2sym            exp                 simple 
% narginchk         nargoutchk          class
% *************************************************************************

    % Check for correct number of output arguments
    if nargout == 1
        % Check for correct number of input arguments
        if nargin == 1 

            % creating a symbolic variable p
            p = sym('p');
            
            % creating a symbolic matrix g of size G
            [n,m] = size(G);
            g = sym(zeros(n,m));            
           
            % determines the type of system and sets flag
            modtyp = class(G);
            switch modtyp
                case 'tf'        
                    cflag = 1;
                case 'zpk'
                    G = tf(G);
                    cflag = 1;
                case 'ss'
                    G = tf(zpk(G));
                    cflag = 1;
                otherwise
                    cflag = 0;
                    error('Multivar 1.0: System must be of type tf, zpk or ss.')
            end
            
            if cflag == 1
                % Extracting information from tf model
                numer = G.num;
                denom = G.den;

                if hasdelay(G) == 1 % if tf element has ioDelay
                    iodel = G.ioDelay;                
                end

                % Walking through g and filling in symbolic data
                for i = 1 : n
                    for j = 1 : m
                        % Convert numerator and denominator to symbolic
                        % form.
                        n = poly2sym(numer{i, j}, p);
                        d = poly2sym(denom{i, j}, p);

                        if hasdelay(G) == 1 % if tf element has ioDelay
                            del = exp(-1* iodel(i, j)* p);
                            g(i,j)= n /d * del;
                        else % if tf element has no ioDelay
                            g(i,j)= n /d ;
                        end
                    end
                end
            end  
        else
            % Display error if incorrect number of inputs
            narginchk(1, 1)
        end
    else
        % Display error if incorrect number of outputs
        nargoutchk(1, 1)
    end            
%------------- END OF CODE --------------