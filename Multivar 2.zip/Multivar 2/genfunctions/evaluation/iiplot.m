function varargout = iiplot(varargin)
% IIPLOT  Plots the interaction index of a MIMO system with respect to frequency.
%
% SYNTAX
% iiplot(SYS)
% (a)   iiplot(SYS) plots interaction index versus frequency for a MIMO system model.
%        
% (b)   [II, W] = iiplot(SYS) returns the vector of interaction index 
%       values, II and vector of frequency values, W  that would have been
%       plotted for the  interaction index versus frequency plot of the 
%       MIMO model.
% (c)   II = iiplot(SYS,W) returns the vector of interaction index 
%       values, II that would have been plotted for the frequencies W in 
%       the  interaction index versus frequency plot of the MIMO model.
% See also SIGMA

% *************************************************************************
% Author:           Crystal Blackwell 
% Email:            Crystal.Blackwell@sta.uwi.edu
% Created:          January 2013; 
% Last revision:    29-June-2013;
% Useful websites:
%
% MATLAB VERSIONS USED IN PROGRAMMING PROCESS: 
% - MATLAB R2013a
%
% *************************************************************************
% NATIVE MATLAB FUNCTIONS USED TO CREATE THIS FUNCTION:
% sigma             size                max                 min
% plot              set                 gca                 xlabel
% ylabel            title               evalfr              eye
% eig               diag
% *************************************************************************

    % Check number of outputs
    if nargout ==0 ||  nargout == 1 || nargout == 2
        
        % Check number of inputs
        if nargin == 1 || nargin == 2
            
            SYS = varargin{1};
            
            % Check if system input is valid
            modnum = modtyptest(SYS);
            
            % Check if system is square
            [m,n] = size(SYS);
            if m == n % if square
                chk = 1;
            else 
                chk = 0; % if non-square
            end
            
            if modnum == 0 || chk == 0
                if modnum == 0
                    % Display error message if system input is invalid
                    error('Multivar: Model must be tf, ss or zpk.')
                end
                
                if chk == 0
                    % Display error message if system input is invalid
                    error('Multivar: System model must be square.')
                end                    
            else
                if nargin == 2
                    W = varargin{2};
                else
                    % Obtain vector of singular values and frequency values
                    [SV, W] = sigma(SYS);
                end
                
                % Preallocate II vector
                II = size(W);                
                for a = 1: length(W)                    
                    % Determine interaction index for each frequency value.
                    X = evalfr(SYS,W(a));
                    idx = eye(size(SYS));
                    C = abs((1-idx).*X);
                    D = abs(diag(diag(X)));
                    II(a) = max(eig(C/D));
                end


                switch nargout
                    case 0 % if no output argument, generate plot
                        % Create vector of the threshold value
                        IIf = ones(size(II));
                        
                        % Plot the interaction index (blue) and threshold
                        % value (red) versus frequency
                        plot(W, II, 'b', W, IIf, 'r');
                        legend('Interaction Index, {\lambda}','Threshold ({\lambda} = 1)') 
                        set(gca, 'XScale','log','FontName','Helvetica','FontSize',8, 'XColor', [0.4 0.4 0.4], 'YColor', [0.4 0.4 0.4]);     
                        xlabel('Frequency (rads/s)', 'Color', [0 0 0])
                        ylabel('Interaction Index', 'Color', [0 0 0])
                        title('Plot of Interaction Index versus frequency')                    
                    case 1
                        varargout{1} = II;
                    case 2 
                        varargout{1} = II;
                        varargout{2} = W;               
                    otherwise
                end
            end
        else
            % Display error if incorrect number of inputs
            narginchk(1,2)
        end
    else
           % Display error if incorrect number of outputs
            nargoutchk(0,2)
    end 
end









