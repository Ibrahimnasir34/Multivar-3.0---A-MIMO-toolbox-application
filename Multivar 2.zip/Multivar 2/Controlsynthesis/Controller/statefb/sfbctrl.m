function varargout = sfbctrl(varargin)
% SFBCTRL M-file for sfbctrl.fig
%      SFBCTRL, by itself, creates a new SFBCTRL or raises the existing
%      singleton*.
%
%      H = SFBCTRL returns the handle to a new SFBCTRL or the handle to
%      the existing singleton*.
%
%      SFBCTRL('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in SFBCTRL.M with the given input arguments.
%
%      SFBCTRL('Property','Value',...) creates a new SFBCTRL or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before sfbctrl_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to sfbctrl_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help sfbctrl

% Last Modified by GUIDE v2.5 29-Dec-2013 17:13:01

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @sfbctrl_OpeningFcn, ...
                   'gui_OutputFcn',  @sfbctrl_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before sfbctrl is made visible.
function sfbctrl_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to sfbctrl (see VARARGIN)

% Choose default command line output for sfbctrl
handles.output = hObject;

% Get root application data
mstruct = getappdata(0, 'mlvappdata');

% Set position and size and title
set(handles.output, 'OuterPosition',mstruct.windowposition, 'Name', mstruct.gtitle);

% Set handle of previous page as gui/figure application data
setappdata(handles.output,'hprevpage',mstruct.phandlerecord(length(mstruct.phandlerecord)));

% Update the page handle record in the structure and then save structure as root application data
mstruct.phandlerecord = [mstruct.phandlerecord, handles.output];
setappdata(0, 'mlvappdata', mstruct)

% set struct from root application data as gui/figure application data
setappdata(handles.output, 'gstruct', mstruct);

% Setting defaults
% Display image
imshow('sfbctrl.jpg')
% disable estimator button
set(handles.createestim, 'Enable', 'off') 

% Setting defaults
modnum = modtyptest(mstruct.controlmodel);
switch modnum
    case 2
        % tf without delays
        SSsys = ss(mstruct.controlmodel);
    case 4
        % ss without delays
        SSsys = mstruct.controlmodel;
    case 6
        % zpk without delays
        SSsys = ss(mstruct.controlmodel);
    otherwise
        return
end

% Set model (exact or approximate) for decoupling as gui/figure application data
setappdata(handles.output, 'modforctrl', SSsys);
    
%Display number of inputs and outputs for original model
[m, r] = size(SSsys);
sm = num2str(m);
sr = num2str(r);
set(handles.noout,'String',sm);
set(handles.noin,'String',sr);

% No of loops controlled
if m == r
    set(handles.nocl,'String',sm);
end

% Setting model display to display original model
sys_text = evalc('SSsys');
tlines = strsplit(sys_text,'\n');
set(handles.moddisplay,'FontName', 'Monospaced', 'String',tlines);

% determine controllability and observability of original system
A = SSsys.a;
B = SSsys.b;
C = SSsys.c;

% Number of states
nostat = length(A);
set(handles.nstate, 'String', nostat)

% Determine  controllability matrix
Co = ctrb(A,B);  

% Number of controllable states
nco = rank(Co);
set(handles.ncostates, 'String', nco)

% Number of uncontrollable states
nunco = nostat - nco;
set(handles.nuncostates, 'String', nunco)   

% Determine  observability matrix   
Ob = obsv(A,C);    

% Number of observable states
nob = rank(Ob);
set(handles.nobstates, 'String', nob)

% Number of unobservable states
nunob = nostat - nob;
set(handles.nunobstates, 'String', nunob)      

if nunob == 0 % if there are no unobservable states
    set(handles.createestim, 'Enable', 'on') % enable estimator button
else
    set(handles.createestim, 'Enable', 'off') % disable estimator button
end  

% Determine controller poles in poles table (Columns are 1)system poles, 2)multipliers,
% 3)desired closed loop poles)
[ns1, ns2] = size(A);
matrixscp = ones(ns1, 3);
matrixscp(:,1) = pole(SSsys);
for q = 1: 1: ns1
    if real(matrixscp(q,1))> 0
        matrixscp(q,2) = -1;
    else
        matrixscp(q,2) = 1;
    end
end
matrixscp(:,3) = matrixscp(:,1) .* matrixscp(:,2);
set(handles.s_cpoles,'Data',matrixscp, 'BackgroundColor',[0.5 1 1]  ,'ColumnWidth',{160},'ColumnEditable', [false, true, false]);

% Performing SFB control
cpoles = matrixscp(:,3)';
[K, N]= sfbc(SSsys, cpoles);
set(handles.Kmatrix,'Data',K, 'BackgroundColor',[1 1 0.5]  ,'ColumnEditable', false);
set(handles.Nmatrix,'Data',N, 'BackgroundColor',[1 0.5 0.5]  ,'ColumnEditable', false);

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes sfbctrl wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = sfbctrl_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes when user attempts to close figure1.
function figure1_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: delete(hObject) closes the figure

% display a question dialog box 
selection = questdlg('Are you sure you want to close Multivar?','Close Request Function','Yes','No','Yes'); 

switch selection, 
    case 'Yes'     
        % delete all figures related to multivar
          mstruct = getappdata(handles.output,'gstruct');  
          delete(mstruct.phandlerecord) 
          exit_multivar
    case 'No'
       % Do nothing
end


% --- Executes on button press in goback.
function goback_Callback(hObject, eventdata, handles)
% hObject    handle to goback (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get position struct from gui/figure application data.
mstruct = getappdata(handles.output, 'gstruct');

% Update/modify structure
% Get rid of the handle of the current figure
mstruct.phandlerecord = mstruct.phandlerecord(1: length(mstruct.phandlerecord) - 1);

% Get position of the current GUI window 
mstruct.windowposition = get(gcf,'OuterPosition');

% Update root application data
setappdata(0, 'mlvappdata', mstruct);

% Get handle of previous page from figure appdata
% Activate previous gui window and delete the handle of the current window
set(getappdata(handles.output,'hprevpage'), 'OuterPosition',mstruct.windowposition,'Visible', 'On');
set(handles.output, 'Visible', 'Off');
delete(handles.output)



function moddisplay_Callback(hObject, eventdata, handles)
% hObject    handle to moddisplay (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of moddisplay as text
%        str2double(get(hObject,'String')) returns contents of moddisplay as a double


% --- Executes during object creation, after setting all properties.
function moddisplay_CreateFcn(hObject, eventdata, handles)
% hObject    handle to moddisplay (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in nextbutt.
function nextbutt_Callback(hObject, eventdata, handles)
% hObject    handle to nextbutt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% get figure application data
mstruct = getappdata(handles.output, 'gstruct');

% Get model for decoupling from gui/figure application data
SSsys = getappdata(handles.output, 'modforctrl');

% Save control info
% Performing SFB control
matrixscp = get(handles.s_cpoles,'Data');
Syspole = pole(SSsys);
cpoles = Syspole .* matrixscp(:,2);
[K, N]= sfbc(SSsys, cpoles);
csys = sfbc_gen(SSsys, K, N);

mstruct.controlinfo = {K, N, SSsys, csys};

% Update control model
mstruct.controlmodel = csys;

% Update window position in structure
mstruct.windowposition = get(gcf,'OuterPosition');

% Update root application data
setappdata(0, 'mlvappdata', mstruct);

% Activate new GUI window and close the last window
set(sfbctrl3, 'Visible', 'On');
set(handles.output, 'Visible', 'Off');

% Update handles structure
guidata(hObject, handles);


function msgbox_Callback(hObject, eventdata, handles)
% hObject    handle to msgbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of msgbox as text
%        str2double(get(hObject,'String')) returns contents of msgbox as a double


% --- Executes during object creation, after setting all properties.
function msgbox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to msgbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in createestim.
function createestim_Callback(hObject, eventdata, handles)
% hObject    handle to createestim (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% get figure application data
mstruct = getappdata(handles.output, 'gstruct');

% Get model for decoupling from gui/figure application data
SSsys = getappdata(handles.output, 'modforctrl');

% Save control info
% Performing SFB control
matrixscp = get(handles.s_cpoles,'Data');
Syspole = pole(SSsys);
cpoles = Syspole .* matrixscp(:,2);
[K, N]= sfbc(SSsys, cpoles);
csys = sfbc_gen(SSsys, K, N);

mstruct.controlinfo = {K, N, SSsys, csys};

% Update control model
mstruct.controlmodel = csys;

% Update window position in structure
mstruct.windowposition = get(gcf,'OuterPosition');

% Update root application data
setappdata(0, 'mlvappdata', mstruct);

% Activate new GUI window and close the last window
set(sfbctrl2, 'Visible', 'On');
set(handles.output, 'Visible', 'Off');

% Update handles structure
guidata(hObject, handles);


% --- Executes when entered data in editable cell(s) in s_cpoles.
function s_cpoles_CellEditCallback(hObject, eventdata, handles)
% hObject    handle to s_cpoles (see GCBO)
% eventdata  structure with the following fields (see UITABLE)
%	Indices: row and column indices of the cell(s) edited
%	PreviousData: previous data for the cell(s) edited
%	EditData: string(s) entered by the user
%	NewData: EditData or its converted form set on the Data property. Empty if Data was not changed
%	Error: error string when failed to convert EditData to appropriate value for Data
% handles    structure with handles and user data (see GUIDATA)

% Get model for decoupling from gui/figure application data
SSsys = getappdata(handles.output, 'modforctrl');

% Get index of edited cell
cedit = eventdata.Indices;
% Get data from table
matrixscp = get(handles.s_cpoles, 'Data');
matrixscp(cedit(1), cedit(2)  + 1) = matrixscp(cedit(1), cedit(2) - 1) * matrixscp(cedit(1), cedit(2)); 
set(handles.s_cpoles, 'Data', matrixscp);

% Performing SFB control
Syspole = pole(SSsys);
cpoles = Syspole .* matrixscp(:,2);
[K, N]= sfbc(SSsys, cpoles);
set(handles.Kmatrix,'Data',K, 'BackgroundColor',[1 1 0.5]  ,'ColumnEditable', false);
set(handles.Nmatrix,'Data',N, 'BackgroundColor',[1 0.5 0.5]  ,'ColumnEditable', false);

% Update handles structure
guidata(hObject, handles);
