function [Abar, Bbar, Cbar, Dbar, T, fb] = ocf(sys)
% OCF  generates the Observable Canonical Form(OCF) of the supplied 
% MIMO system.
% 
% SYNTAX
% [Abar, Bbar, Cbar, Dbar, T, fb] = ocf(sys) returns the Observable 
% Canonical Form(OCF) of the MIMO system SYS and its matrices Abar, Bbar, 
% Cbar, Dbar, the Transformation matrix T and the feedback fb in the event
% that the similarity transformation could not be performed.

% *************************************************************************
% Author:           Crystal Blackwell 
% Email:            Crystal.Blackwell@sta.uwi.edu
% Created:          January 2013; 
% Last revision:    29-June-2013;
% Useful websites:
%
% MATLAB VERSIONS USED IN PROGRAMMING PROCESS: 
% - MATLAB R2013a
%
% *************************************************************************
% NATIVE MATLAB FUNCTIONS USED TO CREATE THIS FUNCTION:
% class                     obsv                        size
% det                       inv                         ss2ss                     
% *************************************************************************

    % Check if input argument is a state-space system
    if strcmp(class(sys), 'ss') == 1
        A = sys.a;
        B = sys.b;
        C = sys.c;
        D = sys.d;
        
        Ob = obsv(sys);
        % If Ob has an inverse...
        [a, b] = size(Ob);
        if a ==b & det(Ob) ~=0        
            [M, p] = m_matrix(A);
            T = M * Ob;        
            sysT = ss2ss(sys,T);
            Abar = sysT.a;
            Bbar = sysT.b;
            Cbar = sysT.c;
            Dbar = sysT.d;
            fb = 1;            
        else
            Abar = [];
            Bbar = [];
            Cbar = [];
            Dbar = [];
            T = [];
            fb = 0;
        end
    else         
        error('Multivar 1.0: System must be in state space form.')
    end
end







