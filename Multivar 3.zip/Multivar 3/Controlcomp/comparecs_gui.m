function varargout = comparecs_gui(varargin)
% COMPARECS_GUI M-file for comparecs_gui.fig
%      COMPARECS_GUI, by itself, creates a new COMPARECS_GUI or raises the existing
%      singleton*.
%
%      H = COMPARECS_GUI returns the handle to a new COMPARECS_GUI or the handle to
%      the existing singleton*.
%
%      COMPARECS_GUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in COMPARECS_GUI.M with the given input arguments.
%
%      COMPARECS_GUI('Property','Value',...) creates a new COMPARECS_GUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before comparecs_gui_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to comparecs_gui_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help comparecs_gui

% Last Modified by GUIDE v2.5 10-Nov-2017 17:35:37

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @comparecs_gui_OpeningFcn, ...
                   'gui_OutputFcn',  @comparecs_gui_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before comparecs_gui is made visible.
function comparecs_gui_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to comparecs_gui (see VARARGIN)

% Choose default command line output for comparecs_gui
handles.output = hObject;

% Get root application data
mstruct = getappdata(0, 'mlvappdata');

% Set position and size and title
set(handles.output, 'OuterPosition',mstruct.windowposition, 'Name', mstruct.gtitle);

% Set handle of previous page as gui/figure application data
setappdata(handles.output,'hprevpage',mstruct.phandlerecord(length(mstruct.phandlerecord)));

% Update the page handle record in the structure and then save structure as root application data
mstruct.phandlerecord = [mstruct.phandlerecord, handles.output];
setappdata(0, 'mlvappdata', mstruct)

% set struct from root application data as gui/figure application data
setappdata(handles.output, 'gstruct', mstruct);

% Setting defaults
% clear message box
set(handles.msgbox,'String', '');

% Configuring pop up menus
type_list{1} = 'Transient';
type_list{2} = 'Frequency Dependent';
set(handles.typepop,'String',type_list)
set(handles.typepop,'Value', 1)

trans_list{1} = 'Step Response';
trans_list{2} = 'Impulse Response';
trans_list{3} = 'Ramp Response';
trans_list{4} = 'Parabolic Response';
setappdata(handles.output, 'transsel', trans_list)

freq_list{1} = 'Bode';
freq_list{2} = 'Nyquist';
freq_list{3} = 'Nichols';        
setappdata(handles.output, 'freqsel', freq_list)

analtype = get(handles.typepop,'Value');
switch analtype
    case 1
        set(handles.analpop,'String',trans_list)
        set(handles.analpop,'Value', 1)
    case 2
        set(handles.analpop,'String',freq_list)
        set(handles.analpop,'Value', 1)
    otherwise
end


% Displaying original step response
step(mstruct.controlmodel);
clabel = 'Current system';
legend(clabel)

% saving figure/gui application data
setappdata(handles.output, 'allsys', {mstruct.controlmodel})
setappdata(handles.output, 'allnames', {clabel})

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes comparecs_gui wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = comparecs_gui_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in goback.
function goback_Callback(hObject, eventdata, handles)
% hObject    handle to goback (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get position struct from gui/figure application data.
mstruct = getappdata(handles.output, 'gstruct');

% Update/modify structure
% Get rid of the handle of the current figure
mstruct.phandlerecord = mstruct.phandlerecord(1: length(mstruct.phandlerecord) - 1);

% Get position of the current GUI window 
mstruct.windowposition = get(gcf,'OuterPosition');

% Update root application data
setappdata(0, 'mlvappdata', mstruct);

% Get handle of previous page from figure appdata
% Activate previous gui window and delete the handle of the current window
set(getappdata(handles.output,'hprevpage'), 'OuterPosition',mstruct.windowposition,'Visible', 'On');
set(handles.output, 'Visible', 'Off');
delete(handles.output)


% --- Executes when user attempts to close figure1.
function figure1_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: delete(hObject) closes the figure

% display a question dialog box 
selection = questdlg('Are you sure you want to close Multivar?','Close Request Function','Yes','No','Yes'); 

switch selection, 
    case 'Yes'     
        % delete all figures related to multivar
          mstruct = getappdata(handles.output,'gstruct');  
          delete(mstruct.phandlerecord) 
          exit_multivar
    case 'No'
       % Do nothing
end


% --- Executes on selection change in typepop.
function typepop_Callback(hObject, eventdata, handles)
% hObject    handle to typepop (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns typepop contents as cell array
%        contents{get(hObject,'Value')} returns selected item from typepop

% Get figure/gui application data
trans_list = getappdata(handles.output, 'transsel');
freq_list = getappdata(handles.output, 'freqsel');

analtype = get(handles.typepop,'Value');
switch analtype
    case 1
        set(handles.analpop,'String',trans_list)
        set(handles.analpop,'Value', 1)

    case 2
        set(handles.analpop,'String',freq_list)
        set(handles.analpop,'Value', 1)        
    otherwise
end

% Get figure/gui application data
tsys = getappdata(handles.output, 'allsys');
ntsys = getappdata(handles.output, 'allnames');

% Generate graphs for selection
% Determine type of analysis selected
analtype = get(handles.typepop,'Value');
analname = get(handles.analpop,'Value');

%Code for when the various options are selected
switch analtype
    case 1 
        switch analname 
            case 1
                    % Displaying step responses
                    subplot(1,1,1); step(tsys{:});
                    legend(ntsys{:})

            case 2
                    % Displaying impulse responses
                    subplot(1,1,1); impulse(tsys{:});
                    legend(ntsys{:})

            case 3           
                    % Displaying ramp responses
                    subplot(1,1,1); mlvramp(tsys{:});
                    legend(ntsys{:})

            case 4           
                    % Displaying parametric responses
                    subplot(1,1,1); mlvpara(tsys{:});
                    legend(ntsys{:})

            otherwise
        end

    case 2
        switch analname 
            case 1
                    % Displaying bode plots
                    subplot(1,1,1); bode(tsys{:});
                    legend(ntsys{:})

            case 2
                    % Displaying nyquist plots
                    subplot(1,1,1); nyquist(tsys{:});
                    legend(ntsys{:})

            case 3           
                    % Displaying nichols plot
                    subplot(1,1,1); nichols(tsys{:});
                    legend(ntsys{:})

            otherwise
        end
    otherwise
end   

% toggle grid if necessary
if get(handles.gridctrl,'Value')== 1
    grid on
else
    grid off
end

% Update handles structure
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function typepop_CreateFcn(hObject, eventdata, handles)
% hObject    handle to typepop (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



% --- Executes on button press in gridctrl.
function gridctrl_Callback(hObject, eventdata, handles)
% hObject    handle to gridctrl (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of gridctrl

if get(handles.gridctrl,'Value')== 1
    grid on
else
    grid off
end


% --- Executes on selection change in analpop.
function analpop_Callback(hObject, eventdata, handles)
% hObject    handle to analpop (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns analpop contents as cell array
%        contents{get(hObject,'Value')} returns selected item from analpop

% Get figure/gui application data
tsys = getappdata(handles.output, 'allsys');
ntsys = getappdata(handles.output, 'allnames');

% Generate graphs for selection
% Determine type of analysis selected
analtype = get(handles.typepop,'Value');
analname = get(handles.analpop,'Value');

%Code for when the various options are selected
switch analtype
    case 1 
        switch analname 
            case 1
                    % Displaying step responses
                    subplot(1,1,1); step(tsys{:});
                    legend(ntsys{:})

            case 2
                    % Displaying impulse responses
                    subplot(1,1,1); impulse(tsys{:});
                    legend(ntsys{:})

            case 3           
                    % Displaying ramp responses
                    subplot(1,1,1); mlvramp(tsys{:});
                    legend(ntsys{:})

            case 4           
                    % Displaying parametric responses
                    subplot(1,1,1); mlvpara(tsys{:});
                    legend(ntsys{:})

            otherwise
        end

    case 2
        switch analname 
            case 1
                    % Displaying bode plots
                    subplot(1,1,1); bode(tsys{:});
                    legend(ntsys{:})

            case 2
                    % Displaying nyquist plots
                    subplot(1,1,1); nyquist(tsys{:});
                    legend(ntsys{:})

            case 3           
                    % Displaying nichols plot
                    subplot(1,1,1); nichols(tsys{:});
                    legend(ntsys{:})

            otherwise
        end
    otherwise
end   

% toggle grid if necessary
if get(handles.gridctrl,'Value')== 1
    grid on
else
    grid off
end

% Update handles structure
guidata(hObject, handles);



% --- Executes during object creation, after setting all properties.
function analpop_CreateFcn(hObject, eventdata, handles)
% hObject    handle to analpop (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function msgbox_Callback(hObject, eventdata, handles)
% hObject    handle to msgbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of msgbox as text
%        str2double(get(hObject,'String')) returns contents of msgbox as a double


% --- Executes during object creation, after setting all properties.
function msgbox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to msgbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in browbutt.
function browbutt_Callback(hObject, eventdata, handles)
% hObject    handle to browbutt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get figure/gui application data
mstruct = getappdata(handles.output,'gstruct');

% Open dialog box for retrieving file
[FileName,PathName] = uigetfile('*.mat','Select the MATLAB binary format (.mat) file from Project folder.', mstruct.projectpath);

 % Check if filepath, ext etc is valid
         % to be completed

% Display selection if valid
if FileName ~= 0 
    if PathName ~= 0
        % set display
        slfmpath = [PathName,FileName];
        set(handles.filenm, 'String',slfmpath )   

        % load .mat file
        newsys = importdata(slfmpath);

        % Get figure/gui application data
        tsys = getappdata(handles.output, 'allsys');
        ntsys = getappdata(handles.output, 'allnames');

        % adding data for new system
        tsys = [tsys, {newsys}];
        ntsys = [ntsys, {FileName}];

        % Generate graphs for selection
        % Determine type of analysis selected
        analtype = get(handles.typepop,'Value');
        analname = get(handles.analpop,'Value');
        
        %Code for when the various options are selected
        switch analtype
            case 1 
                switch analname 
                    case 1
                            % Displaying step responses
                            subplot(1,1,1); step(tsys{:});
                            legend(ntsys{:})

                    case 2
                            % Displaying impulse responses
                            subplot(1,1,1); impulse(tsys{:});
                            legend(ntsys{:})

                    case 3           
                            % Displaying ramp responses
                            subplot(1,1,1); mlvramp(tsys{:});
                            legend(ntsys{:})

                    case 4           
                            % Displaying parametric responses
                            subplot(1,1,1); mlvpara(tsys{:});
                            legend(ntsys{:})

                    otherwise
                end

            case 2
                switch analname 
                    case 1
                            % Displaying bode plots
                            subplot(1,1,1); bode(tsys{:});
                            legend(ntsys{:})

                    case 2
                            % Displaying nyquist plots
                            subplot(1,1,1); nyquist(tsys{:});
                            legend(ntsys{:})

                    case 3           
                            % Displaying nichols plot
                            subplot(1,1,1); nichols(tsys{:});
                            legend(ntsys{:})

                    otherwise
                end
            otherwise
        end   

        % toggle grid if necessary
        if get(handles.gridctrl,'Value')== 1
            grid on
        else
            grid off
        end

        % save handles as figure/gui application data
        setappdata(handles.output, 'allsys', tsys)
        setappdata(handles.output, 'allnames', ntsys)

    end
end

% Update handles structure
guidata(hObject, handles);


function filenm_Callback(hObject, eventdata, handles)
% hObject    handle to filenm (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of filenm as text
%        str2double(get(hObject,'String')) returns contents of filenm as a double


% --- Executes during object creation, after setting all properties.
function filenm_CreateFcn(hObject, eventdata, handles)
% hObject    handle to filenm (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

      


% --- Executes on button press in ionextbutt.
function ionextbutt_Callback(hObject, eventdata, handles)
% hObject    handle to ionextbutt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

mstruct = getappdata(handles.output, 'gstruct');

% Indicate the type of analysis
analtype = get(handles.typepop,'Value');
analname = get(handles.analpop,'Value');
mstruct.compcurrent = [analtype, analname];

% Obtain preparing to pass transfer functions to the next GUI
tsys = getappdata(handles.output, 'allsys');
mstruct.cssys = tsys;

% Obtain preparing to pass system names to the next GUI
ntsys = getappdata(handles.output, 'allnames');
mstruct.csnames = ntsys;

% Update window position in structure
mstruct.windowposition = get(gcf,'OuterPosition');

% Update root application data
setappdata(0, 'mlvappdata', mstruct);

% Activate new GUI window and close the last window
set(comparecsio_gui, 'Visible', 'On');
set(handles.output, 'Visible', 'Off');

% Update handles structure
guidata(hObject, handles);
