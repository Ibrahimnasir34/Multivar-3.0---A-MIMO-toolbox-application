function [Abar, Bbar, Cbar, Dbar, T] = kcf(sys)
% KCF generate the Kalman Canonical Form (KCF)of a supplied MIMO system.
% 
% SYNTAX
% [Abar, Bbar, Cbar, Dbar, T] = kcf(sys) returns the Kalman Canonical 
% Form(KCF) of the MIMO system SYS and its matrices Abar, Bbar, Cbar, Dbar,
% and the Transformation matrix T.

% *************************************************************************
% Author:           Crystal Blackwell 
% Email:            Crystal.Blackwell@sta.uwi.edu
% Created:          January 2013; 
% Last revision:    29-June-2013;
% Useful websites:
%
% MATLAB VERSIONS USED IN PROGRAMMING PROCESS: 
% - MATLAB R2013a
%
% *************************************************************************
% NATIVE MATLAB FUNCTIONS USED TO CREATE THIS FUNCTION:
% class                     ctrb                        obsv
% rank                      null                        ss2ss                     
% *************************************************************************

    % Check if input argument is a state-space system
    if strcmp(class(sys), 'ss') == 1
        Co = ctrb(sys);
        Ob = obsv(sys);

        % Rank observable
        rOb = rank(Co);
        % Rank controllable
        rCo = rank(Ob);
        % Rank
        rCoOb = rank([Co';Ob]);

        % Not controllable and not observable
        ncno = null([Co'; Ob]);

        % Not controllable and observable
        nco = null([Co';ncno']);

        % Controllable and not observable
        cno = null([Ob;ncno']); 

        % Controllable and observable
        co = null([ncno';nco';cno'])';

        T = [co cno nco ncno]';

        % Executing transformation
        sysT = ss2ss(sys,T);
        Abar = sysT.a;
        Bbar = sysT.b;
        Cbar = sysT.c;
        Dbar = sysT.d;
     else
        Abar = [];
        Bbar = [];
        Cbar = [];
        Dbar = [];
        T = [];      
    end
end





