function varargout = final_gui(varargin)
% FINAL_GUI MATLAB code for final_gui.fig
%      FINAL_GUI, by itself, creates a new FINAL_GUI or raises the existing
%      singleton*.
%
%      H = FINAL_GUI returns the handle to a new FINAL_GUI or the handle to
%      the existing singleton*.
%
%      FINAL_GUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in FINAL_GUI.M with the given input arguments.
%
%      FINAL_GUI('Property','Value',...) creates a new FINAL_GUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before final_gui_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to final_gui_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help final_gui

% Last Modified by GUIDE v2.5 12-Nov-2013 05:47:12

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @final_gui_OpeningFcn, ...
                   'gui_OutputFcn',  @final_gui_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before final_gui is made visible.
function final_gui_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to final_gui (see VARARGIN)

% Choose default command line output for final_gui
handles.output = hObject;

% Get root application data
mstruct = getappdata(0, 'mlvappdata');

% Set position and size and title
set(handles.output, 'OuterPosition',mstruct.windowposition, 'Name', mstruct.gtitle);

% Set handle of previous page as gui/figure application data
setappdata(handles.output,'hprevpage',mstruct.phandlerecord(length(mstruct.phandlerecord)));

% Update the page handle record in the structure and then save structure as root application data
mstruct.phandlerecord = [mstruct.phandlerecord, handles.output];
setappdata(0, 'mlvappdata', mstruct)

% set struct from root application data as gui/figure application data
setappdata(handles.output, 'gstruct', mstruct);

% Set Defaults
% have no button selected
set(handles.uipanel2,'SelectedObject', []); 
% clear message box
set(handles.msgbox,'String', '');

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes final_gui wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = final_gui_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in closeprog.
function closeprog_Callback(hObject, eventdata, handles)
% hObject    handle to closeprog (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% display a question dialog box 
selection = questdlg('Are you sure you want to close Multivar?','Close Request Function','Yes','No','Yes'); 

switch selection, 
    case 'Yes'     
        % delete all figures related to multivar
          mstruct = getappdata(handles.output,'gstruct');  
          delete(mstruct.phandlerecord) 
          exit_multivar
    case 'No'
       % Do nothing
end


% --- Executes on button press in go_back.
function go_back_Callback(hObject, eventdata, handles)
% hObject    handle to go_back (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get structure from gui/figure application data
mstruct = getappdata(handles.output,'gstruct');

% Update/modify structure
% Get rid of the handle of the current figure
mstruct.phandlerecord = mstruct.phandlerecord(1: length(mstruct.phandlerecord) - 1);

% Get position of the current GUI window 
mstruct.windowposition = get(gcf,'OuterPosition');

% Update root application data
setappdata(0, 'mlvappdata', mstruct);

% Get handle of previous page from figure appdata
% Activate previous gui window and delete the handle of the current window
set(getappdata(handles.output,'hprevpage'), 'OuterPosition',mstruct.windowposition,'Visible', 'On');
set(handles.output, 'Visible', 'Off');
delete(handles.output)


% --- Executes when selected object is changed in uipanel2.
function uipanel2_SelectionChangeFcn(hObject, eventdata, handles)
% hObject    handle to the selected object in uipanel2 
% eventdata  structure with the following fields (see UIBUTTONGROUP)
%	EventName: string 'SelectionChanged' (read only)
%	OldValue: handle of the previously selected object or empty if none was selected
%	NewValue: handle of the currently selected object
% handles    structure with handles and user data (see GUIDATA)

%Get Tag of selected object.
bselected = get(handles.uipanel2,'SelectedObject'); 

% get figure/gui application data
mstruct = getappdata(handles.output, 'gstruct');

%Code for when the various togglebuttons are selected
switch bselected  
    case handles.savecsbutt         
        % clear message box
        set(handles.msgbox,'String', '');

        % Update window position in structure
        mstruct.windowposition = get(gcf,'OuterPosition');

        % Update root application data
        setappdata(0, 'mlvappdata', mstruct);
        
        % Clear toggle selection
        set(handles.uipanel2,'SelectedObject', []); 

        % Activate new GUI window and close the last window
        set(savecs_gui, 'Visible', 'On');
        set(handles.output, 'Visible', 'Off');

        % Update handles structure
        guidata(hObject, handles);

    case handles.exportwsbutt
        % clear message box
        set(handles.msgbox,'String', '');
        
        % determine default variable name
        filename = mstruct.matfile;
        defname = [filename(1:length(filename)-4), '_ctrl']; % take off .mat off filename and append '_ctrl'
        
        % show dialog box with default variable name
        prompt = {'Enter variable name:'};
        title = 'Export to Workspace';
        lines = 1;
        def = {defname};
        answer = inputdlg(prompt, title, lines, def);
                
        % if cancelled do nothing
        if isempty(answer)
        else % if value is returned
            %determine if variable exists in workspace
            try
                A = evalin('base',answer{1}); % attempt to get value of variable from workspace
                YesNo = 1; % return 1
            catch % error generated by evalin is caught
                YesNo = 0; % return 0
            end

            switch YesNo
                case 0 % .mat does not exist
                    % export to workspace
                    assignin('base', answer{1}, mstruct.controlmodel);
                    % display message in message box
                    set(handles.msgbox,'String', ['MULTIVAR: Variable "', answer{1}, '" exported to MATLAB Workspace.'],  'ForegroundColor', [0 0 1]);
                case 1 % .mat of same name exists
                    % if no ask for permission to overwrite
                    % display a question dialog box 
                    selection = questdlg('A variable of the same name already exists. Overwrite?','Workspace Variable Overwite','Yes','No','No'); 

                    switch selection, 
                        case 'Yes'     
                            % export to workspace
                            assignin('base', answer{1}, mstruct.controlmodel);
                            % display message in message box
                            set(handles.msgbox,'String', ['MULTIVAR: Variable "', answer{1}, '" exported to MATLAB Workspace.'],  'ForegroundColor', [0 0 1]);
                        case 'No'
                            % display message in message box
                            set(handles.msgbox,'String', 'MULTIVAR: Please reattempt with a different variable name if you still wish to export to MATLAB workspace.',  'ForegroundColor', [1 0 0]);
                        otherwise
                    end
                otherwise 
            end
        end
        
        % Clear toggle selection
        set(handles.uipanel2,'SelectedObject', []); 
        
        % Update handles structure
        guidata(hObject, handles);
        
    case handles.exportsmbutt
        % clear message box
        set(handles.msgbox,'String', '');

        % Update window position in structure
        mstruct = getappdata(handles.output, 'gstruct');
        
        % Clear toggle selection
        set(handles.uipanel2,'SelectedObject', []);
        
        cs2sim(mstruct.mlvlocation, mstruct.decopinfo)

        % Update handles structure
        guidata(hObject, handles);
 
    
    case handles.compcsbutt
        % clear message box
        set(handles.msgbox,'String', '');

        % Update window position in structure
        mstruct = getappdata(handles.output, 'gstruct');
        mstruct.windowposition = get(gcf,'OuterPosition');

        % Update root application data
        setappdata(0, 'mlvappdata', mstruct);
        
        % Clear toggle selection
        set(handles.uipanel2,'SelectedObject', []); 

        % Activate new GUI window and close the last window
        set(comparecs_gui, 'Visible', 'On');
        set(handles.output, 'Visible', 'Off');

        % Update handles structure
        guidata(hObject, handles);        
    otherwise
end


% --- Executes when user attempts to close figure1.
function figure1_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: delete(hObject) closes the figure

% display a question dialog box 
selection = questdlg('Are you sure you want to close Multivar?','Close Request Function','Yes','No','Yes'); 

switch selection, 
    case 'Yes'     
        % delete all figures related to multivar
          mstruct = getappdata(handles.output,'gstruct');  
          delete(mstruct.phandlerecord) 
          exit_multivar
    case 'No'
       % Do nothing
end



function msgbox_Callback(hObject, eventdata, handles)
% hObject    handle to msgbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of msgbox as text
%        str2double(get(hObject,'String')) returns contents of msgbox as a double


% --- Executes during object creation, after setting all properties.
function msgbox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to msgbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
