function y = issquare(G)
% ISSQUARE  Determines whether arrays, matrices and systems are square.
%
% SYNTAX
% (a)   issquare(G) returns 1 if array, matrix and system G is square and 
% 0 if non square. 
% 
% See also SIZE, IS.

% *************************************************************************
% Author:           Crystal Blackwell 
% Email:            Crystal.Blackwell@sta.uwi.edu
% Created:          January 2013; 
% Last revision:    29-June-2013;
% Useful websites:
%
% MATLAB VERSIONS USED IN PROGRAMMING PROCESS: 
% - MATLAB R2013a
%
% *************************************************************************
% NATIVE MATLAB FUNCTIONS USED TO CREATE THIS FUNCTION:
% class                     size                      nargin
% nargout                   narginchk                 nargoutchk
% error
% *************************************************************************

    % Check for correct number of output arguments
    if nargout <= 1
        % Check for correct number of input arguments
        if nargin == 1 

            try
                [m, r] = size(G);
                if m == r
                    y = 1; % square
                else
                    y = 0; % non-square
                end
            catch err
                error(['Multivar 1.0: ', err.message]) 
            end
        else
            % Display error if incorrect number of inputs
            narginchk(1, 1)
        end
    else
        % Display error if incorrect number of outputs
        nargoutchk(0, 1)
    end            
end
