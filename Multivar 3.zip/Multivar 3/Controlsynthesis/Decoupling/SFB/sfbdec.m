function varargout = sfbdec(varargin)
% SFBDEC M-file for sfbdec.fig
%      SFBDEC, by itself, creates a new SFBDEC or raises the existing
%      singleton*.
%
%      H = SFBDEC returns the handle to a new SFBDEC or the handle to
%      the existing singleton*.
%
%      SFBDEC('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in SFBDEC.M with the given input arguments.
%
%      SFBDEC('Property','Value',...) creates a new SFBDEC or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before sfbdec_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to sfbdec_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help sfbdec

% Last Modified by GUIDE v2.5 15-Dec-2013 15:45:45

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @sfbdec_OpeningFcn, ...
                   'gui_OutputFcn',  @sfbdec_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before sfbdec is made visible.
function sfbdec_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to sfbdec (see VARARGIN)

% Choose default command line output for sfbdec
handles.output = hObject;

% Get root application data
mstruct = getappdata(0, 'mlvappdata');

% Set position and size and title
set(handles.output, 'OuterPosition',mstruct.windowposition, 'Name', mstruct.gtitle);

% Set handle of previous page as gui/figure application data
setappdata(handles.output,'hprevpage',mstruct.phandlerecord(length(mstruct.phandlerecord)));

% Update the page handle record in the structure and then save structure as root application data
mstruct.phandlerecord = [mstruct.phandlerecord, handles.output];
setappdata(0, 'mlvappdata', mstruct)

% set struct from root application data as gui/figure application data
setappdata(handles.output, 'gstruct', mstruct);

% Setting defaults
% Display image
imshow('sfbpic.jpg')
% disable estimator button
set(handles.createestim, 'Enable', 'off') 

% Setting defaults
switch mstruct.modnum
    case 1
        % tf with delays
        SSsys = ss(mstruct.arrapproxmodel);
    case 2
        % tf without delays
        SSsys = mstruct.arrapproxmodel;
    case 4
        % ss without delays
        SSsys = mstruct.arrsysmodel;
    case 5
        % zpk with delays
        SSsys = ss(mstruct.arrapproxmodel);
    case 6
        % zpk without delays
        SSsys = mstruct.arrapproxmodel;
    otherwise
        return
end

% Set model (exact or approximate) for decoupling as gui/figure application data
setappdata(handles.output, 'modfordecop', SSsys);
    
%Display number of inputs and outputs for original model
[m, r] = size(SSsys);
sm = num2str(m);
sr = num2str(r);
set(handles.noout,'String',sm);
set(handles.noin,'String',sr);

% Calculating and displaying SS Condition number for original model
steadysys = dcgain(SSsys);
[U, S, V]  = svd(steadysys);
CN = cond(S);
sCN = num2str(CN);
set(handles.sscn,'String',sCN);

% No of loops controlled
if m == r
    set(handles.nocl,'String',sm);
end

% Setting model display to display original model
sys_text = evalc('SSsys');
tlines = strsplit(sys_text,'\n');
set(handles.moddisplay,'FontName', 'Monospaced', 'String',tlines);

% Performing SFB
[Ke, Te] = getdiagKT(SSsys);
[F, G] = sfbd(SSsys, Ke, Te);

% Check if F is finite
if isfinite(F)== ones(size(F))
    f_chk = 1;
else
    f_chk = 0;
end

% Check if G is finite
if isfinite(G)== ones(size(G))
    g_chk = 1;
else
    g_chk = 0;
end

KT = [Ke',Te'];

%Displaying matrices F, G, KT
set(handles.fmatrix,'Data',F, 'BackgroundColor',[0.5 1 0.5],'ColumnEditable', false);
set(handles.gmatrix,'Data',G, 'BackgroundColor',[1 1 0.5]  ,'ColumnEditable', false);
set(handles.KTmatrix,'Data',KT, 'BackgroundColor',[1 1 0.5]  ,'ColumnEditable', true);

if f_chk == 1 && g_chk == 1
    % clear message box
    set(handles.msgbox, 'String', '')
    
    % Enable NEXT button
    set(handles.nextbutt, 'Enable', 'on')
    
    % Display decoupled system
    dsys = sfbd_gen(SSsys, F, G);
    dsys_text = evalc('dsys');
    tlines = strsplit(dsys_text,'\n');
    set(handles.dmoddisplay,'FontName', 'Monospaced', 'String',tlines);    
   
    % determine controllability and observability of original system
    A = SSsys.a;
    B = SSsys.b;
    C = SSsys.c;
    
    % Number of states
    nostat = length(A);
    set(handles.nstate, 'String', nostat)
    
    % Determine  controllability matrix
    Co = ctrb(A,B);  

    % Number of controllable states
    nco = rank(Co);
    set(handles.ncostates, 'String', nco)

    % Number of uncontrollable states
    nunco = nostat - nco;
    set(handles.nuncostates, 'String', nunco)   
    
    % Determine  observability matrix   
    Ob = obsv(A,C);    

    % Number of observable states
    nob = rank(Ob);
    set(handles.nobstates, 'String', nob)

    % Number of unobservable states
    nunob = nostat - nob;
    set(handles.nunobstates, 'String', nunob)      
   
    if nunob == 0 % if there are no unobservable states
        set(handles.createestim, 'Enable', 'on') % enable estimator button
    else
        set(handles.createestim, 'Enable', 'off') % disable estimator button
    end   
   
else
    emessage = 'Multivar 1.0: ';
    emessage1 =  'F matrix is not finite.';
    emessage2 =  'G matrix is not finite.';
    if f_chk == 0
        emessage = [emessage, emessage1];
    end
    if g_chk == 0
        emessage = [emessage, emessage2];
    end
    set(handles.msgbox, 'String', emessage)
    
    % disable NEXT button
    set(handles.nextbutt, 'Enable', 'off')
end

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes sfbdec wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = sfbdec_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes during object creation, after setting all properties.
function sscn_CreateFcn(hObject, eventdata, handles)
% hObject    handle to sscn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes when user attempts to close figure1.
function figure1_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: delete(hObject) closes the figure

% display a question dialog box 
selection = questdlg('Are you sure you want to close Multivar?','Close Request Function','Yes','No','Yes'); 

switch selection, 
    case 'Yes'     
        % delete all figures related to multivar
          mstruct = getappdata(handles.output,'gstruct');  
          delete(mstruct.phandlerecord) 
          exit_multivar
    case 'No'
       % Do nothing
end


% --- Executes on button press in goback.
function goback_Callback(hObject, eventdata, handles)
% hObject    handle to goback (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get position struct from gui/figure application data.
mstruct = getappdata(handles.output, 'gstruct');

% Update/modify structure
% Get rid of the handle of the current figure
mstruct.phandlerecord = mstruct.phandlerecord(1: length(mstruct.phandlerecord) - 1);

% Get position of the current GUI window 
mstruct.windowposition = get(gcf,'OuterPosition');

% Update root application data
setappdata(0, 'mlvappdata', mstruct);

% Get handle of previous page from figure appdata
% Activate previous gui window and delete the handle of the current window
set(getappdata(handles.output,'hprevpage'), 'OuterPosition',mstruct.windowposition,'Visible', 'On');
set(handles.output, 'Visible', 'Off');
delete(handles.output)



function moddisplay_Callback(hObject, eventdata, handles)
% hObject    handle to moddisplay (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of moddisplay as text
%        str2double(get(hObject,'String')) returns contents of moddisplay as a double


% --- Executes during object creation, after setting all properties.
function moddisplay_CreateFcn(hObject, eventdata, handles)
% hObject    handle to moddisplay (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in nextbutt.
function nextbutt_Callback(hObject, eventdata, handles)
% hObject    handle to nextbutt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% get figure application data
mstruct = getappdata(handles.output, 'gstruct');

% Get model for decoupling from gui/figure application data
SSsys = getappdata(handles.output, 'modfordecop');

% Save decoupling info
% Get data from table
KTdata = get(handles.KTmatrix, 'Data');
Ke = KTdata(:,1);
Te = KTdata(:,2);

% perform state feedback decoupling
[F, G] = sfbd(SSsys, Ke', Te');
dsys = sfbd_gen(SSsys, F, G);

mstruct.decopinfo = {F, G, SSsys, dsys};

% Update control model
mstruct.controlmodel = dsys;

% Update window position in structure
mstruct.windowposition = get(gcf,'OuterPosition');

% Update root application data
setappdata(0, 'mlvappdata', mstruct);

% Activate new GUI window and close the last window
set(sfbdec3, 'Visible', 'On');
set(handles.output, 'Visible', 'Off');

% Update handles structure
guidata(hObject, handles);



function dmoddisplay_Callback(hObject, eventdata, handles)
% hObject    handle to dmoddisplay (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of dmoddisplay as text
%        str2double(get(hObject,'String')) returns contents of dmoddisplay as a double


% --- Executes during object creation, after setting all properties.
function dmoddisplay_CreateFcn(hObject, eventdata, handles)
% hObject    handle to dmoddisplay (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function msgbox_Callback(hObject, eventdata, handles)
% hObject    handle to msgbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of msgbox as text
%        str2double(get(hObject,'String')) returns contents of msgbox as a double


% --- Executes during object creation, after setting all properties.
function msgbox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to msgbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes when entered data in editable cell(s) in KTmatrix.
function KTmatrix_CellEditCallback(hObject, eventdata, handles)
% hObject    handle to KTmatrix (see GCBO)
% eventdata  structure with the following fields (see UITABLE)
%	Indices: row and column indices of the cell(s) edited
%	PreviousData: previous data for the cell(s) edited
%	EditData: string(s) entered by the user
%	NewData: EditData or its converted form set on the Data property. Empty if Data was not changed
%	Error: error string when failed to convert EditData to appropriate value for Data
% handles    structure with handles and user data (see GUIDATA)

% Get model for decoupling from gui/figure application data
SSsys = getappdata(handles.output, 'modfordecop');

% Get data from table
KTdata = get(handles.KTmatrix, 'Data');
Ke = KTdata(:,1);
Te = KTdata(:,2);

% perform state feedback decoupling
[F, G] = sfbd(SSsys, Ke', Te');

% Check if F is finite
if isfinite(F)== ones(size(F))
    f_chk = 1;
else
    f_chk = 0;
end

% Check if G is finite
if isfinite(G)== ones(size(G))
    g_chk = 1;
else
    g_chk = 0;
end

%Displaying matrices F, G, KT
set(handles.fmatrix,'Data',F, 'BackgroundColor',[0.5 1 0.5],'ColumnEditable', false);
set(handles.gmatrix,'Data',G, 'BackgroundColor',[1 1 0.5]  ,'ColumnEditable', false);

if f_chk == 1 && g_chk == 1    
    % clear message box
    set(handles.msgbox, 'String', '')   
        
    % Enable NEXT button
    set(handles.nextbutt, 'Enable', 'on')
    
    % Display decoupled system
    dsys = sfbd_gen(SSsys, F, G);
    dsys_text = evalc('dsys');
    tlines = strsplit(dsys_text,'\n');
    set(handles.dmoddisplay,'FontName', 'Monospaced', 'String',tlines);
else
    emessage = 'Multivar 1.0: ';
    emessage1 =  'F matrix is not finite.';
    emessage2 =  'G matrix is not finite.';
    if f_chk == 0
        emessage = [emessage, emessage1];
    end
    if g_chk == 0
        emessage = [emessage, emessage2];
    end
    set(handles.msgbox, 'String', emessage)
    
    % disable NEXT button
    set(handles.nextbutt, 'Enable', 'off')
end



% --- Executes when selected cell(s) is changed in KTmatrix.
function KTmatrix_CellSelectionCallback(hObject, eventdata, handles)
% hObject    handle to KTmatrix (see GCBO)
% eventdata  structure with the following fields (see UITABLE)
%	Indices: row and column indices of the cell(s) currently selecteds
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in createestim.
function createestim_Callback(hObject, eventdata, handles)
% hObject    handle to createestim (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% get figure application data
mstruct = getappdata(handles.output, 'gstruct');

% Get model for decoupling from gui/figure application data
SSsys = getappdata(handles.output, 'modfordecop');

% Save decoupling info
% Get data from table
KTdata = get(handles.KTmatrix, 'Data');
Ke = KTdata(:,1);
Te = KTdata(:,2);

% perform state feedback decoupling
[F, G] = sfbd(SSsys, Ke', Te');
dsys = sfbd_gen(SSsys, F, G);

mstruct.decopinfo = {F, G, SSsys, dsys};

% Update control model
mstruct.controlmodel = dsys;

% Update window position in structure
mstruct.windowposition = get(gcf,'OuterPosition');

% Update root application data
setappdata(0, 'mlvappdata', mstruct);

% Activate new GUI window and close the last window
set(sfbdec2, 'Visible', 'On');
set(handles.output, 'Visible', 'Off');

% Update handles structure
guidata(hObject, handles);
