function varargout = robindex(varargin)
% ROBINDEX  Plots the input and output complementary sensitivity and sensitvity
% functions of a svd decoupled and controlled MIMO system.
%
% SYNTAX
% iiplot(SYS)
% (a)   robindex(Ti, Si, To, So) plots the input and output complementary and
%       sensitvity functions on 4 subplots.
%        
% (b)   [msvti, msvto, msvsi, msvso, wti, wto, wsi, wso] = robindex(Ti, Si, To, So)
%       returns 
%       1)  the vector of input complementary sensitivity values, msvti
%           and the corresponding vector of frequency values, wti
%       2)  the vector of output complementary sensitivity values msvto
%           and the corresponding vector of frequency values, wto.
%       3)  the vector of input sensitivity values msvsi
%           and the corresponding vector of frequency values, wsi.
%       4)  the vector of output sensitivity values msvso  
%           and the corresponding vector of frequency values, wsi.
% (c)   [msvti, msvto, msvsi, msvso] = robindex(Ti, Si, To, So, wti, wto, wsi, wso) 
%       returns the vectors msvti, msvto, msvsi and msvso 
%       that would have been plotted for the frequencies wti, wto, wsi, wso in 
%       the  robustness performance and stability margins versus frequency plots.

% *************************************************************************
% Author:           Crystal Blackwell 
% Email:            Crystal.Blackwell@sta.uwi.edu
% Created:          January 2013; 
% Last revision:    29-June-2013;
% Useful websites:
%
% MATLAB VERSIONS USED IN PROGRAMMING PROCESS: 
% - MATLAB R2013a
%
% *************************************************************************
% NATIVE MATLAB FUNCTIONS USED TO CREATE THIS FUNCTION:
% sigma             size                max                 eye
% plot              subplot             gca                 xlabel
% ylabel            title               set                 eye
% *************************************************************************

    % Check number of outputs
    if nargout ==0 ||  nargout == 4 || nargout == 8
        
        % Check number of inputs
        if nargin == 4 || nargin == 8
            Ti = varargin{1};
            Si = varargin{2};
            To = varargin{3};               
            So = varargin{4};

            if nargin == 8
                wti = varargin{5};
                wto = varargin{6};
                wsi = varargin{7};
                wso = varargin{8};
                svti = sigma(Ti, wti);
                svsi = sigma(Si, wsi);
                svto = sigma(To, wto);
                svso = sigma(So, wso);
            else
                % Obtain vector of singular values and frequency values
                [svti,wti] = sigma(Ti);
                [svsi,wsi] = sigma(Si);
                [svto,wto] = sigma(To);
                [svso,wso] = sigma(So);
            end

            % Input uncertainty
            msvti =   1./max(svti);
            msvsi =   1./max(svsi);

            % Output uncertainty
            msvto =   1./max(svto);
            msvso =   1./max(svso);


            switch nargout
                case 0 % if no output argument, generate plot
                    subplot(2, 2, 1)
                    plot(wti, msvti)
                    set(gca,'XScale','log','YScale','log','FontName','Helvetica','FontSize',8, 'XColor', [0.4 0.4 0.4], 'YColor', [0.4 0.4 0.4]);
                    ylabel('{\sigma}_m_a_x({\Delta}_i(j{\omega})) for Complementary Sensitivity function T', 'Color', [0 0 0])
                    xlabel('Frequency (rads/s)', 'Color', [0 0 0])

                    subplot(2, 2, 2)
                    plot(wto, msvto)
                    set(gca,'XScale','log','YScale','log','FontName','Helvetica','FontSize',8, 'XColor', [0.4 0.4 0.4], 'YColor', [0.4 0.4 0.4]);
                    ylabel('{\sigma}_m_a_x({\Delta}_o(j{\omega})) for Complementary Sensitivity function T', 'Color', [0 0 0])
                    xlabel('Frequency (rads/s)', 'Color', [0 0 0])

                    subplot(2, 2, 3)
                    plot(wsi, msvsi)
                    set(gca,'XScale','log','YScale','log','FontName','Helvetica','FontSize',8, 'XColor', [0.4 0.4 0.4], 'YColor', [0.4 0.4 0.4]);
                    ylabel('{\sigma}_m_a_x({\Delta}_i(j{\omega})) for Sensitivity function S', 'Color', [0 0 0])
                    xlabel('Frequency (rads/s)', 'Color', [0 0 0])

                    subplot(2, 2, 4)
                    plot(wso, msvso)
                    set(gca,'XScale','log','YScale','log','FontName','Helvetica','FontSize',8, 'XColor', [0.4 0.4 0.4], 'YColor', [0.4 0.4 0.4]);
                    ylabel('{\sigma}_m_a_x({\Delta}_o(j{\omega})) for Sensitivity function S', 'Color', [0 0 0])
                    xlabel('Frequency (rads/s)', 'Color', [0 0 0])

                case 4
                    varargout{1}= msvti;
                    varargout{2}= msvto;
                    varargout{3}= msvsi;
                    varargout{4}= msvso;
                case 8 
                    varargout{1}= msvti;
                    varargout{2}= msvto;
                    varargout{3}= msvsi;
                    varargout{4}= msvso;
                    varargout{5}= wti;
                    varargout{6}= wto;
                    varargout{7}= wsi;
                    varargout{8}= wso;             
                otherwise
            end
        else
            % Display error if incorrect number of inputs
            error('Incorrect number of inputs')
        end
    else
           % Display error if incorrect number of outputs
            error('Incorrect number of outputs')
    end 
end