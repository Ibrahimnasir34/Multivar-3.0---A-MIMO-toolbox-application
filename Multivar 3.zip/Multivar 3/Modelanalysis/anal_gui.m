function varargout = anal_gui(varargin)
% ANAL_GUI MATLAB code for anal_gui.fig
%      ANAL_GUI, by itself, creates a new ANAL_GUI or raises the existing
%      singleton*.
%
%      H = ANAL_GUI returns the handle to a new ANAL_GUI or the handle to
%      the existing singleton*.
%
%      ANAL_GUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in ANAL_GUI.M with the given input arguments.
%
%      ANAL_GUI('Property','Value',...) creates a new ANAL_GUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before anal_gui_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to anal_gui_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help anal_gui

% Last Modified by GUIDE v2.5 30-May-2014 18:21:06

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @anal_gui_OpeningFcn, ...
                   'gui_OutputFcn',  @anal_gui_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before anal_gui is made visible.
function anal_gui_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to anal_gui (see VARARGIN)

% Choose default command line output for anal_gui
handles.output = hObject;

% Get root application data
mstruct = getappdata(0, 'mlvappdata');

% Set position and size and title
set(handles.output, 'OuterPosition',mstruct.windowposition, 'Name', mstruct.gtitle);

% Set handle of previous page as gui/figure application data
setappdata(handles.output,'hprevpage',mstruct.phandlerecord(length(mstruct.phandlerecord)));

% Update the page handle record in the structure and then save structure as root application data
mstruct.phandlerecord = [mstruct.phandlerecord, handles.output];
setappdata(0, 'mlvappdata', mstruct)

% set struct from root application data as gui/figure application data
setappdata(handles.output, 'gstruct', mstruct);

% Set Defaults
% have no button selected
set(handles.abgroup,'SelectedObject', []); 

% Determine type of model
tmod = mstruct.modnum;

% Enable or disable buttons and post message
switch tmod
    case 1 % tf systems with time delays
        set(handles.to_pzio, 'Enable', 'off');
        set(handles.to_pz, 'Enable', 'off');
        set(handles.to_obs, 'Enable', 'off');
        set(handles.to_ctrb, 'Enable', 'off');
        set(handles.to_tform, 'Enable', 'off'); 
        
        % display message 
        set(handles.msgbox,'String', 'MULTIVAR: System model contains time delays and therefore cannot be analysed by some of the analysis features.');
        
    case 2 % tf systems without time delays 
        % Do nothing
        
    case 4 % ss systems without time delays
        % Do nothing
        
    case 5 % zpk systems with time delays
        set(handles.to_pzio, 'Enable', 'off');
        set(handles.to_pz, 'Enable', 'off');
        set(handles.to_obs, 'Enable', 'off');
        set(handles.to_ctrb, 'Enable', 'off');
        set(handles.to_tform, 'Enable', 'off');
        
        % display message 
        set(handles.msgbox,'String', 'MULTIVAR: System model contains time delays and therefore cannot be analysed by some of the analysis features.'); 
        
    case 6 % zpk systems without time delays
            % Do nothing
    otherwise
        % Disable all buttons
        set(handles.to_pzio, 'Enable', 'off');
        set(handles.to_pz, 'Enable', 'off');
        set(handles.to_imp, 'Enable', 'off');
        set(handles.to_step, 'Enable', 'off');
        set(handles.to_rmp, 'Enable', 'off');
        set(handles.to_para, 'Enable', 'off');
        set(handles.to_bode, 'Enable', 'off');
        set(handles.to_nich, 'Enable', 'off');
        set(handles.to_nyq, 'Enable', 'off');
        set(handles.to_gnyq, 'Enable', 'off');
        set(handles.to_obs, 'Enable', 'off');
        set(handles.to_ctrb, 'Enable', 'off');
        set(handles.to_tform, 'Enable', 'off');
        set(handles.to_ss_struct, 'Enable', 'off');
        set(handles.to_fd_struct, 'Enable', 'off');
        set(handles.to_svdpairing, 'Enable', 'off');
        set(handles.to_rgapairing, 'Enable', 'off');
        
        % display message 
        set(handles.msgbox,'String', 'MULTIVAR: System model cannot be analysed by any of the analysis features.');
       
end

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes anal_gui wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = anal_gui_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in to_ctrlsyn.
function to_ctrlsyn_Callback(hObject, eventdata, handles)
% hObject    handle to to_ctrlsyn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get position struct from gui/figure application data.
mstruct = getappdata(handles.output, 'gstruct');

% Update window position in structure
mstruct.windowposition = get(gcf,'OuterPosition');

% Update root application data
setappdata(0, 'mlvappdata', mstruct);

% Activate new GUI window and close the last window
set(ctrlsyn, 'Visible', 'On');
set(handles.output, 'Visible', 'Off');

% Update handles structure
guidata(hObject, handles);


% --- Executes on button press in go_back.
function go_back_Callback(hObject, eventdata, handles)
% hObject    handle to go_back (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get structure from gui/figure application data
mstruct = getappdata(handles.output,'gstruct');

% Update/modify structure
% Get rid of the handle of the current figure
mstruct.phandlerecord = mstruct.phandlerecord(1: length(mstruct.phandlerecord) - 1);

% Get position of the current GUI window 
mstruct.windowposition = get(gcf,'OuterPosition');

% Update root application data
setappdata(0, 'mlvappdata', mstruct);

% Get handle of previous page from figure appdata
% Activate previous gui window and delete the handle of the current window
set(getappdata(handles.output,'hprevpage'), 'OuterPosition',mstruct.windowposition,'Visible', 'On');
set(handles.output, 'Visible', 'Off');
delete(handles.output)


% --- Executes when selected object is changed in abgroup.
function abgroup_SelectionChangeFcn(hObject, eventdata, handles)
% hObject    handle to the selected object in abgroup 
% eventdata  structure with the following fields (see UIBUTTONGROUP)
%	EventName: string 'SelectionChanged' (read only)
%	OldValue: handle of the previously selected object or empty if none was selected
%	NewValue: handle of the currently selected object
% handles    structure with handles and user data (see GUIDATA)

% Get Tag of selected object.
bselected = get(handles.abgroup,'SelectedObject'); 

%Code for when the various togglebuttons are selected
switch bselected  
    case handles.to_pzio
            
        % Get struct from gui/figure application data.
        mstruct = getappdata(handles.output, 'gstruct');
        
        % clear message box
        set(handles.msgbox,'String', '');

        % Update window position in structure
        mstruct.windowposition = get(gcf,'OuterPosition');

        % Update root application data
        setappdata(0, 'mlvappdata', mstruct);

        % Clear toggle selection
        set(handles.abgroup,'SelectedObject', []); 

        % Activate new GUI window and close the last window
        set(iopzmimo_gui, 'Visible', 'On');
        set(handles.output, 'Visible', 'Off');

        % Update handles structure
        guidata(hObject, handles);
    
    case handles.to_pz
        % Get struct from gui/figure application data.
        mstruct = getappdata(handles.output, 'gstruct');
        
        % clear message box
        set(handles.msgbox,'String', '');

        % Update window position in structure
        mstruct.windowposition = get(gcf,'OuterPosition');

        % Update root application data
        setappdata(0, 'mlvappdata', mstruct);

        % Clear toggle selection
        set(handles.abgroup,'SelectedObject', []); 

        % Activate new GUI window and close the last window
        set(pzmimo_gui, 'Visible', 'On');
        set(handles.output, 'Visible', 'Off');

        % Update handles structure
        guidata(hObject, handles); 
        
    case handles.to_imp
        % Get struct from gui/figure application data.
        mstruct = getappdata(handles.output, 'gstruct');

        % clear message box
        set(handles.msgbox,'String', '');

        % Update window position in structure
        mstruct.windowposition = get(gcf,'OuterPosition');

        % Update root application data
        setappdata(0, 'mlvappdata', mstruct);

        % Clear toggle selection
        set(handles.abgroup,'SelectedObject', []);         

        % Activate new GUI window and close the last window
        set(impmimo_gui, 'Visible', 'On');
        set(handles.output, 'Visible', 'Off');

        % Update handles structure
        guidata(hObject, handles);        
        
   case handles.to_step
        % Get struct from gui/figure application data.
        mstruct = getappdata(handles.output, 'gstruct');

        % clear message box
        set(handles.msgbox,'String', '');

        % Update window position in structure
        mstruct.windowposition = get(gcf,'OuterPosition');

        % Update root application data
        setappdata(0, 'mlvappdata', mstruct);

        % Clear toggle selection
        set(handles.abgroup,'SelectedObject', []); 

        % Activate new GUI window and close the last window
        set(stepmimo_gui, 'Visible', 'On');
        set(handles.output, 'Visible', 'Off');

        % Update handles structure
        guidata(hObject, handles);
       
   case handles.to_rmp
        % Get struct from gui/figure application data.
        mstruct = getappdata(handles.output, 'gstruct');

        % clear message box
        set(handles.msgbox,'String', '');

        % Update window position in structure
        mstruct.windowposition = get(gcf,'OuterPosition');

        % Update root application data
        setappdata(0, 'mlvappdata', mstruct);

        % Clear toggle selection
        set(handles.abgroup,'SelectedObject', []);         

        % Activate new GUI window and close the last window
        set(rmpmimo_gui, 'Visible', 'On');
        set(handles.output, 'Visible', 'Off');

        % Update handles structure
        guidata(hObject, handles);   

   case handles.to_para
        % Get struct from gui/figure application data.
        mstruct = getappdata(handles.output, 'gstruct');

        % clear message box
        set(handles.msgbox,'String', '');

        % Update window position in structure
        mstruct.windowposition = get(gcf,'OuterPosition');

        % Update root application data
        setappdata(0, 'mlvappdata', mstruct);

        % Clear toggle selection
        set(handles.abgroup,'SelectedObject', []);         

        % Activate new GUI window and close the last window
        set(paramimo_gui, 'Visible', 'On');
        set(handles.output, 'Visible', 'Off');

        % Update handles structure
        guidata(hObject, handles);
        
   case handles.to_bode
        % Get struct from gui/figure application data.
        mstruct = getappdata(handles.output, 'gstruct');

        % clear message box
        set(handles.msgbox,'String', '');

        % Update window position in structure
        mstruct.windowposition = get(gcf,'OuterPosition');

        % Update root application data
        setappdata(0, 'mlvappdata', mstruct);

        % Clear toggle selection
        set(handles.abgroup,'SelectedObject', []);         

        % Activate new GUI window and close the last window
        set(bodemimo_gui, 'Visible', 'On');
        set(handles.output, 'Visible', 'Off');

        % Update handles structure
        guidata(hObject, handles);
        
   case handles.to_nich
        % Get struct from gui/figure application data.
        mstruct = getappdata(handles.output, 'gstruct');

        % clear message box
        set(handles.msgbox,'String', '');

        % Update window position in structure
        mstruct.windowposition = get(gcf,'OuterPosition');

        % Update root application data
        setappdata(0, 'mlvappdata', mstruct);

        % Clear toggle selection
        set(handles.abgroup,'SelectedObject', []);         

        % Activate new GUI window and close the last window
        set(nicmimo_gui, 'Visible', 'On');
        set(handles.output, 'Visible', 'Off');

        % Update handles structure
        guidata(hObject, handles);
    
    case handles.to_nyq
        % Get struct from gui/figure application data.
        mstruct = getappdata(handles.output, 'gstruct');

        % clear message box
        set(handles.msgbox,'String', '');

        % Update window position in structure
        mstruct.windowposition = get(gcf,'OuterPosition');

        % Update root application data
        setappdata(0, 'mlvappdata', mstruct);

        % Clear toggle selection
        set(handles.abgroup,'SelectedObject', []);         

        % Activate new GUI window and close the last window
        set(nyqmimo_gui, 'Visible', 'On');
        set(handles.output, 'Visible', 'Off');

        % Update handles structure
        guidata(hObject, handles);

   case handles.to_gnyq
        % Get struct from gui/figure application data.
        mstruct = getappdata(handles.output, 'gstruct');

        % clear message box
        set(handles.msgbox,'String', '');

        % Update window position in structure
        mstruct.windowposition = get(gcf,'OuterPosition');

        % Update root application data
        setappdata(0, 'mlvappdata', mstruct);

        % Clear toggle selection
        set(handles.abgroup,'SelectedObject', []);         

        % Activate new GUI window and close the last window
        set(gennyq_gui, 'Visible', 'On');
        set(handles.output, 'Visible', 'Off');

        % Update handles structure
        guidata(hObject, handles);

    case handles.to_obs
        % Get struct from gui/figure application data.
        mstruct = getappdata(handles.output, 'gstruct');

        % clear message box
        set(handles.msgbox,'String', '');

        % Update window position in structure
        mstruct.windowposition = get(gcf,'OuterPosition');

        % Update root application data
        setappdata(0, 'mlvappdata', mstruct);

        % Clear toggle selection
        set(handles.abgroup,'SelectedObject', []);         

        % Activate new GUI window and close the last window
        set(obsvmat_gui, 'Visible', 'On');
        set(handles.output, 'Visible', 'Off');

        % Update handles structure
        guidata(hObject, handles);

    case handles.to_ctrb
        % Get struct from gui/figure application data.
        mstruct = getappdata(handles.output, 'gstruct');

        % clear message box
        set(handles.msgbox,'String', '');

        % Update window position in structure
        mstruct.windowposition = get(gcf,'OuterPosition');

        % Update root application data
        setappdata(0, 'mlvappdata', mstruct);

        % Clear toggle selection
        set(handles.abgroup,'SelectedObject', []);         

        % Activate new GUI window and close the last window
        set(ctrbmat_gui, 'Visible', 'On');
        set(handles.output, 'Visible', 'Off');

        % Update handles structure
        guidata(hObject, handles);

   case handles.to_tform
        % Get struct from gui/figure application data.
        mstruct = getappdata(handles.output, 'gstruct');

        % clear message box
        set(handles.msgbox,'String', '');

        % Update window position in structure
        mstruct.windowposition = get(gcf,'OuterPosition');

        % Update root application data
        setappdata(0, 'mlvappdata', mstruct);

        % Clear toggle selection
        set(handles.abgroup,'SelectedObject', []);         

        % Activate new GUI window and close the last window
        set(tform_mimo_gui, 'Visible', 'On');
        set(handles.output, 'Visible', 'Off');

        % Update handles structure
        guidata(hObject, handles);

    case handles.to_ss_struct
        % Get struct from gui/figure application data.
        mstruct = getappdata(handles.output, 'gstruct');
        
        % clear message box
        set(handles.msgbox,'String', '');

        % Update window position in structure
        mstruct.windowposition = get(gcf,'OuterPosition');

        % Update root application data
        setappdata(0, 'mlvappdata', mstruct);

        % Clear toggle selection
        set(handles.abgroup,'SelectedObject', []);         

        % Activate new GUI window and close the last window
        set(ss_svdcn_gui, 'Visible', 'On');
        set(handles.output, 'Visible', 'Off');

        % Update handles structure
        guidata(hObject, handles);

    case handles.to_fd_struct
        % Get struct from gui/figure application data.
        mstruct = getappdata(handles.output, 'gstruct');

        % clear message box
        set(handles.msgbox,'String', '');

        % Update window position in structure
        mstruct.windowposition = get(gcf,'OuterPosition');

        % Update root application data
        setappdata(0, 'mlvappdata', mstruct);

        % Clear toggle selection
        set(handles.abgroup,'SelectedObject', []);         

        % Activate new GUI window and close the last window
        set(frq_svdcn_gui, 'Visible', 'On');
        set(handles.output, 'Visible', 'Off');

        % Update handles structure
        guidata(hObject, handles);

    case handles.to_svdpairing
        % Get struct from gui/figure application data.
        mstruct = getappdata(handles.output, 'gstruct');

        % clear message box
        set(handles.msgbox,'String', '');

        % Update window position in structure
        mstruct.windowposition = get(gcf,'OuterPosition');

        % Update root application data
        setappdata(0, 'mlvappdata', mstruct);

        % Clear toggle selection
        set(handles.abgroup,'SelectedObject', []);         

        % Activate new GUI window and close the last window
        set(fr_svd_gui, 'Visible', 'On');
        set(handles.output, 'Visible', 'Off');

        % Update handles structure
        guidata(hObject, handles); 
        
   case handles.to_rgapairing
        % Get struct from gui/figure application data.
        mstruct = getappdata(handles.output, 'gstruct');

        % clear message box
        set(handles.msgbox,'String', '');

        % Update window position in structure
        mstruct.windowposition = get(gcf,'OuterPosition');

        % Update root application data
        setappdata(0, 'mlvappdata', mstruct);

        % Clear toggle selection
        set(handles.abgroup,'SelectedObject', []);         

        % Activate new GUI window and close the last window
        set(fr_rga_gui, 'Visible', 'On');
        set(handles.output, 'Visible', 'Off');

        % Update handles structure
        guidata(hObject, handles);
       
    otherwise
end


% --- Executes when user attempts to close figure1.
function figure1_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: delete(hObject) closes the figure

% display a question dialog box 
selection = questdlg('Are you sure you want to close Multivar?','Close Request Function','Yes','No','Yes'); 

switch selection, 
    case 'Yes'     
        % delete all figures related to multivar
          mstruct = getappdata(handles.output,'gstruct');  
          delete(mstruct.phandlerecord) 
          exit_multivar
    case 'No'
       % Do nothing
end



function msgbox_Callback(hObject, eventdata, handles)
% hObject    handle to msgbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of msgbox as text
%        str2double(get(hObject,'String')) returns contents of msgbox as a double


% --- Executes during object creation, after setting all properties.
function msgbox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to msgbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
