function varargout = sfbctrl3(varargin)
% SFBCTRL3 M-file for sfbctrl3.fig
%      SFBCTRL3, by itself, creates a new SFBCTRL3 or raises the existing
%      singleton*.
%
%      H = SFBCTRL3 returns the handle to a new SFBCTRL3 or the handle to
%      the existing singleton*.
%
%      SFBCTRL3('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in SFBCTRL3.M with the given input arguments.
%
%      SFBCTRL3('Property','Value',...) creates a new SFBCTRL3 or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before sfbctrl3_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to sfbctrl3_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help sfbctrl3

% Last Modified by GUIDE v2.5 09-Apr-2014 15:53:58

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @sfbctrl3_OpeningFcn, ...
                   'gui_OutputFcn',  @sfbctrl3_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before sfbctrl3 is made visible.
function sfbctrl3_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to sfbctrl3 (see VARARGIN)

% Choose default command line output for sfbctrl3
handles.output = hObject;

% Get root application data
mstruct = getappdata(0, 'mlvappdata');

% Set position and size and title
set(handles.output, 'OuterPosition',mstruct.windowposition, 'Name', mstruct.gtitle);

% Set handle of previous page as gui/figure application data
setappdata(handles.output,'hprevpage',mstruct.phandlerecord(length(mstruct.phandlerecord)));

% Update the page handle record in the structure and then save structure as root application data
mstruct.phandlerecord = [mstruct.phandlerecord, handles.output];
setappdata(0, 'mlvappdata', mstruct)

% set struct from root application data as gui/figure application data
setappdata(handles.output, 'gstruct', mstruct);

% Setting defaults
SSsys = mstruct.controlinfo{3};
csys = mstruct.controlinfo{4};

% Set model (exact or approximate) for decoupling as gui/figure application data
setappdata(handles.output, 'modforctrl', SSsys);

% Setting decoupled model as application data
setappdata(handles.output, 'ctrlsys', csys)

string_list{1} = 'Step Response';
string_list{2} = 'Impulse Response';
string_list{3} = 'Ramp Response';
string_list{4} = 'Parabolic Response';
set(handles.popmen,'String',string_list)
set(handles.popmen,'Value', 1)

% Displaying previous step response
horig = subplot(1,2,1); step(SSsys);
title('Step Response of system before control was added');

% Displaying decoupled step response
hctrl = subplot(1,2,2); step(csys);
title('Step Response of Controlled System');

% save handles of subplots as gui application data
setappdata(handles.output, 'hsplots', [horig , hctrl])

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes sfbctrl3 wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = sfbctrl3_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in goback.
function goback_Callback(hObject, eventdata, handles)
% hObject    handle to goback (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get position struct from gui/figure application data.
mstruct = getappdata(handles.output, 'gstruct');

% Update/modify structure
% Get rid of the handle of the current figure
mstruct.phandlerecord = mstruct.phandlerecord(1: length(mstruct.phandlerecord) - 1);

% Get position of the current GUI window 
mstruct.windowposition = get(gcf,'OuterPosition');

% Update root application data
setappdata(0, 'mlvappdata', mstruct);

% Get handle of previous page from figure appdata
% Activate previous gui window and delete the handle of the current window
set(getappdata(handles.output,'hprevpage'), 'OuterPosition',mstruct.windowposition,'Visible', 'On');
set(handles.output, 'Visible', 'Off');
delete(handles.output)


% --- Executes when user attempts to close figure1.
function figure1_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: delete(hObject) closes the figure

% display a question dialog box 
selection = questdlg('Are you sure you want to close Multivar?','Close Request Function','Yes','No','Yes'); 

switch selection, 
    case 'Yes'     
        % delete all figures related to multivar
          mstruct = getappdata(handles.output,'gstruct');  
          delete(mstruct.phandlerecord) 
          exit_multivar
    case 'No'
       % Do nothing
end


% --- Executes on selection change in popmen.
function popmen_Callback(hObject, eventdata, handles)
% hObject    handle to popmen (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popmen contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popmen


% Get model (exact or approximate) for decoupling from gui/figure application data
csys = getappdata(handles.output, 'ctrlsys');
SSsys = getappdata(handles.output, 'modforctrl');

% Determine selected value
val = get(handles.popmen,'Value');

%Code for when the various togglebuttons are selected
switch val 
    case 1
            % Displaying previous step response
            horig = subplot(1,2,1); step(SSsys);
            title('Step Response of system before control was added');

            % Displaying decoupled step response     
            hctrl = subplot(1,2,2); step(csys);
            title('Step Response of Controlled System');
            
    case 2
            % Displaying previous impulse response          
            horig = subplot(1,2,1); impulse(SSsys);
            title('Impulse Response of system before control was added');

            % Displaying decoupled impulse response     
            hctrl = subplot(1,2,2); impulse(csys);
            title('Impulse Response of Controlled System');
       
    case 3           
            % Displaying previous ramp response           
            horig = subplot(1,2,1); mlvramp(SSsys);
            title('Ramp Response of system before control was added');

            % Displaying decoupled ramp response
            hctrl = subplot(1,2,2); mlvramp(csys);
            title('Ramp Response of Controlled System');
            
    case 4           
            % Displaying previous parabolic response           
            horig = subplot(1,2,1); mlvpara(SSsys);
            title('Parabolic Response of system before control was added');

            % Displaying decoupled parabolic response
            hctrl = subplot(1,2,2); mlvpara(csys);
            title('Parabolic Response of Controlled System');                
        
    otherwise
end

if get(handles.gridctrl,'Value')== 1
    axes(horig)
    grid on
    axes(hctrl)
    grid on
else
    axes(horig)
    grid off
    axes(hctrl)
    grid off
end

setappdata(handles.output, 'hsplots', [horig , hctrl])

% Update handles structure
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function popmen_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popmen (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function msgbox_Callback(hObject, eventdata, handles)
% hObject    handle to msgbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of msgbox as text
%        str2double(get(hObject,'String')) returns contents of msgbox as a double


% --- Executes during object creation, after setting all properties.
function msgbox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to msgbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in nextbutt.
function nextbutt_Callback(hObject, eventdata, handles)
% hObject    handle to nextbutt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get original model from figure application data
mstruct = getappdata(handles.output,'gstruct');

% Update window position in structure
mstruct.windowposition = get(gcf,'OuterPosition');

% Activate new GUI window and close the last window
% To Control system evaluation page
set(cevalmimo_gui, 'Visible', 'On');
set(handles.output, 'Visible', 'Off');

% Update handles structure
guidata(hObject, handles);


% --- Executes on button press in gridctrl.
function gridctrl_Callback(hObject, eventdata, handles)
% hObject    handle to gridctrl (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of gridctrl

if get(handles.gridctrl,'Value')== 1
    splothand = getappdata(handles.output, 'hsplots');
    axes(splothand(1))
    grid on
    axes(splothand(2))
    grid on
else
    splothand = getappdata(handles.output, 'hsplots');
    axes(splothand(1))
    grid off
    axes(splothand(2))
    grid off
end
