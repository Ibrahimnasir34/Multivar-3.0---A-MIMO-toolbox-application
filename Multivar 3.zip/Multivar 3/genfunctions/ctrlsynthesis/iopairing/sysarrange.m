function resys = sysarrange(sys,tpairing)
% SYSARRANGE  rearranging the ordering of the inputs and outputs of a MIMO 
% system depending on the pairing table.
%
% SYNTAX
% RESYS = iosnames(SYS) takes a MIMO system of type tf, zpk and ss and
% rearranges the inputs annd outputs according to the pairing table. The
% rearraanged model RESYS is returned.
% % See also IOSNAMES.

% *************************************************************************
% Author:           Crystal Blackwell 
% Email:            Crystal.Blackwell@sta.uwi.edu
% Created:          January 2013; 
% Last revision:    29-June-2013;
% Useful websites:
%
% MATLAB VERSIONS USED IN PROGRAMMING PROCESS: 
% - MATLAB R2013a
%
% *************************************************************************
% NATIVE MATLAB FUNCTIONS USED TO CREATE THIS FUNCTION:
% size                      length                      unique
% sortrows                  setdiff                     zeros
% *************************************************************************
% MULTIVAR FUNCTIONS USED TO CREATE THIS FUNCTION:
% iosnames                  modtyptest
% *************************************************************************

    % Check for correct number of output arguments
    if nargout <= 1
        % Check for correct number of input arguments
        if nargin == 2 
            % determines the type of system and sets flag
            modnum = modtyptest(sys);   
            if modnum == 1 || modnum == 2 || modnum == 4 || modnum == 5 || modnum == 6 
                cflag = 1;
            else
                cflag = 0;
            end

            % Determine dimensions of system
            [m,p] = size(sys);
            % Check if pairing table is valid in size
            [x,y] = size(tpairing);    % get size of pairing table    
            if p <= m % no of inputs is smaller or equal to no of outputs
                if x == p && y == 2
                    size_chk = 1;
                else
                    size_chk = 0;
                end
            else
                if x == m && y == 2
                    size_chk = 1;
                else
                    size_chk = 0;
                end
            end

            % Check for repeated values in the inputs
            if length(unique(tpairing(:,1))) < length(tpairing(:,1))
                inpchk = 0;
            else
                inpchk = 1;
            end

            % Check for repeated values in the outputs
            if length(unique(tpairing(:,2))) < length(tpairing(:,2))
                outpchk = 0;
            else
                outpchk = 1;
            end 

            % Check if data in pairing table is valid
            % numeric and finite
            % in the range of inputs and outputs


            if cflag ==1 && size_chk == 1 && inpchk == 1 && outpchk == 1 % if inputs are valid
                % Name the un-named inputs and outputs
                sys = iosnames(sys);     

                % sort pairing table
                if p <= m % no of inputs is smaller or equal to no of outputs
                    % sort according to inputs column
                    tpairing = sortrows(tpairing,1);
                    
                    % extract vector of outputs from pairing table
                    outorder = tpairing(:,2);
                    allout = (1:1: m)';
                    drestout = setdiff(allout, outorder);
                    coutorder = (vertcat(outorder, drestout'))';
                else
                    % sort according to outputs column
                    tpairing = sortrows(tpairing,2); 
                    
                    % extract vector of inputs from pairing table
                    inorder = tpairing(:,1);
                    allin = (1:1: p)';
                    drestin = setdiff(allin, inorder);
                    cinorder = (vertcat(inorder, drestin))';  
                end

                % for ss systems
                if modnum == 4
                    % extract matrices from ss
                    A = sys.a;    
                    B = sys.b;
                    C = sys.c;
                    D = sys.d;
                    Iname = sys.InputName;
                    Oname = sys.OutputName;
                    Sname = sys.StateName;


                    if p <= m % no of inputs is smaller or equal to no of outputs
                        % sort rows according to vector
                        C = C(coutorder, :);
                        D = D(coutorder, :);
                        Oname = Oname(coutorder, :);                        

                    else % no of outputs is smaller
                        % sort columns according to vector                        
                        B = B(:, cinorder);
                        D = D(:, cinorder);
                        % sort rows according to vector (Note: Variable ames are
                        % always in column form)
                        Iname = Iname(cinorder, :);
                    end

                    resys = ss(A,B,C,D);
                    resys.InputName = Iname;
                    resys.OutputName = Oname;
                    resys.StateName = Sname;
                end


                % for tf and zpk systems
                if modnum == 1 || modnum == 2 || modnum == 5 || modnum == 6 
                    
                    if p <= m % if no of inputs is smaller or equal to no of outputs
                        
                        % sort rows according to vector
                        resys = sys(coutorder, :);
                        
                    else % if no of outputs is smaller
                   
                        % sort columns according to vector
                        resys = sys(:, cinorder);
                    end      
                end
                
            else
                emessage = 'Multivar 1.0:';
                if cflag == 0
                    emessage = [emessage, 'Input system model is incompatible with this function. '];
                end
                if size_chk == 0 
                    emessage = [emessage, 'Pairing table is of incorrect size. '];
                end
                if inpchk == 0
                    emessage = [emessage, 'Repeated inputs are present in pairing table. '];
                end
                if outpchk == 0
                    emessage = [emessage, 'Repeated outputs are present in pairing table. '];
                end 
                error(emessage)
            end
        else
            % Display error if incorrect number of inputs
            narginchk(2, 2)
        end
    else
        % Display error if incorrect number of outputs
        nargoutchk(0, 1)
    end            
end