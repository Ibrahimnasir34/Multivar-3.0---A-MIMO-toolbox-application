function varargout = multivar(varargin)
% MULTIVAR MATLAB code for multivar.fig
%      MULTIVAR, by itself, creates a new MULTIVAR or raises the existing
%      singleton*.
%
%      H = MULTIVAR returns the handle to a new MULTIVAR or the handle to
%      the existing singleton*.
%
%      MULTIVAR('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in MULTIVAR.M with the given input arguments.
%
%      MULTIVAR('Property','Value',...) creates a new MULTIVAR or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before multivar_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to multivar_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help multivar

% Last Modified by GUIDE v2.5 25-Jul-2014 10:33:02

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @multivar_OpeningFcn, ...
                   'gui_OutputFcn',  @multivar_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before multivar is made visible.
function multivar_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to multivar (see VARARGIN)

% Choose default command line output for multivar
handles.output = hObject;

% Setting title bar
Mfolder = which('multivar');
[mlvpath, name, ext] = fileparts(Mfolder); 
[vpath, verprog, vext] = fileparts(mlvpath);
gtitle = [verprog, ': A MIMO Toolbox'];

% Set position and size and title
set(0, 'Units', 'normalized')
scsz = get(0, 'ScreenSize');
scaling = 0.7;
posl  = scsz(3)-scaling;
posb = scsz(4)-scaling;
set(handles.output, 'OuterPosition',[posl, posb, scaling, scaling], 'Name', gtitle);
movegui(gcf,'northeast')

% have no option button selected
set(handles.selmode,'SelectedObject', []); 

% Display License
fileID = fopen('license.txt','r');
ftext = fscanf(fileID, '%c');
fclose(fileID);
licstrings = strsplit(ftext, '\n');
set(handles.licdisp,'FontName', 'Monospaced', 'String', licstrings);


% Setting GUI page application data
setappdata(handles.output, 'mlvpath', mlvpath);
setappdata(handles.output, 'verprog', verprog);
setappdata(handles.output, 'gtitle', gtitle);

% Display picture in axes
subplot(handles.axes1)
imshow('dpic.jpg')

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes multivar wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = multivar_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on selection change in licdisp.
function licdisp_Callback(hObject, eventdata, handles)
% hObject    handle to licdisp (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns licdisp contents as cell array
%        contents{get(hObject,'Value')} returns selected item from licdisp


% --- Executes during object creation, after setting all properties.
function licdisp_CreateFcn(hObject, eventdata, handles)
% hObject    handle to licdisp (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes when selected object is changed in selmode.
function selmode_SelectionChangeFcn(hObject, eventdata, handles)
% hObject    handle to the selected object in selmode 
% eventdata  structure with the following fields (see UIBUTTONGROUP)
%	EventName: string 'SelectionChanged' (read only)
%	OldValue: handle of the previously selected object or empty if none was selected
%	NewValue: handle of the currently selected object
% handles    structure with handles and user data (see GUIDATA)

mselected = get(handles.selmode,'SelectedObject'); 

%Code for when the various togglebuttons are selected
switch mselected     
    case handles.gmode 
        if get(handles.lcheck,'Value')== 1
            set(handles.msgbox, 'String', 'Initiating GUI mode...');
            mstruct = getappdata(0, 'mlvappdata'); % get multivar data structure
            if isempty(mstruct) == 1 % multivar is not already activated i.e. data structure is empty
                mlvpath = getappdata(handles.output, 'mlvpath');
                verprog = getappdata(handles.output, 'verprog');
                gtitle = getappdata(handles.output, 'gtitle');

                % Preallocate and set initial values of general application data
                mstruct.mlvlocation = mlvpath; % store location of the multivar toolbox folder
                mstruct.mlvstring = verprog; % store string containing name and version of the toolbox
                mstruct.gtitle = gtitle; % store title for GUI pages
                mstruct.phandlerecord = []; % stores handles of open gui pages to assist in navigation
                mstruct.windowposition = []; % stores location and dimensions of the current gui page
                mstruct.projectpath = []; % stores folder path for project folder
                mstruct.matfile = []; % stores filename of .mat file (includes .mat extension)
                mstruct.savemodelpath = []; % store entire file path for .mat file
                mstruct.systemmodel = []; % stores the original system model
                mstruct.approxmodel = []; % stores the approximation/conversion of the original system model
                mstruct.arrsysmodel = []; % stores the rearranged system model (modification of the original system model to satisfy the i/o pairing table
                mstruct.arrapproxmodel = []; % stores the rearranged approximated/converted system model (modification of the approximation/conversion system model to satisfy the i/o pairing table
                mstruct.iopairing = []; % stores the i/o pairing table
                mstruct.controlmodel = []; % stores the control model during control synthesis    
                mstruct.controlsyn = {}; % sets the decoupling and control actions of the control synthesis sequence
                mstruct.decopinfo = {}; % stores the results of the decoupling portion of the control synthesis sequence
                mstruct.controlinfo = {}; % stores the results of the controller portion of the control synthesis sequence
                mstruct.modnum = 0; % stores number indicating class of system model    

                mstruct.mlvmode = 1; % stores current mode of multivar operation
                setappdata(0, 'mlvappdata', mstruct)

                mstruct2.iopairing = []; % Preallocate structure of analysis application data
                setappdata(0, 'mlvanaldata', mstruct2)

                allfolders = genpath(mlvpath); % generates the paths of all subfolders and files in the multivar folder
                addpath(allfolders); % Add folders to path


                % *****Close dialog and open Multivar
                % hide prompt window
                set(handles.output, 'Visible', 'off')  

                % Display message in command window
                disp('MULTIVAR GUI MODE ACTIVATED.')

                % Open GUI mode start page
                set(mmain,'Visible', 'On') 

                % Close prompt window
                delete(handles.output) 

            else % if multivar is already activated
                % Display appropriate message in command window
                switch mstruct.mlvmode 
                    case 1
                        disp('Multivar is already open in GUI mode.')
                    case 2
                        disp('Multivar is already open in Function mode.')
                        disp('To exit the Function mode at a later time, type "exit_multivar" in the Command Window and then press Enter.')
                    otherwise
                end      

                % Close prompt window
                delete(handles.output)
            end    
        else
            % Display message
            set(handles.msgbox, 'String', 'Please read and agree to the license agreement before use.');
            % have no option button selected
            set(handles.selmode,'SelectedObject', []); 
        end
    case handles.fmode  
        if get(handles.lcheck,'Value')== 1
            set(handles.msgbox, 'String', 'Initiating Function mode...');
            mstruct = getappdata(0, 'mlvappdata');      
            if isempty(mstruct) == 1 % if multivar is not activated

                % Get gui page application data
                mlvpath = getappdata(handles.output, 'mlvpath');
                verprog = getappdata(handles.output, 'verprog');

                % Preallocate and set initial values of general application data            
                mstruct.mlvlocation = mlvpath;
                mstruct.mlvstring = verprog; % store string containing name and version of the toolbox            
                mstruct.mlvmode = 2;

                % Set overall application data
                setappdata(0, 'mlvappdata', mstruct)

                % Add folders to path
                gfpath = [mlvpath, '\genfunctions'];
                allfolders = genpath(gfpath);
                addpath(allfolders);

                %*****Close dialog and display message in command window
                % hide prompt window
                set(handles.output, 'Visible', 'off') 

                % Display message in command window
                disp('MULTIVAR FUNCTION MODE ACTIVATED.') 
                disp('To exit the Function mode at a later time, type "exit_multivar" in the Command Window and then press Enter.')
                
                % Close prompt window
                delete(handles.output) 

            else % if multivar is already activated  
                 % Display appropriate message in command window
                switch mstruct.mlvmode 
                    case 1
                        disp('Multivar is already open in GUI mode.')
                    case 2
                        disp('Multivar is already open in Function mode.')
                        disp('To exit the Function mode at a later time, type "exit_multivar" in the Command Window and then press Enter.')
                    otherwise
                end    

                % Close prompt window
                delete(handles.output) 
            end    
        else
            % Display message
            set(handles.msgbox, 'String', 'Please read and agree to the license agreement before use.');
            % have no option button selected
            set(handles.selmode,'SelectedObject', []);
        end
end


% --- Executes on button press in lcheck.
function lcheck_Callback(hObject, eventdata, handles)
% hObject    handle to lcheck (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of lcheck

if get(handles.lcheck,'Value')== 1
        set(handles.msgbox, 'String', '');
else
    set(handles.msgbox, 'String', 'Please read and agree to the license agreement before use.');
end


function msgbox_Callback(hObject, eventdata, handles)
% hObject    handle to msgbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of msgbox as text
%        str2double(get(hObject,'String')) returns contents of msgbox as a double


% --- Executes during object creation, after setting all properties.
function msgbox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to msgbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
