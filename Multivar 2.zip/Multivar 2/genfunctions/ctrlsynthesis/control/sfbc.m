function [K, N]= sfbc(sys, dpoles)
% SFBC  generates the state feedback gain matrix, K and the input gain 
% matrix, N for a state feedback control design determined via pole placement.
% 
% SYNTAX
% [K, N]= sfbc(sys, dpoles) returns a state feedback gain matrix, K and the
% input gain matrix, N after inputing the system model which must contain 
% no delays and a vector of poles.
% See also SFBC_GEN.

% *************************************************************************
% Author:           Crystal Blackwell 
% Email:            Crystal.Blackwell@sta.uwi.edu
% Created:          January 2013; 
% Last revision:    29-June-2013;
% Useful websites:
%
% MATLAB VERSIONS USED IN PROGRAMMING PROCESS: 
% - MATLAB R2013a
%
% *************************************************************************
% NATIVE MATLAB FUNCTIONS USED TO CREATE THIS FUNCTION:
% nargin                    nargout                     error
% narginchk                 nargoutchk                  size
% length                    ss                          place
% horzcat                   vertcat                     zeros
% eye                       pinv  
% *************************************************************************
% MULTIVAR FUNCTIONS USED TO CREATE THIS FUNCTION:
% modtyptest   
% *************************************************************************

    % Check for correct number of output arguments
    if nargout == 2
        
        % Check for correct number of input arguments
        if nargin == 2

            % Check type of model
            modnum = modtyptest(sys);
            if modnum == 2 || modnum == 4 || modnum == 6
                cflag = 1; % set cflag high
                if modnum == 4  % if system is a state space model
                    % Do nothing
                else
                    sys = ss(sys); % Convert to state space
                end
            else
                cflag = 0; % set cflag low
            end

            % Extract state space matrices
            A = sys.a;
            B = sys.b;
            C = sys.c;
            D = sys.d;

            
            n = length(A);
            [m,p] = size(sys);
            
            % Check validity of the pole vector
            pvl = length(dpoles);
            if n == pvl && isvector(dpoles) == 1 && isnumeric(dpoles) == 1 % if vector of poles is the right size and a vector
                pvflag = 1;
            else
                pvflag = 0;
            end
            
            if cflag == 1 && pvflag ==1 % if both inputs are acceptable

                % Pole placement for controller
                K = place(A,B,dpoles); 

                % Determining input matrix
                AB = horzcat(A,B);
                CD = horzcat(C,D);
                ABCD = vertcat(AB, CD);        

                if m < p % if no of outputs is less than number of inputs
                    r = m; % let number of loops be equal to number of outputs
                else
                    r = p; % let number of loops be equal to number of inputs
                end 
                
                ZsOne1 = zeros(n, r);
                ZsOne2 = eye(m, r);
                ZsOne = vertcat(ZsOne1, ZsOne2);

                
                if m == p % if system is square
                    Nxu = ABCD \ ZsOne;
                else % non square
                    Nxu = pinv(ABCD) * ZsOne;
                end                   

                Nx = Nxu(1:n ,:);
                Nu = Nxu((n+1):(n+ p),:);
                N = Nu + (K* Nx);
            else
                 emessage = 'Multivar 1.0:';
                if cflag == 0
                    emessage = [emessage, 'System must be of type tf, ss, or zpk and must not contain time delays. '];
                end
                if pvflag == 0
                    emessage = [emessage, '"dpoles" must be a numeric vector whose length must equal the row size of the "A" matrix of the system. '];
                end                         
                error(emessage)
            end
            
        else
            % Display error if incorrect number of inputs
            narginchk(2, 2)
        end
        
    else
        % Display error if incorrect number of outputs
        nargoutchk(2, 2)
    end
end