function varargout = mlvramp(varargin)
% MLVRAMP  Ramp response of dynamic systems. 
%
% SYNTAX
% (a)   mlvramp (with no arguments) plots the ramp response of a randomly 
%       generated stable SISO, LTI system. 
% 
% (b)   mlvramp(SYS) plots the ramp response of the dynamic system SYS. For
%       systems with more than one input, independent step commands are 
%       applied to each input-output channel. The time range and number of 
%       points are chosen automatically.
% 
% (c)   mlvramp(SYS,TFINAL) simulates the ramp response from t=0 to the 
%       final time t=TFINAL (expressed in the time units specified in 
%       SYS.TimeUnit). For discrete-time models with unspecified sampling 
%       time, TFINAL is interpreted as the number of samples.
%
% (d)   mlvramp(SYS,T) uses the time vector T for simulation (expressed in 
%       the time units of SYS). For discrete-time models, T should be of 
%       the form Ti:Ts:Tf where Ts is the sampling time. For 
%       continuous-time models, T should be of the form Ti:dt:Tf where dt 
%       is the sampling period for the discrete approximation of SYS. The 
%       ramp input is always assumed to start at t=0 (regardless of Ti).
% 
% (e)   mlvramp(SYS1,SYS2,...,T) plots the ramp response of several systems
%       SYS1,SYS2,... on a single plot. The time vector T is optional. You 
%       can also specify a color, line style, and marker for each system, 
%       for example:
%           mlvramp(sys1,'r',sys2,'y--',sys3,'gx').
% 
% (f)   [Y,T] = mlvramp(SYS) returns the output response Y and the time 
%       vector T used for simulation. No plot is drawn on the screen. If 
%       SYS has NY outputs and NU inputs, and LT = length(T), Y is an array
%       of size [LT NY NU] where Y(:,:,j) gives the ramp response of the 
%       j-th input channel. The time vector T is expressed in the time 
%       units of SYS. 
% 
% (g)   [Y,T,X] = mlvramp(SYS) also returns, for a state-space model SYS, 
%       the state trajectory X, a LT-by-NX-by-NU array if SYS has NX states.
% See also STEP, MLVPARA.

% *************************************************************************
% Author:           Crystal Blackwell 
% Email:            Crystal.Blackwell@sta.uwi.edu
% Created:          January 2013; 
% Last revision:    29-June-2013;
% Useful websites:
%
% MATLAB VERSIONS USED IN PROGRAMMING PROCESS: 
% - MATLAB R2013a
%
% *************************************************************************
% NATIVE MATLAB FUNCTIONS USED TO CREATE THIS FUNCTION:
% step                      tf                          title
% nargin                    nargout                     varargin
% varargout                 round                       rand
% abs                       zpk                         tf
% cell2mat                  disp                        throw
% try                       catch
% *************************************************************************

    multiplier = tf(1, [1 0]);
    % For no output arguments
    if nargout == 0          
            
            % For no input arguments
            if nargin == 0
                % Find the ramp response of a random stable transfer function.
                % Generate values for the order of the system in the range [a, b]
                a = 2;
                b = 9;
                rorder = a + (b-a)* round(rand);
                % Generate number of zero coefficients at the start of the numerator polynomial in the range [1, rorder-1]
                nz = 1 + (rorder-2)* round(rand);

                % Create stable zpk model and convert to tf model
                rzeros = -1 * abs(rand(1,rorder-nz, 'double'));
                rpoles = -1 * abs(rand(1,rorder, 'double'));
                rgain = abs(rand);
                rzpk = zpk(rzeros, rpoles, rgain);
                rmodel = tf(rzpk);

                % Extract numerator and denominator and apply step
                msg1 = ['Here is an example of how the function mlvramp works:', sprintf('\n'), ...
                       'Consider a randomly generated stable Transfer Function Model', sprintf('\n'),...
                       'of the form G(s)=num(s)/den(s):'];
                disp(msg1)  
                num = cell2mat(rmodel.num)
                den = cell2mat(rmodel.den)
                msg2 = ['Call mlvramp using the following command (see also, help mlvramp):',sprintf('\n'),...
                        'mlvramp(tf(num,den));'];
                disp(msg2)

                % Generate plot
                step(rmodel * multiplier)
                title('Ramp Response')        
                
            else
                % Modify input to facilitate use with step function to generate
                % plot of ramp response for specified system
                for k = 1:nargin
                    if isa(varargin{k}, 'ss') ==1 || isa(varargin{k}, 'tf') ==1 || isa(varargin{k}, 'zpk') ==1
                        smodel = varargin{k};
                        inname = smodel.InputName;
                        outname = smodel.OutputName;
                        rmpmodel = varargin{k} * multiplier;
                        rmpmodel.InputName = inname;
                        rmpmodel.OutputName = outname;
                        varargin{k} = rmpmodel;
                    end
                end
                
                try
                    step(varargin{:})
                    title('Ramp Response')                
                catch err
                    throw(err);
                end
            end        
    else
        % Modify input to facilitate use with step function to generate
        % numerical values for ramp response for specified system
        for k = 1:nargin
            if isa(varargin{k}, 'ss') ==1 || isa(varargin{k}, 'tf') ==1 || isa(varargin{k}, 'zpk') ==1
                smodel = varargin{k};
                inname = smodel.InputName;
                outname = smodel.OutputName;
                rmpmodel = varargin{k} * multiplier;
                rmpmodel.InputName = inname;
                rmpmodel.OutputName = outname;
                varargin{k} = rmpmodel;
            end
        end
        
        % Take different actions for different numbers of output arguments
        switch nargout    
            case 1
                % For 1 output arguments
                try
                    varargout{1} = step(varargin{:});  
                catch err
                     throw(err);
                end

            case 2
                % For 2 output arguments
                try
                    [varargout{1},varargout{2}] = step(varargin{:});  
                catch err
                     throw(err);
                end

            case 3
                % For 3 output arguments
                try                
                    [varargout{1},varargout{2}, varargout{3}] = step(varargin{:}); 
                catch err
                     throw(err);
                end

            otherwise
                % If there are too many output arguments then display error message
                try 
                    % Note: varargout{4} activates the error message normally
                    % thrown by step function. 
                    [varargout{1},varargout{2}, varargout{3}, varargout{4}] = step(varargin{:});
                catch err
                     throw(err);
                end
        end
    end
end







