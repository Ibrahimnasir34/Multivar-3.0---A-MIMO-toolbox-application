function nyq = gnyquist(sys)
% GNYQUIST plots the generalised nyquist eigenloci for an LTI MIMO model
%
% SYNTAX
% (a)   gnyquist(SYS) plots the generalised nyquist eigenloci 
%       for an LTI MIMO model SYS. SYS may be a transfer function, zero 
%       pole gain or state space model. 
%
% See also SYS2SYM, SEIG, ARROWH.

% *************************************************************************
% Author:           Crystal Blackwell 
% Email:            Crystal.Blackwell@sta.uwi.edu
% Created:          January 2013; 
% Last revision:    29-June-2013;
% Useful websites:
%
% MATLAB VERSIONS USED IN PROGRAMMING PROCESS: 
% - MATLAB R2013a
%
% *************************************************************************
% NATIVE MATLAB FUNCTIONS USED TO CREATE THIS FUNCTION:
% eval              isfinite        limit               nargin
% nargout           complex         logspace            length
% exp               abs             horzcat             title
% cell              char            real                imag 
% plot              xlabel          ylabel              hold
% eval              eye             syms                size 
% solve             det             simplify
% *************************************************************************
% MULTIVAR FUNCTIONS USED TO CREATE THIS FUNCTION:
% arrowh            sys2sym         modtypetest
% *************************************************************************
% CREDITS: 
% This function is based on the function NYQMIMO produced by the following:
% Creator: Oskar Vivero Osornio (oskar.vivero@gmail.com)
% Created: February 2006; 
% Last revision: 11-May-2006;
% NOTE: The original function by Mr. Vivero can be obtained from the MMT toolbox 
% on the MATLAB File exchange. Changes were made to the program to improve 
% logical flow and in a effort to improve speed and compatibility with 
% later releases of MATLAB such as MATLAB 2013a as well as for its 
% utilisation in the Multivar toolbox.
%
% This function uses the ARROWH function produced by the following
% Creator: Florian Knorn (florian.knorn@student.uni-magdeburg.de)
% Version: 1.14
% Date Produced: June 18th, 2008
% Last Updated:  June 18th, 2008
% Obtained from: MATLAB File exchange
% *************************************************************************

    % Check for correct number of output arguments
    if nargout <= 1
        % Check for correct number of input arguments
        if nargin == 1 

            % determines the type of system and sets flag
            modnum = modtyptest(sys);

            % For tf, ss, zpk systems
            if modnum == 1 || modnum == 2 || modnum == 3 || modnum == 4 || modnum == 5 || modnum == 6 
            
                % For square systems
                if issquare(sys) == 1 

                    % Determine the eigenvalues of the symbolic system
                    G = sys2sym(sys);
                    syms L;
                    I = eye(size(G));
                    LI = L * I;
                    e = solve(det(LI - G) ==0, L);    
                    e = simplify(e);

                    % %------ Check for Singularities on the origin -----
                    % Computes the bidirectional limit of the eigenvalue when p approaches 0

                    lim_zero = eval(limit(e,0));
                    if all(isfinite(lim_zero))== 1
                        sing_zero = 0;
                    else
                        sing_zero = 1;
                    end

                    %-------- Checking for G improper -------
                    % Computes the bidirectional limit of the eigenvalue when p approaches Inf
                    lim_inf = eval(limit(e,Inf));
                    if all(isfinite(lim_inf))== 1
                        sing_inf = 0;
                    else
                        sing_inf = 1;
                    end


                    %-------- Setting Nyquist Contour -------

                    % Amount of points between the initial and final frequency values
                    step = 1000;
                    % Initial Frequency value
                    wi = -3;
                    % Final Frequency value 
                    wf = 6;


                    w = complex(0,logspace(wi,wf,step));
                    n = length(w);

                    switch sing_zero
                        case 0
                            switch sing_inf
                                case 0 % Continous, Proper case 
                                    freq = w;

                                case 1 % Continous, Improper case
                                    f = pi/2: -pi/200 : 0;
                                    lemma_inf = abs(w(n))*exp(1i*f);
                                    freq = horzcat(w, lemma_inf);
                            end
                        case 1
                            q = 0: pi/50 : pi/2;
                            lemma_zero = abs(w(1))*exp(1i*q);

                            switch sing_inf
                                case 0 % Case with integrators and Proper
                                    freq = horzcat(lemma_zero, w);

                                case 1 % Case with integrators and Improper
                                    f = pi/2 : -pi/200 : 0;
                                    lemma_inf = abs(w(n))*exp(1i*f);
                                    freq = horzcat(lemma_zero, w, lemma_inf);
                            end
                    end


                    %--------------- MAPPING ----------------
                    % Determine the number of eigenvalues
                    ne = length(e);

                    % Determine number of frequency values
                    ns = length(freq);

                    % Preallocate matrix
                    nyq = zeros(length(freq),ne);    

                    % for each eigenloci
                    for k = 1 : ne
                        echar = char(e(k));
                        % calculate for each frequency
                        for h = 1 : ns 
                            p = freq(h); % p is substituted into echar in the eval function below
                            nyq(h,k)= eval(echar);
                        end
                    end



                    %--------------- PLOTTING ---------------
                    plot(real(nyq), imag(nyq),'-')
                    hold on
                    plot(real(nyq),-1* imag(nyq),'--')
                    hold on
                    plot(-1,0,'r+')
                    hold on

                    set(gca,'YColor',[0.4 0.4 0.4],'XColor',[0.4 0.4 0.4],'FontSize',8)

                    xlabel('Real Axis')
                    ylabel('Imaginary axis')
                    title('Multivariable Nyquist eigenloci plot')

                    % For Generating the pairs of arrowheads on each eigenloci
                    for k = 1 : ne
                        if sing_inf == 0 % for proper case            
                            % sample points for first arrowhead
                            f1 = 26;
                            f2 = 46;            
                            % sample points for second arrowhead
                            f3 = 200;
                            f4 = 220;

                        else % for improper case
                            % sample points for first arrowhead
                            f1 = 860;
                            f2 = 880;            
                            % sample points for second arrowhead
                            f3 = 960;
                            f4 = 980;    
                        end

                        % points on either side of first arrowhead
                        v1 = nyq(f1,k);
                        v2 = nyq(f2,k);
                        % generate first arrowhead 
                        x1 = [real(v1), real(v2)];
                        y1 = [imag(v1), imag(v2)];
                        arrowh(x1,y1);

                        % points on either side of second arrowhead
                        v3 = nyq(f3,k);
                        v4 = nyq(f4,k);        
                        % generate second arrowhead 
                        x2 = [real(v3), real(v4)];
                        y2 = [imag(v3), imag(v4)];
                        arrowh(x2,y2);
                    end
                    hold off
    
                else
                    error('Multivar 1.0: Input system must be square.')
                end        

            else
                error('Multivar 1.0: Input system is not compatible with generalised Nyquist function.')
            end     
    
        else
            % Display error if incorrect number of inputs
            narginchk(1, 1)
        end
    else
        % Display error if incorrect number of outputs
        nargoutchk(0, 1)
    end

end
