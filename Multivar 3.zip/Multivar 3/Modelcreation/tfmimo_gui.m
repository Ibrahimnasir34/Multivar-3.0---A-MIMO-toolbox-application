function varargout = tfmimo_gui(varargin)
% TFMIMO_GUI M-file for tfmimo_gui.fig
%      TFMIMO_GUI, by itself, creates a new TFMIMO_GUI or raises the existing
%      singleton*.
%
%      H = TFMIMO_GUI returns the handle to a new TFMIMO_GUI or the handle to
%      the existing singleton*.
%
%      TFMIMO_GUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in TFMIMO_GUI.M with the given input arguments.
%
%      TFMIMO_GUI('Property','Value',...) creates a new TFMIMO_GUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before tfmimo_gui_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to tfmimo_gui_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help tfmimo_gui

% Last Modified by GUIDE v2.5 13-Oct-2017 04:12:36

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @tfmimo_gui_OpeningFcn, ...
                   'gui_OutputFcn',  @tfmimo_gui_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before tfmimo_gui is made visible.
function tfmimo_gui_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to tfmimo_gui (see VARARGIN)

% Choose default command line output for tfmimo_gui
handles.output = hObject;

% Get root application data
mstruct = getappdata(0, 'mlvappdata');

% Set position and size and title
set(handles.output, 'OuterPosition',mstruct.windowposition, 'Name', mstruct.gtitle);

% Set handle of previous page as gui/figure application data
setappdata(handles.output,'hprevpage',mstruct.phandlerecord(length(mstruct.phandlerecord)));

% Update the page handle record in the structure and then save structure as root application data
mstruct.phandlerecord = [mstruct.phandlerecord, handles.output];
mstruct.systemmodel = iosnames(mstruct.systemmodel);
setappdata(0, 'mlvappdata', mstruct)

% set struct from root application data as gui/figure application data
setappdata(handles.output, 'gstruct', mstruct);

% Set Defaults
% get empty system model and save as gui/figure application data
tfsys = mstruct.systemmodel;
setappdata(handles.output, 'unsavedmod',tfsys)

% Set values of pop-up menus
[m,n] = size(tfsys);
list_in = 1:n;
list_out = 1:m;
set(handles.pvin, 'String', num2str(list_in.'))
set(handles.pvout, 'String', num2str(list_out.'))

% Set default value of pop-up menus and save as figure / gui application data
din = 1;
dout = 1;
set(handles.pvin, 'Value', din)
set(handles.pvout, 'Value', dout)
piochannel = [dout, din];
setappdata(handles.output, 'pio', piochannel)

% Set default value of position map
subplot(1,1,1), colmat(m,n,dout,din)

%Set default values of edit text boxes
% Note to convert from cell to string use cell2mat and then mat2str
% functions
iotf = tfsys(dout,din);
set(handles.numvector,'String', mat2str(cell2mat(iotf.num)));
set(handles.delvalue,'String', num2str(iotf.iodelay));
set(handles.denvector,'String', mat2str(cell2mat(iotf.den)));

% Preview default model
str_sys = evalc('iotf');
tlines = strsplit(str_sys,'\n');
set(handles.tdisp,'FontName', 'Monospaced', 'String',tlines);
set(handles.msgbox, 'String','')


% Update handles structure
guidata(hObject, handles);

% UIWAIT makes tfmimo_gui wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = tfmimo_gui_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in nextbutt.
function nextbutt_Callback(hObject, eventdata, handles)
% hObject    handle to nextbutt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Convert data from GUI to  transfer function
vnum = eval(['[',get(handles.numvector, 'String'), ']']);
vdel = eval(get(handles.delvalue, 'String'));
vden = eval(['[',get(handles.denvector, 'String'), ']']);
if any(vden) == 1
    G = tf(vnum, vden);
    G.iodelay = vdel;

    % SAVE PREV I/O CHANNEL    
    % Modify tf matrix and save as root application data
    tfsys = getappdata(handles.output, 'unsavedmod');
    vout = get(handles.pvout, 'Value');
    vin = get(handles.pvin, 'Value');
    tfsys(vout, vin) = G;
    setappdata(handles.output, 'unsavedmod',tfsys)
    
    % GO TO NEXT GUI PAGE
    % Get struct from gui/figure application data.
    mstruct = getappdata(handles.output, 'gstruct');

    % Save system model to structure
    fsys = mstruct.systemmodel;
    tfsys.InputName = fsys.InputName;
    tfsys.OutputName = fsys.OutputName;        
 
    mstruct.systemmodel = tfsys;

    % Get position of the current GUI window and save as application window for
    % the next GUI window.
    mstruct.windowposition = get(gcf,'OuterPosition');

    % Update root application data
    setappdata(0, 'mlvappdata', mstruct);

    % Activate new GUI window and close the last window
    set(varnames, 'Visible', 'On');
    set(handles.output, 'Visible', 'Off');
    
else
    emessage = 'Multivar: Transfer function cannot be saved. The denominators specified in the "den" property must be nonzero vectors.';
    set(handles.msgbox, 'String', emessage, 'ForegroundColor', [1 0 0])
    set(handles.tdisp,'FontName', 'Monospaced', 'String','')
end

% Update handles structure
guidata(hObject, handles);






% --- Executes on button press in goback.
function goback_Callback(hObject, eventdata, handles)
% hObject    handle to goback (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get structure from gui/figure application data
mstruct = getappdata(handles.output,'gstruct');

% Update/modify structure
% Get rid of the handle of the current figure
mstruct.phandlerecord = mstruct.phandlerecord(1: length(mstruct.phandlerecord) - 1);

% Get position of the current GUI window 
mstruct.windowposition = get(gcf,'OuterPosition');

% Update root application data
setappdata(0, 'mlvappdata', mstruct);

% Get handle of previous page from figure appdata
% Activate previous gui window and delete the handle of the current window
set(getappdata(handles.output,'hprevpage'), 'OuterPosition',mstruct.windowposition,'Visible', 'On');
set(handles.output, 'Visible', 'Off');
delete(handles.output)



function numvector_Callback(hObject, eventdata, handles)
% hObject    handle to numvector (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of numvector as text
%        str2double(get(hObject,'String')) returns contents of numvector as a double
vnum = eval(['[',get(handles.numvector, 'String'), ']']);
vdel = eval(get(handles.delvalue, 'String'));
vden = eval(['[',get(handles.denvector, 'String'), ']']);
if any(vden) == 1
    G = tf(vnum, vden);
    G.iodelay = vdel;
    str_sys = evalc('G');
    tlines = strsplit(str_sys,'\n');
    set(handles.tdisp,'FontName', 'Monospaced', 'String',tlines);
    set(handles.msgbox, 'String','')
else
    emessage = 'Multivar: The denominators specified in the "den" property must be nonzero vectors.';
    set(handles.msgbox, 'String', emessage, 'ForegroundColor', [1 0 0])
    set(handles.tdisp,'FontName', 'Monospaced', 'String','')
end


% --- Executes during object creation, after setting all properties.
function numvector_CreateFcn(hObject, eventdata, handles)
% hObject    handle to numvector (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function delvalue_Callback(hObject, eventdata, handles)
% hObject    handle to delvalue (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of delvalue as text
%        str2double(get(hObject,'String')) returns contents of delvalue as a double
vnum = eval(['[',get(handles.numvector, 'String'), ']']);
vdel = eval(get(handles.delvalue, 'String'));
vden = eval(['[',get(handles.denvector, 'String'), ']']);
if any(vden) == 1
    G = tf(vnum, vden);
    G.iodelay = vdel;
    str_sys = evalc('G');
    tlines = strsplit(str_sys,'\n');
    set(handles.tdisp,'FontName', 'Monospaced', 'String',tlines);
    set(handles.msgbox, 'String','')
else
    emessage = 'Multivar: The denominators specified in the "den" property must be nonzero vectors.';
    set(handles.msgbox, 'String', emessage, 'ForegroundColor', [1 0 0])
    set(handles.tdisp,'FontName', 'Monospaced', 'String','')
end



% --- Executes during object creation, after setting all properties.
function delvalue_CreateFcn(hObject, eventdata, handles)
% hObject    handle to delvalue (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function denvector_Callback(hObject, eventdata, handles)
% hObject    handle to denvector (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of denvector as text
%        str2double(get(hObject,'String')) returns contents of denvector as a double
vnum = eval(['[',get(handles.numvector, 'String'), ']']);
vdel = eval(get(handles.delvalue, 'String'));
vden = eval(['[',get(handles.denvector, 'String'), ']']);
if any(vden) == 1
    G = tf(vnum, vden);
    G.iodelay = vdel;
    str_sys = evalc('G');
    tlines = strsplit(str_sys,'\n');
    set(handles.tdisp,'FontName', 'Monospaced', 'String',tlines);
    set(handles.msgbox, 'String','')
else
    emessage = 'Multivar: The denominator vector must contain at least one non-zero element.';
    set(handles.msgbox, 'String', emessage, 'ForegroundColor', [1 0 0])
    set(handles.tdisp,'FontName', 'Monospaced', 'String','')
end


% --- Executes during object creation, after setting all properties.
function denvector_CreateFcn(hObject, eventdata, handles)
% hObject    handle to denvector (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in pvin.
function pvin_Callback(hObject, eventdata, handles)
% hObject    handle to pvin (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns pvin contents as cell array
%        contents{get(hObject,'Value')} returns selected item from pvin

% Convert data from GUI to  transfer function
vnum = eval(['[',get(handles.numvector, 'String'), ']']);
vdel = eval(get(handles.delvalue, 'String'));
vden = eval(['[',get(handles.denvector, 'String'), ']']);
if any(vden) == 1
    G = tf(vnum, vden);
    G.iodelay = vdel;
    
    % SAVE PREV I/O CHANNEL
    % Modify tf matrix and save as root application data
    tfsys = getappdata(handles.output, 'unsavedmod');
    % Get previous channel id and save previous tf
    piochannel = getappdata(handles.output, 'pio');
    vout = piochannel(1);
    vin =  piochannel(2);
    tfsys(vout, vin) = G;
    setappdata(handles.output, 'unsavedmod',tfsys)
    set(handles.msgbox, 'String', ['Transfer function saved to matrix model at location ', '[ ', num2str(vout),', ', num2str(vin), ' ]'], 'ForegroundColor', [0 0 1])

    % GO TO NEW I/O CHANNEL
    % to facilitate stepping through the matrix
    [m, n] = size(tfsys);
    % get new values of inputs and output from pop-ups
    a = get(handles.pvout, 'Value');
    b = get(handles.pvin, 'Value');
    
    % update last previous i/o channel value
    piochannel = [a, b];
    setappdata(handles.output, 'pio', piochannel)    
    
    subplot(1,1,1), colmat(m,n,a,b)

    % If at the beginning of the matrix turn off "PREVIOUS" button
    if a == 1 && b == 1
        set(handles.ioprevbutt, 'Enable', 'off')
    else
        set(handles.ioprevbutt, 'Enable', 'on')
    end

    % If at the end of the matrix turn off "NEXT" button
    if a == m && b == n
        set(handles.ionextbutt, 'Enable', 'off')
    else
        set(handles.ionextbutt, 'Enable', 'on')
    end

    iotf = tfsys(a,b);
    set(handles.numvector,'String', mat2str(cell2mat(iotf.num)));
    set(handles.delvalue,'String', num2str(iotf.iodelay));
    set(handles.denvector,'String', mat2str(cell2mat(iotf.den)));

    vden = cell2mat(iotf.den);
    if any(vden) == 1
        str_sys = evalc('iotf');
        tlines = strsplit(str_sys,'\n');
        set(handles.tdisp,'FontName', 'Monospaced', 'String',tlines);
        set(handles.msgbox, 'String','')
    else
        emessage = 'Multivar: The denominator vector must contain at least one non-zero element.';
        set(handles.msgbox, 'String', emessage, 'ForegroundColor', [1 0 0])
        set(handles.tdisp,'FontName', 'Monospaced', 'String','')
    end

else
    emessage = 'Multivar: Transfer function cannot be saved. The denominator vector must contain at least one non-zero element.';
    set(handles.msgbox, 'String', emessage, 'ForegroundColor', [1 0 0])
    set(handles.tdisp,'FontName', 'Monospaced', 'String','')
end

% Update handles structure
guidata(hObject, handles);




% --- Executes on button press in ioprevbutt.
function ioprevbutt_Callback(hObject, eventdata, handles)
% hObject    handle to ioprevbutt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Convert data from GUI to  transfer function
vnum = eval(['[',get(handles.numvector, 'String'), ']']);
vdel = eval(get(handles.delvalue, 'String'));
vden = eval(['[',get(handles.denvector, 'String'), ']']);
if any(vden) == 1
    G = tf(vnum, vden);
    G.iodelay = vdel;

    % SAVE PREV I/O CHANNEL
    % Modify tf matrix and save as root application data
    tfsys = getappdata(handles.output, 'unsavedmod');
    a = get(handles.pvout, 'Value');
    b = get(handles.pvin, 'Value');
    tfsys(a, b) = G;
    setappdata(handles.output, 'unsavedmod',tfsys)
    

    % GO TO NEW I/O CHANNEL
    % to facilitate stepping through the matrix
    [m, n] = size(tfsys);

    % calculate index of next i/o channel    
    if b ~= 1
        b = b - 1; % decrement input number
    else
        if a ~= 1
            a = a - 1; %decrement output number
            b = n; % set input number to largest input value
        end
    end

    % If at the beginning of the matrix turn off "PREVIOUS" button
    if a == 1 && b == 1
        set(handles.ioprevbutt, 'Enable', 'off')
    else
        set(handles.ioprevbutt, 'Enable', 'on')
    end

    % If at the end of the matrix turn off "NEXT" button
    if a == m && b == n
        set(handles.ionextbutt, 'Enable', 'off')
    else
        set(handles.ionextbutt, 'Enable', 'on')
    end

    % Update displays
    set(handles.pvout, 'Value',a)
    set(handles.pvin, 'Value',b)
    
    % update last previous i/o channel value
    piochannel = [a, b];
    setappdata(handles.output, 'pio', piochannel)    

    iotf = tfsys(a,b);
    set(handles.numvector,'String', mat2str(cell2mat(iotf.num)));
    set(handles.delvalue,'String', num2str(iotf.iodelay));
    set(handles.denvector,'String', mat2str(cell2mat(iotf.den)));

    vden = cell2mat(iotf.den);
    if any(vden) == 1
        str_sys = evalc('iotf');
        tlines = strsplit(str_sys,'\n');
        set(handles.tdisp,'FontName', 'Monospaced', 'String',tlines);
        set(handles.msgbox, 'String','')
    else
        emessage = 'Multivar: The denominator vector must contain at least one non-zero element.';
        set(handles.msgbox, 'String', emessage, 'ForegroundColor', [1 0 0])
        set(handles.tdisp,'FontName', 'Monospaced', 'String','')
    end
    subplot(1,1,1), colmat(m,n,a,b)
    
else
    emessage = 'Multivar: Transfer function cannot be saved. The denominator vector must contain at least one non-zero element.';
    set(handles.msgbox, 'String', emessage, 'ForegroundColor', [1 0 0])
    set(handles.tdisp,'FontName', 'Monospaced', 'String','')
end

% Update handles structure
guidata(hObject, handles);



% --- Executes during object creation, after setting all properties.
function pvin_CreateFcn(hObject, eventdata, handles)
% hObject    handle to pvin (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in pvout.
function pvout_Callback(hObject, eventdata, handles)
% hObject    handle to pvout (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns pvout contents as cell array
%        contents{get(hObject,'Value')} returns selected item from pvout

% Convert data from GUI to  transfer function
vnum = eval(['[',get(handles.numvector, 'String'), ']']);
vdel = eval(get(handles.delvalue, 'String'));
vden = eval(['[',get(handles.denvector, 'String'), ']']);
if any(vden) == 1
    G = tf(vnum, vden);
    G.iodelay = vdel;

    % SAVE PREV I/O CHANNEL
    % Modify tf matrix and save as root application data
    tfsys = getappdata(handles.output, 'unsavedmod');
    % Get previous channel id and save previous tf
    piochannel = getappdata(handles.output, 'pio');
    vout = piochannel(1);
    vin =  piochannel(2);
    tfsys(vout, vin) = G;
    setappdata(handles.output, 'unsavedmod',tfsys)
    set(handles.msgbox, 'String', ['Transfer function saved to matrix model at location ', '[ ', num2str(vout),', ', num2str(vin), ' ]'], 'ForegroundColor', [0 0 1])

    % GO TO NEW I/O CHANNEL
    % to facilitate stepping through the matrix
    [m, n] = size(tfsys);
    % get new values of inputs and output from pop-ups
    a = get(handles.pvout, 'Value');
    b = get(handles.pvin, 'Value');

    % update last previous i/o channel value
    piochannel = [a, b];
    setappdata(handles.output, 'pio', piochannel)

    subplot(1,1,1), colmat(m,n,a,b)

    % If at the beginning of the matrix turn off "PREVIOUS" button
    if a == 1 && b == 1
        set(handles.ioprevbutt, 'Enable', 'off')
    else
        set(handles.ioprevbutt, 'Enable', 'on')
    end

    % If at the end of the matrix turn off "NEXT" button
    if a == m && b == n
        set(handles.ionextbutt, 'Enable', 'off')
    else
        set(handles.ionextbutt, 'Enable', 'on')
    end

    iotf = tfsys(a,b);
    set(handles.numvector,'String', mat2str(cell2mat(iotf.num)));
    set(handles.delvalue,'String', num2str(iotf.iodelay));
    set(handles.denvector,'String', mat2str(cell2mat(iotf.den)));

    vden = cell2mat(iotf.den);
    if any(vden) == 1
        str_sys = evalc('iotf');
        tlines = strsplit(str_sys,'\n');
        set(handles.tdisp,'FontName', 'Monospaced', 'String',tlines);
        set(handles.msgbox, 'String','')
    else
        emessage = 'Multivar: The denominator vector must contain at least one non-zero element.';
        set(handles.msgbox, 'String', emessage, 'ForegroundColor', [1 0 0])
        set(handles.tdisp,'FontName', 'Monospaced', 'String','')
    end

else
    emessage = 'Multivar: Transfer function cannot be saved. The denominator vector must contain at least one non-zero element.';
    set(handles.msgbox, 'String', emessage, 'ForegroundColor', [1 0 0])
    set(handles.tdisp,'FontName', 'Monospaced', 'String','')
end

% Update handles structure
guidata(hObject, handles);




% --- Executes during object creation, after setting all properties.
function pvout_CreateFcn(hObject, eventdata, handles)
% hObject    handle to pvout (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in ionextbutt.
function ionextbutt_Callback(hObject, eventdata, handles)
% hObject    handle to ionextbutt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Convert data from GUI to  transfer function
vnum = eval(['[',get(handles.numvector, 'String'), ']']);
vdel = eval(get(handles.delvalue, 'String'));
vden = eval(['[',get(handles.denvector, 'String'), ']']);
if any(vden) == 1
    G = tf(vnum, vden);
    G.iodelay = vdel;

    % SAVE PREV I/O CHANNEL
    % Modify tf matrix and save as root application data
    tfsys = getappdata(handles.output, 'unsavedmod');
    a = get(handles.pvout, 'Value');
    b = get(handles.pvin, 'Value');
    tfsys(a, b) = G;
    setappdata(handles.output, 'unsavedmod',tfsys)
    

    % GO TO NEW I/O CHANNEL
    % to facilitate stepping through the matrix
    [m, n] = size(tfsys);
    % calculate index of next i/o channel
    if b ~= n
        b = b + 1; % increment input number
    else
        if a ~= m
            a = a + 1; %increment output number
            b = 1; % set input number to 1
        end
    end


    % If at the beginning of the matrix turn off "PREVIOUS" button
    if a == 1 && b == 1
        set(handles.ioprevbutt, 'Enable', 'off')
    else
        set(handles.ioprevbutt, 'Enable', 'on')
    end

    % If at the end of the matrix turn off "NEXT" button
    if a == m && b == n
        set(handles.ionextbutt, 'Enable', 'off')
    else
        set(handles.ionextbutt, 'Enable', 'on')
    end

    % Update displays
    set(handles.pvout, 'Value',a)
    set(handles.pvin, 'Value',b)
    
    % update last previous i/o channel value
    piochannel = [a, b];
    setappdata(handles.output, 'pio', piochannel)    

    iotf = tfsys(a,b);
    set(handles.numvector,'String', mat2str(cell2mat(iotf.num)));
    set(handles.delvalue,'String', num2str(iotf.iodelay));
    set(handles.denvector,'String', mat2str(cell2mat(iotf.den)));

    vden = cell2mat(iotf.den);
    if any(vden) == 1
        str_sys = evalc('iotf');
        tlines = strsplit(str_sys,'\n');
        set(handles.tdisp,'FontName', 'Monospaced', 'String',tlines);
        set(handles.msgbox, 'String','')
    else
        emessage = 'Multivar: The denominator vector must contain at least one non-zero element.';
        set(handles.msgbox, 'String', emessage, 'ForegroundColor', [1 0 0])
        set(handles.tdisp,'FontName', 'Monospaced', 'String','')
    end
    subplot(1,1,1), colmat(m,n,a,b)    

else
    emessage = 'Multivar: Transfer function cannot be saved. The denominator vector must contain at least one non-zero element.';
    set(handles.msgbox, 'String', emessage, 'ForegroundColor', [1 0 0])
    set(handles.tdisp,'FontName', 'Monospaced', 'String','')
end

% Update handles structure
guidata(hObject, handles);



% --- Executes on button press in iosave.
function iosave_Callback(hObject, eventdata, handles)
% hObject    handle to iosave (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Convert data from GUI to  transfer function
vnum = eval(['[',get(handles.numvector, 'String'), ']']);
vdel = eval(get(handles.delvalue, 'String'));
vden = eval(['[',get(handles.denvector, 'String'), ']']);
if any(vden) == 1
    G = tf(vnum, vden);
    G.iodelay = vdel;

    % Modify tf matrix and save as root application data
    tfsys = getappdata(handles.output, 'unsavedmod');
    vout = get(handles.pvout, 'Value');
    vin = get(handles.pvin, 'Value');
    tfsys(vout, vin) = G;
    setappdata(handles.output, 'unsavedmod',tfsys)
    set(handles.msgbox, 'String', ['Transfer function saved to matrix model at location ', '[ ', num2str(vout),', ', num2str(vin), ' ]'], 'ForegroundColor', [0 0 1])
else
    emessage = 'Multivar: Transfer function cannot be saved. The denominator vector must contain at least one non-zero element.';
    set(handles.msgbox, 'String', emessage, 'ForegroundColor', [1 0 0])
    set(handles.tdisp,'FontName', 'Monospaced', 'String','')
end

% Update handles structure
guidata(hObject, handles);


function ioviewpane_Callback(hObject, eventdata, handles)
% hObject    handle to ioviewpane (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of ioviewpane as text
%        str2double(get(hObject,'String')) returns contents of ioviewpane as a double


% --- Executes during object creation, after setting all properties.
function ioviewpane_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ioviewpane (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes when user attempts to close figure1.
function figure1_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: delete(hObject) closes the figure

% display a question dialog box 
selection = questdlg('Are you sure you want to close Multivar?','Close Request Function','Yes','No','Yes'); 

switch selection, 
    case 'Yes'     
        % delete all figures related to multivar
          mstruct = getappdata(handles.output,'gstruct');  
          delete(mstruct.phandlerecord) 
          exit_multivar
    case 'No'
       % Do nothing
end



function msgbox_Callback(hObject, eventdata, handles)
% hObject    handle to msgbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of msgbox as text
%        str2double(get(hObject,'String')) returns contents of msgbox as a double


% --- Executes during object creation, after setting all properties.
function msgbox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to msgbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in tdisp.
function tdisp_Callback(hObject, eventdata, handles)
% hObject    handle to tdisp (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns tdisp contents as cell array
%        contents{get(hObject,'Value')} returns selected item from tdisp


% --- Executes during object creation, after setting all properties.
function tdisp_CreateFcn(hObject, eventdata, handles)
% hObject    handle to tdisp (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
