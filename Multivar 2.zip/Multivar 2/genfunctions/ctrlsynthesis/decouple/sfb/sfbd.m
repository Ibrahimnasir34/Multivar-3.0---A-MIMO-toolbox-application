function [F, G] = sfbd(sys, Ke, Te)
% SFBD  Uses state feedback to diagonally decouple LTI MIMO systems.
%
% SYNTAX
% [F, G] = sfbd(SYS, Ke, Te) returns the state feedback matrix F and the
% input gain matrix G for a system SYS and specified steady state gains Ke
% and time constants Te.
%
% FUNCTION INPUT ARGUMENTS
% sys  - LTI MIMO of type ss, zpk or tf without time delays
% system
% Ke - vector of the gain values for the diagonal elements of the decoupled
% transfer function matrix. Length must equal the smallest dimension of the
% size of SYS.
% Te - vector of the tau values for the diagonal elements of the decoupled
% transfer function matrix. These values should be positive to ensure system
% stability.  Length must equal the smallest dimension of the size of SYS.
%
% FUNCTION OUTPUT ARGUMENTS
% F - feedback matrix for state feedback decoupling
% G - input gain matrix for state feedback decoupling
% See also SFBD_GEN.

% *************************************************************************
% Author:           Crystal Blackwell 
% Email:            Crystal.Blackwell@sta.uwi.edu
% Created:          January 2013; 
% Last revision:    29-June-2013;
% Useful websites:
%
% MATLAB VERSIONS USED IN PROGRAMMING PROCESS: 
% - MATLAB R2013a
%
% *************************************************************************
% NATIVE MATLAB FUNCTIONS USED TO CREATE THIS FUNCTION:
% nargin                    nargout                     narginchk                   
% nargoutchkdcgain          size                        inv                 
% ss                        eye                         error               
% diag                      zeros                       pinv            
% *************************************************************************
% MULTIVAR FUNCTIONS USED TO CREATE THIS FUNCTION:
% modtyptest           
% *************************************************************************

    % Check for correct number of output arguments
    if nargout == 2
        % Check for correct number of input arguments
        if nargin == 3 

            % Check type of input system
            modnum = modtyptest(sys);
            if modnum == 2 || modnum == 4 || modnum == 6
                
                % Convert sys to state space if tf or zpk
                if modnum == 2 || modnum == 6
                    sys = ss(sys);
                end

                A = sys.a;
                B = sys.b;
                C = sys.c;
                D = sys.d;

                % if D matrix is a zero matrix execute
                if (D == zeros(size(D)))

                    [m, p] = size(sys);
                    % Let the smaller of the system dimensions be the size of the new
                    % square decoupled system
                    if m <= p
                        ds = m;
                    else
                        ds = p;
                    end 

                    % If Ke is the correct size execute
                    [k1, k2] = size(Ke);
                    if k1 == 1 && k2 == ds

                        % If Te is the correct size execute
                        [t1, t2] = size(Te);
                        if t1 == 1 && t2 == ds

                            % If all elements of Te are positive execute
                            if (Te >= 0)
                                % Preallocating the Kd and Md vectors
                                Md = zeros(1, ds);
                                Kd = zeros(1, ds);
                                % Calculating the values of the Kd and Md vectors
                                for a = 1 : ds
                                    Md(a) = -1/Te(a);
                                    Kd(a) = -1 * Ke(a)* Md(a);
                                end

                                % Creating the K and M matrices
                                M = diag(Md);
                                K = diag(Kd);

                                % Evaluating the F and G matrices
                                F = pinv(C*B) * ((M*C)-(C*A));
                                G = pinv(C*B) *K;
                            else
                                 error('Multivar 1.0: All the elements of the time constant vectors should all be positive.')
                            end
                        else
                            error('Multivar 1.0: The vector of time constants is not the correct size.')
                        end
                    else
                         error('Multivar 1.0: The vector of absolute gains is not the correct size.')
                    end
                else
                     error('Multivar 1.0: System disturbance matrix must be a zero matrix.')
                end    
            else
                error('Multivar 1.0: Inappropriate input system.')
            end
        else
            % Display error if incorrect number of inputs
            narginchk(3, 3)
        end
    else
        % Display error if incorrect number of outputs
        nargoutchk(2, 2)
    end            
end
    
    
        
           
    

