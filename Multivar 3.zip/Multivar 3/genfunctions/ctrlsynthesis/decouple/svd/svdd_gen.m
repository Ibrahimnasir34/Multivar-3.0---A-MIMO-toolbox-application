function dsys = svdd_gen(sys, precomp, postcomp)
% SVDD_GENN  Applies SVD decoupling to the system and returns the entire
% system.
%
% SYNTAX
% dsys = svdd_gen(sys, precomp, postcomp) applied the pre-compensators and
% post-compenstators used in SVD decoupling and returns the transfer
% function of the entire system.
%

% *************************************************************************
% Author:           Crystal Blackwell 
% Email:            Crystal.Blackwell@sta.uwi.edu
% Created:          January 2013; 
% Last revision:    29-June-2013;
% Useful websites:
%
% MATLAB VERSIONS USED IN PROGRAMMING PROCESS: 
% - MATLAB R2013a
%
% *************************************************************************
% NATIVE MATLAB FUNCTIONS USED TO CREATE THIS FUNCTION:
% dcgain            svd                 size                minreal 
% inv               error                         
% *************************************************************************

    % Check if precomp and post comp are the right dimensions and numerical

    % determine decoupled system
    dsys = postcomp * sys * precomp;
    
    % Determining variable names from original system
    inname = sys.InputName;
    outname = sys.OutputName;
    if isa(sys,'ss')
        statname = sys.StateName;
    end
    % determining dimensions of decoupled system
    [md, nd] = size(dsys);
    if isa(sys,'ss')
        [a1,a2] = size(dsys.a);
        if a1 == a2
            sd = a1;
        else
            return
        end
    end

    % determining names for decoupled system
    inname = inname(1: nd); 
    outname = outname(1: md);
    if isa(sys,'ss')
        statname = statname(1:sd);
    end

    % Assigning variable names to decoupled system
    % Inputs
    for g = 1: 1: length(inname)
        inname{g} = [inname{g}, '_d'];
    end      
    dsys.InputName = inname;
    
    % Outputs
    for h = 1: 1: length(outname)
        outname{h} = [outname{h}, '_d'];
    end  
    dsys.OutputName = outname;
    
    % States
    if isa(sys,'ss')
        for f = 1: 1: length(statname)
            statname{f} = [statname{f}, '_d'];
        end  
        dsys.StateName = statname;
    end   
end