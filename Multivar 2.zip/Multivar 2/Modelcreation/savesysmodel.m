function varargout = savesysmodel(varargin)
% SAVESYSMODEL M-file for savesysmodel.fig
%      SAVESYSMODEL, by itself, creates a new SAVESYSMODEL or raises the existing
%      singleton*.
%
%      H = SAVESYSMODEL returns the handle to a new SAVESYSMODEL or the handle to
%      the existing singleton*.
%
%      SAVESYSMODEL('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in SAVESYSMODEL.M with the given input arguments.
%
%      SAVESYSMODEL('Property','Value',...) creates a new SAVESYSMODEL or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before savesysmodel_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to savesysmodel_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help savesysmodel

% Last Modified by GUIDE v2.5 11-May-2014 18:53:06

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @savesysmodel_OpeningFcn, ...
                   'gui_OutputFcn',  @savesysmodel_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before savesysmodel is made visible.
function savesysmodel_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to savesysmodel (see VARARGIN)

% Choose default command line output for savesysmodel
handles.output = hObject;

% Get root application data
mstruct = getappdata(0, 'mlvappdata');

% Set position and size and title
set(handles.output, 'OuterPosition',mstruct.windowposition, 'Name', mstruct.gtitle);

% Set handle of previous page as gui/figure application data
setappdata(handles.output,'hprevpage',mstruct.phandlerecord(length(mstruct.phandlerecord)));

% Update the page handle record in the structure and then save structure as root application data
mstruct.phandlerecord = [mstruct.phandlerecord, handles.output];
mstruct.modnum = modtyptest(mstruct.systemmodel);
setappdata(0, 'mlvappdata', mstruct)

% set struct from root application data as gui/figure application data
setappdata(handles.output, 'gstruct', mstruct);

% Set Defaults
sys_mod = mstruct.systemmodel;
sys_text = evalc('sys_mod');
tlines = strsplit(sys_text,'\n');
set(handles.tdisp,'FontName', 'Monospaced', 'String',tlines);

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes savesysmodel wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = savesysmodel_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in save_butt.
function save_butt_Callback(hObject, eventdata, handles)
% hObject    handle to save_butt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% display a question dialog box 
selection = questdlg('Are you sure you want to save your changes?','Save Request Function','Yes','No','Yes'); 

switch selection, 
    case 'Yes'     
        % Get struct from gui/figure application data.
        mstruct = getappdata(handles.output, 'gstruct');                

        % Save model to .mat file and display message
        % Get filename and remove .mat extension
        filename = mstruct.matfile;
        filename = filename(1: length(filename)-4);
        
        % assign value to variable
        eval([filename, '= mstruct.systemmodel;'])
        save(mstruct.savemodelpath, filename);
        set(handles.msgbox, 'String', ['Multivar: System model saved to ', mstruct.savemodelpath, '.']);

        % Update window position in structure
        mstruct.windowposition = get(gcf,'OuterPosition');        

        % Update/modify structure
        % Get rid of the handle of the current figure
        excesspg = mstruct.phandlerecord(length(mstruct.phandlerecord) - 4 + 1: length(mstruct.phandlerecord));
        mstruct.phandlerecord = mstruct.phandlerecord(1: length(mstruct.phandlerecord) - 4);

        % Update root application data
        setappdata(0, 'mlvappdata', mstruct);

        % Get handle of previous page from figure appdata
        set(handles.output, 'Visible', 'Off');         
   
        % Activate new GUI window and close the last window
        switch mstruct.modnum
            case 1
                % tf with delays
                set(pademimo_gui, 'Visible', 'On');       
            case 2
                % tf without delays
                set(alt_ssdisplay, 'Visible', 'On');
            case 4
                % ss without delays
                set(alt_tfzpkdisplay, 'Visible', 'On');
            case 5
                % zpk with delays
                set(pademimo_gui, 'Visible', 'On');
            case 6
                % zpk without delays
                set(alt_ssdisplay, 'Visible', 'On');
        end
        delete(excesspg)       

    case 'No'
       % Do nothing
end



% --- Executes on button press in goback.
function goback_Callback(hObject, eventdata, handles)
% hObject    handle to goback (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get structure from gui/figure application data
mstruct = getappdata(handles.output,'gstruct');

% Update/modify structure
% Get rid of the handle of the current figure
mstruct.phandlerecord = mstruct.phandlerecord(1: length(mstruct.phandlerecord) - 1);

% Get position of the current GUI window 
mstruct.windowposition = get(gcf,'OuterPosition');

% Update root application data
setappdata(0, 'mlvappdata', mstruct);

% Get handle of previous page from figure appdata
% Activate previous gui window and delete the handle of the current window
set(getappdata(handles.output,'hprevpage'), 'OuterPosition',mstruct.windowposition,'Visible', 'On');
set(handles.output, 'Visible', 'Off');
delete(handles.output)


% --- Executes when user attempts to close figure1.
function figure1_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: delete(hObject) closes the figure

% display a question dialog box 
selection = questdlg('Are you sure you want to close Multivar?','Close Request Function','Yes','No','Yes'); 

switch selection, 
    case 'Yes'     
        % delete all figures related to multivar
          mstruct = getappdata(handles.output,'gstruct');  
          delete(mstruct.phandlerecord) 
          exit_multivar
    case 'No'
       % Do nothing
end



function msgbox_Callback(hObject, eventdata, handles)
% hObject    handle to msgbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of msgbox as text
%        str2double(get(hObject,'String')) returns contents of msgbox as a double


% --- Executes during object creation, after setting all properties.
function msgbox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to msgbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in tdisp.
function tdisp_Callback(hObject, eventdata, handles)
% hObject    handle to tdisp (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns tdisp contents as cell array
%        contents{get(hObject,'Value')} returns selected item from tdisp


% --- Executes during object creation, after setting all properties.
function tdisp_CreateFcn(hObject, eventdata, handles)
% hObject    handle to tdisp (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
