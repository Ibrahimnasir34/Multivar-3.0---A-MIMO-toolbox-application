function [Abar, Bbar, Cbar, Dbar, T] = jcf(sys)
% JCF generate the Jordan Canonical Form(JCF)of a supplied MIMO system.
% 
% SYNTAX
% [Abar, Bbar, Cbar, Dbar, T] = dcf(sys) returns the Jordan Canonical 
% Form(JCF) of the MIMO system SYS and its matrices Abar, Bbar, Cbar, Dbar,
% and the Transformation matrix T.

% *************************************************************************
% Author:           Crystal Blackwell 
% Email:            Crystal.Blackwell@sta.uwi.edu
% Created:          January 2013; 
% Last revision:    29-June-2013;
% Useful websites:
%
% MATLAB VERSIONS USED IN PROGRAMMING PROCESS: 
% - MATLAB R2013a
%
% *************************************************************************
% NATIVE MATLAB FUNCTIONS USED TO CREATE THIS FUNCTION:
% class                     jordan                      abs
% inv                       ss2ss                     
% *************************************************************************

    % Check if input argument is a state-space system
    if strcmp(class(sys), 'ss') == 1
        [iT, J] = jordan(sys.a);
        T = inv(iT);

        % Performing transformation
        sysT = ss2ss(sys,T);
        Abar = sysT.a;
        Bbar = sysT.b;
        Cbar = sysT.c;
        Dbar = sysT.d;

        % Setting very tiny values to zero for clarity and presentation
        % purposes
        ptol = 0.0001;
        Abar(abs(Abar) < ptol) = 0;
        Bbar(abs(Bbar) < ptol) = 0;
        Cbar(abs(Cbar) < ptol) = 0;
        Dbar(abs(Dbar) < ptol) = 0;
        T(abs(T) < ptol) = 0;
     else
        % error('Multivar 1.0: System must be in state space form.')
        Abar = [];
        Bbar = [];
        Cbar = [];
        Dbar = [];
        T = [];      
    end
end


