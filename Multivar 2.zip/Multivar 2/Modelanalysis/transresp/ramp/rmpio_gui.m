function varargout = rmpio_gui(varargin)
% RMPIO_GUI M-file for rmpio_gui.fig
%      RMPIO_GUI, by itself, creates a new RMPIO_GUI or raises the existing
%      singleton*.
%
%      H = RMPIO_GUI returns the handle to a new RMPIO_GUI or the handle to
%      the existing singleton*.
%
%      RMPIO_GUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in RMPIO_GUI.M with the given input arguments.
%
%      RMPIO_GUI('Property','Value',...) creates a new RMPIO_GUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before rmpio_gui_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to rmpio_gui_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help rmpio_gui

% Last Modified by GUIDE v2.5 06-Sep-2013 11:40:47

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @rmpio_gui_OpeningFcn, ...
                   'gui_OutputFcn',  @rmpio_gui_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before rmpio_gui is made visible.
function rmpio_gui_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to rmpio_gui (see VARARGIN)

% Choose default command line output for rmpio_gui
handles.output = hObject;

% Get root application data
mstruct = getappdata(0, 'mlvappdata');

% Set position and size and title
set(handles.output, 'OuterPosition',mstruct.windowposition, 'Name', mstruct.gtitle);

% Set handle of previous page as gui/figure application data
setappdata(handles.output,'hprevpage',mstruct.phandlerecord(length(mstruct.phandlerecord)));

% Update the page handle record in the structure and then save structure as root application data
mstruct.phandlerecord = [mstruct.phandlerecord, handles.output];
setappdata(0, 'mlvappdata', mstruct)

% set struct from root application data as gui/figure application data
setappdata(handles.output, 'gstruct', mstruct);

% Set Defaults
% Setting values of input and output pop-up menus
G = mstruct.systemmodel;
[m,r] = size(G);
list_in = 1:r;
list_out = 1:m;
set(handles.pvin, 'String', num2str(list_in.'))
set(handles.pvout, 'String', num2str(list_out.'))

% Displaying default plot on opening of GUI
din =1;
dout = 1;
set(handles.pvin,'Value', din); 
set(handles.pvout,'Value', dout);
set(handles.ioprevbutt, 'Enable', 'off')

subplot(handles.axes1)
subplot(1,1,1), mlvramp(G(dout,din))
if get(handles.gridctrl,'Value')== 1
    grid on
else
    grid off
end

IO_channel = G(dout,din);
io_text = evalc('IO_channel');
iolines = strsplit(io_text,'\n');
set(handles.iodisp,'FontName', 'Monospaced', 'String',iolines);

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes rmpio_gui wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = rmpio_gui_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on selection change in pvin.
function pvin_Callback(hObject, eventdata, handles)
% hObject    handle to pvin (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns pvin contents as cell array
%        contents{get(hObject,'Value')} returns selected item from pvin

% Get position struct from gui/figure application data.
mstruct = getappdata(handles.output, 'gstruct');
G = mstruct.systemmodel;

chin = get(handles.pvin,'Value'); 
chout = get(handles.pvout,'Value');

subplot(1,1,1), mlvramp(G(chout,chin))
if get(handles.gridctrl,'Value')== 1
    grid on
else
    grid off
end
IO_channel = G(chout,chin);
io_text = evalc('IO_channel');
iolines = strsplit(io_text,'\n');
set(handles.iodisp,'FontName', 'Monospaced', 'String',iolines);

% Update handles structure
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function pvin_CreateFcn(hObject, eventdata, handles)
% hObject    handle to pvin (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% Update handles structure
guidata(hObject, handles);


% --- Executes on selection change in pvout.
function pvout_Callback(hObject, eventdata, handles)
% hObject    handle to pvout (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns pvout contents as cell array
%        contents{get(hObject,'Value')} returns selected item from pvout

% Get position struct from gui/figure application data.
mstruct = getappdata(handles.output, 'gstruct');
G = mstruct.systemmodel;

chin = get(handles.pvin,'Value'); 
chout = get(handles.pvout,'Value');

subplot(1,1,1), mlvramp(G(chout,chin))
if get(handles.gridctrl,'Value')== 1
    grid on
else
    grid off
end
IO_channel = G(chout,chin);
io_text = evalc('IO_channel');
iolines = strsplit(io_text,'\n');
set(handles.iodisp,'FontName', 'Monospaced', 'String',iolines);

% Update handles structure
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function pvout_CreateFcn(hObject, eventdata, handles)
% hObject    handle to pvout (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% Update handles structure
guidata(hObject, handles);


% --- Executes on button press in ioprevbutt.
function ioprevbutt_Callback(hObject, eventdata, handles)
% hObject    handle to ioprevbutt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% to facilitate stepping through the matrix
mstruct = getappdata(handles.output, 'gstruct');
G = mstruct.systemmodel;
[m, n] = size(G);
a = get(handles.pvout, 'Value');
b = get(handles.pvin, 'Value');

if b ~= 1
    b = b - 1;
else
    if a ~= 1
        a = a - 1;
        b = n;
    end
end

% If at the beginning of the matrix turn off "PREVIOUS" button
if a == 1 && b == 1
    set(handles.ioprevbutt, 'Enable', 'off')
else
    set(handles.ioprevbutt, 'Enable', 'on')
end

% If at the end of the matrix turn off "NEXT" button
if a == m && b == n
    set(handles.ionextbutt, 'Enable', 'off')
else
    set(handles.ionextbutt, 'Enable', 'on')
end

% Update pop-up menu values
set(handles.pvout, 'Value',a)
set(handles.pvin, 'Value',b)

% Display plot
subplot(1,1,1), mlvramp(G(a,b))
if get(handles.gridctrl,'Value')== 1
    grid on
else
    grid off
end
IO_channel = G(a,b);
io_text = evalc('IO_channel');
iolines = strsplit(io_text,'\n');
set(handles.iodisp,'FontName', 'Monospaced', 'String',iolines);


% --- Executes on button press in goback.
function goback_Callback(hObject, eventdata, handles)
% hObject    handle to goback (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get structure from gui/figure application data
mstruct = getappdata(handles.output,'gstruct');

% Update/modify structure
% Get rid of the handle of the current figure
mstruct.phandlerecord = mstruct.phandlerecord(1: length(mstruct.phandlerecord) - 1);

% Get position of the current GUI window 
mstruct.windowposition = get(gcf,'OuterPosition');

% Update root application data
setappdata(0, 'mlvappdata', mstruct);

% Get handle of previous page from figure appdata
% Activate previous gui window and delete the handle of the current window
set(getappdata(handles.output,'hprevpage'), 'OuterPosition',mstruct.windowposition,'Visible', 'On');
set(handles.output, 'Visible', 'Off');
delete(handles.output)


% --- Executes when user attempts to close figure1.
function figure1_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: delete(hObject) closes the figure

% display a question dialog box 
selection = questdlg('Are you sure you want to close Multivar?','Close Request Function','Yes','No','Yes'); 

switch selection, 
    case 'Yes'     
        % delete all figures related to multivar
          mstruct = getappdata(handles.output,'gstruct');  
          delete(mstruct.phandlerecord) 
          exit_multivar
    case 'No'
       % Do nothing
end


% --- Executes on button press in ionextbutt.
function ionextbutt_Callback(hObject, eventdata, handles)
% hObject    handle to ionextbutt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% to facilitate stepping through the matrix
mstruct = getappdata(handles.output, 'gstruct');
G = mstruct.systemmodel;
[m, n] = size(G);
a = get(handles.pvout, 'Value');
b = get(handles.pvin, 'Value');

if b ~= n
    b = b + 1;
else
    if a ~= m
        a = a + 1;
        b = 1;
    end
end

% If at the beginning of the matrix turn off "PREVIOUS" button
if a == 1 && b == 1
    set(handles.ioprevbutt, 'Enable', 'off')
else
    set(handles.ioprevbutt, 'Enable', 'on')
end

% If at the end of the matrix turn off "NEXT" button
if a == m && b == n
    set(handles.ionextbutt, 'Enable', 'off')
else
    set(handles.ionextbutt, 'Enable', 'on')
end

% Update pop-up menu values
set(handles.pvout, 'Value',a)
set(handles.pvin, 'Value',b)

% Display plot
subplot(1,1,1), mlvramp(G(a,b))
if get(handles.gridctrl,'Value')== 1
    grid on
else
    grid off
end

IO_channel = G(a,b);
io_text = evalc('IO_channel');
iolines = strsplit(io_text,'\n');
set(handles.iodisp,'FontName', 'Monospaced', 'String',iolines);

% --- Executes on button press in gridctrl.
function gridctrl_Callback(hObject, eventdata, handles)
% hObject    handle to gridctrl (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of gridctrl

if get(handles.gridctrl,'Value')== 1
    grid on
else
    grid off
end



function iodisp_Callback(hObject, eventdata, handles)
% hObject    handle to iodisp (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of iodisp as text
%        str2double(get(hObject,'String')) returns contents of iodisp as a double


% --- Executes during object creation, after setting all properties.
function iodisp_CreateFcn(hObject, eventdata, handles)
% hObject    handle to iodisp (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in to_sysanal.
function to_sysanal_Callback(hObject, eventdata, handles)
% hObject    handle to to_sysanal (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get structure from gui/figure application data
mstruct = getappdata(handles.output,'gstruct');

% Update/modify structure
% Get handle for analysis page from record
hanal = mstruct.phandlerecord(length(mstruct.phandlerecord) - 2);

% Get rid of the last two handles
mstruct.phandlerecord = mstruct.phandlerecord(1: length(mstruct.phandlerecord) - 2);

% Get position of the current GUI window 
mstruct.windowposition = get(gcf,'OuterPosition');

% Update root application data
setappdata(0, 'mlvappdata', mstruct);

% Get handle of previous page from figure appdata
% Activate previous gui window and delete the handle of the current window
set(hanal, 'OuterPosition',mstruct.windowposition,'Visible', 'On');
set(handles.output, 'Visible', 'Off');

% Delete current page and previous page
delete(getappdata(handles.output,'hprevpage'), handles.output)
