function svdii3d(sys)
% SVDII3D  Plots the input and output complementary sensitivity and sensitvity
% functions of a svd decoupled and controlled MIMO system.
%
% SYNTAX
% svdii3d(SYS)
% (a)   svdii3d(SYS) provides a 3D plot of interaction index versus Reponse
%       frequency versus SVD Decoupling Frequency.
%

% *************************************************************************
% Author:           Crystal Blackwell 
% Email:            Crystal.Blackwell@sta.uwi.edu
% Created:          January 2013; 
% Last revision:    29-June-2013;
% Useful websites:
%
% MATLAB VERSIONS USED IN PROGRAMMING PROCESS: 
% - MATLAB R2013a
%
% *************************************************************************
% NATIVE MATLAB FUNCTIONS USED TO CREATE THIS FUNCTION:
% sigma             length              surf                ones
% plot              evalfr              gca                 xlabel
% ylabel            title               set                 length
% *************************************************************************

% NOTE: Assumption sys is arlready arranged for diagonal pairing
    [sv,rf] = sigma(sys);
    df = rf;
    m = length(rf);
         
    for a = 1: m
        % determine gain matrix
        s = 1j * df(a);
        Gm = evalfr(sys, s);
        
        % Decouple
        [U, S, V] = svd(Gm, 'econ');
        dsys = svdd_gen(sys, V, U);
        
        % Interaction value for that decoupling frquency
        II = iiplot(dsys, rf);
        
        % Arranging Matrix
        dfx = rf(a) * ones(1, m);

        X(:, a) = dfx;
        Y(:, a) = rf;
        Z(:, a) = II;
    end
    
    % Display
    figure
    surf(X, Y, Z)
    set(gca, 'XScale','log','YScale','log')
    xlabel('SVD Decoupling Frequency')
    ylabel('System Response Frequency')
    zlabel('Interation Index {\lambda}')
    title('Plot of Interaction Index versus SVD decoupling frequency and response frequency')    
    
end