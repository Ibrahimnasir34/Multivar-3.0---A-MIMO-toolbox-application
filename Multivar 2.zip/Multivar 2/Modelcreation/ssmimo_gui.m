function varargout = ssmimo_gui(varargin)
% SSMIMO_GUI M-file for ssmimo_gui.fig
%      SSMIMO_GUI, by itself, creates a new SSMIMO_GUI or raises the existing
%      singleton*.
%
%      H = SSMIMO_GUI returns the handle to a new SSMIMO_GUI or the handle to
%      the existing singleton*.
%
%      SSMIMO_GUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in SSMIMO_GUI.M with the given input arguments.
%
%      SSMIMO_GUI('Property','Value',...) creates a new SSMIMO_GUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before ssmimo_gui_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to ssmimo_gui_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help ssmimo_gui

% Last Modified by GUIDE v2.5 11-May-2014 18:40:33

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @ssmimo_gui_OpeningFcn, ...
                   'gui_OutputFcn',  @ssmimo_gui_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before ssmimo_gui is made visible.
function ssmimo_gui_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to ssmimo_gui (see VARARGIN)

% Choose default command line output for ssmimo_gui
handles.output = hObject;

% Get root application data
mstruct = getappdata(0, 'mlvappdata');

% Set position and size and title
set(handles.output, 'OuterPosition',mstruct.windowposition, 'Name', mstruct.gtitle);

% Set handle of previous page as gui/figure application data
setappdata(handles.output,'hprevpage',mstruct.phandlerecord(length(mstruct.phandlerecord)));

% Update the page handle record in the structure and then save structure as root application data
mstruct.phandlerecord = [mstruct.phandlerecord, handles.output];
mstruct.systemmodel = iosnames(mstruct.systemmodel);
setappdata(0, 'mlvappdata', mstruct)

% set gui page application data
setappdata(handles.output, 'gstruct', mstruct);

% Set Defaults
% get empty system model from root application data
SSsys = mstruct.systemmodel; 
A = SSsys.a;
B = SSsys.b;
C = SSsys.c;
D = SSsys.d;

%Set properties for tables A, B, C, D
set(handles.Atable,'Data',A, 'BackgroundColor',[0.5 1 0.5],'ColumnWidth',{80},'ColumnEditable', true);
set(handles.Btable,'Data',B, 'BackgroundColor',[1 1 0.5]  ,'ColumnWidth',{80},'ColumnEditable', true);
set(handles.Ctable,'Data',C, 'BackgroundColor',[0.5 1 1]  ,'ColumnWidth',{80},'ColumnEditable', true);
set(handles.Dtable,'Data',D, 'BackgroundColor',[1 0.6 0.6],'ColumnWidth',{80},'ColumnEditable', true);

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes ssmimo_gui wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = ssmimo_gui_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in nextbutt.
function nextbutt_Callback(hObject, eventdata, handles)
% hObject    handle to nextbutt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

Adata = get(handles.Atable,'Data');
Bdata = get(handles.Btable,'Data');
Cdata = get(handles.Ctable,'Data');
Ddata = get(handles.Dtable,'Data');

% Check that all the entries in each matrix are filled and numerical
if isfinite(Adata) == ones(size(Adata))
    if isfinite(Bdata)== ones(size(Bdata))
        if isfinite(Cdata)== ones(size(Cdata))
            if isfinite(Ddata)== ones(size(Ddata))
                % Get position struct from gui/figure application data.
                mstruct = getappdata(handles.output, 'gstruct');
                
                % Create state space system
                fsys = mstruct.systemmodel;
                SSsys = ss(Adata, Bdata, Cdata, Ddata);
                SSsys.InputName = fsys.InputName;
                SSsys.OutputName = fsys.OutputName;
                SSsys.StateName = fsys.StateName;                
                
                mstruct.systemmodel = SSsys;                          
               
                % Get position of the current GUI window and update
                % structure
                mstruct.windowposition = get(gcf,'OuterPosition');

                % Update root application data
                setappdata(0, 'mlvappdata', mstruct);
                
                % Clear Message box
                emessage = '';
                set(handles.msgbox,'String',emessage, 'ForegroundColor', [1 0 0]) 

                % Activate new GUI window and close the last window
                set(varnames, 'Visible', 'On');
                set(handles.output, 'Visible', 'Off');

                % Update handles structure
                guidata(hObject, handles);
            else
                emessage = 'Multivar: All elements of the "D" matrix must be numerical and finite.';
                set(handles.msgbox,'String',emessage, 'ForegroundColor', [1 0 0]) 
            end
        else
            emessage = 'Multivar: All elements of the "C" matrix must be numerical and finite.';
            set(handles.msgbox,'String',emessage, 'ForegroundColor', [1 0 0]) 
        end        
    else
        emessage = 'Multivar: All elements of the "B" matrix must be numerical and finite.';
        set(handles.msgbox,'String',emessage, 'ForegroundColor', [1 0 0])
    end    
else
    emessage = 'Multivar: All elements of the "A" matrix must be numerical and finite.';
    set(handles.msgbox,'String',emessage, 'ForegroundColor', [1 0 0]) 
end


% --- Executes on button press in goback.
function goback_Callback(hObject, eventdata, handles)
% hObject    handle to goback (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get structure from gui/figure application data
mstruct = getappdata(handles.output,'gstruct');

% Update/modify structure
% Get rid of the handle of the current figure
mstruct.phandlerecord = mstruct.phandlerecord(1: length(mstruct.phandlerecord) - 1);

% Get position of the current GUI window 
mstruct.windowposition = get(gcf,'OuterPosition');

% Update root application data
setappdata(0, 'mlvappdata', mstruct);

% Get handle of previous page from figure appdata
% Activate previous gui window and delete the handle of the current window
set(getappdata(handles.output,'hprevpage'), 'OuterPosition',mstruct.windowposition,'Visible', 'On');
set(handles.output, 'Visible', 'Off');
delete(handles.output)


% --- Executes when user attempts to close figure1.
function figure1_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: delete(hObject) closes the figure

% display a question dialog box 
selection = questdlg('Are you sure you want to close Multivar?','Close Request Function','Yes','No','Yes'); 

switch selection, 
    case 'Yes'     
        % delete all figures related to multivar
          mstruct = getappdata(handles.output,'gstruct');  
          delete(mstruct.phandlerecord) 
          exit_multivar
    case 'No'
       % Do nothing
end



function msgbox_Callback(hObject, eventdata, handles)
% hObject    handle to msgbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of msgbox as text
%        str2double(get(hObject,'String')) returns contents of msgbox as a double


% --- Executes during object creation, after setting all properties.
function msgbox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to msgbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
