function varargout = svddcal_gui(varargin)
% SVDDCAL_GUI M-file for svddcal_gui.fig
%      SVDDCAL_GUI, by itself, creates a new SVDDCAL_GUI or raises the existing
%      singleton*.
%
%      H = SVDDCAL_GUI returns the handle to a new SVDDCAL_GUI or the handle to
%      the existing singleton*.
%
%      SVDDCAL_GUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in SVDDCAL_GUI.M with the given input arguments.
%
%      SVDDCAL_GUI('Property','Value',...) creates a new SVDDCAL_GUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before svddcal_gui_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to svddcal_gui_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help svddcal_gui

% Last Modified by GUIDE v2.5 19-Sep-2013 15:27:12

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @svddcal_gui_OpeningFcn, ...
                   'gui_OutputFcn',  @svddcal_gui_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before svddcal_gui is made visible.
function svddcal_gui_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to svddcal_gui (see VARARGIN)

% Choose default command line output for svddcal_gui
handles.output = hObject;

% Setting title bar
set(gcf,'Name','Multivar 1.0: A MIMO Toolbox');

% Get root application data
mstruct = getappdata(0, 'mlvappdata');

% Get position of previous GUI window from root app data
win_posnew = mstruct.windowposition;
set(gcf,'Units','pixels');
set(gcf,'OuterPosition',win_posnew);

% Set handle of previous page as gui/figure application data
setappdata(handles.output,'hprevpage',mstruct.phandlerecord(length(mstruct.phandlerecord)));

% Update the page handle record in the structure and then save structure as root application data
mstruct.phandlerecord = [mstruct.phandlerecord, handles.output];
setappdata(0, 'mlvappdata', mstruct)

% set struct from root application data as gui/figure application data
setappdata(handles.output, 'gstruct', mstruct);

% Setting defaults
% Setting model display
G = mstruct.systemmodel;
sys_text = evalc('G');
set(handles.moddisplay,'String',sys_text, 'Enable', 'inactive');

% Displaying steady state values
%Display number of inputs and outputs for original model
[m, r] = size(G);
sm = num2str(m);
sr = num2str(r);
set(handles.noout,'String',sm);
set(handles.noin,'String',sr);

% Performing SVD
scalval = eye(size(G));
[U, S, V, CN, precomp, postcomp] = svdd(G, scalval);
dsys = svdd_gen(G, precomp, postcomp);

sCN = num2str(CN);
set(handles.sscn,'String',sCN);

%Displaying matrices U, S, V
set(handles.umatrix,'Data',U, 'BackgroundColor',[0.5 1 0.5],'ColumnEditable', false);
set(handles.smatrix,'Data',S, 'BackgroundColor',[1 1 0.5]  ,'ColumnEditable', false);
set(handles.vmatrix,'Data',V, 'BackgroundColor',[0.5 1 1]  ,'ColumnEditable', false);

%Displaying compensator matrices
set(handles.mprecomp,'Data',precomp, 'BackgroundColor',[1 1 0.5]  ,'ColumnEditable', false);
set(handles.mpostcomp,'Data',postcomp, 'BackgroundColor',[0.5 1 1]  ,'ColumnEditable', false);

% Setting decoupled model display
dsys_text = evalc('dsys');
set(handles.dmoddisplay,'String',dsys_text, 'Enable', 'inactive');

% No of loops controlled
[m2, r2] = size(S);
sm2 = num2str(m2);
set(handles.nocl,'String',sm2);

%Display number of inputs and outputs for decoupled system
[dm, dr] = size(dsys);
dsm = num2str(dm);
dsr = num2str(dr);
set(handles.dnoout,'String',dsm);
set(handles.dnoin,'String',dsr);


% Update handles structure
guidata(hObject, handles);

% UIWAIT makes svddcal_gui wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = svddcal_gui_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% add horizontal scrollbar to editbox
addhscroll(handles.moddisplay);
addhscroll(handles.dmoddisplay);

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes during object creation, after setting all properties.
function sscn_CreateFcn(hObject, eventdata, handles)
% hObject    handle to sscn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes when user attempts to close figure1.
function figure1_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: delete(hObject) closes the figure

% display a question dialog box 
selection = questdlg('Are you sure you want to close Multivar?','Close Request Function','Yes','No','Yes'); 

switch selection, 
    case 'Yes'     
        % delete all figures related to multivar
          mstruct = getappdata(handles.output,'gstruct');  
          delete(mstruct.phandlerecord) 
          exit_multivar
    case 'No'
       % Do nothing
end


% --- Executes on button press in goback.
function goback_Callback(hObject, eventdata, handles)
% hObject    handle to goback (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get position struct from gui/figure application data.
mstruct = getappdata(handles.output, 'gstruct');

% Update/modify structure
% Get rid of the handle of the current figure
mstruct.phandlerecord = mstruct.phandlerecord(1: length(mstruct.phandlerecord) - 1);

% Get position of the current GUI window 
mstruct.windowposition = get(gcf,'OuterPosition');

% Update root application data
setappdata(0, 'mlvappdata', mstruct);

% Get handle of previous page from figure appdata
% Activate previous gui window and delete the handle of the current window
set(getappdata(handles.output,'hprevpage'), 'OuterPosition',mstruct.windowposition,'Visible', 'On');
set(handles.output, 'Visible', 'Off');
delete(handles.output)



function moddisplay_Callback(hObject, eventdata, handles)
% hObject    handle to moddisplay (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of moddisplay as text
%        str2double(get(hObject,'String')) returns contents of moddisplay as a double


% --- Executes during object creation, after setting all properties.
function moddisplay_CreateFcn(hObject, eventdata, handles)
% hObject    handle to moddisplay (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in tosvdresp.
function tosvdresp_Callback(hObject, eventdata, handles)
% hObject    handle to tosvdresp (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

mstruct = getappdata(handles.output, 'gstruct');

% Update window position in structure
mstruct.windowposition = get(gcf,'OuterPosition');

% Update root application data
setappdata(0, 'mlvappdata', mstruct);

% Activate new GUI window and close the last window
set(svddt_gui, 'Visible', 'On');
set(handles.output, 'Visible', 'Off');

% Update handles structure
guidata(hObject, handles);



function dmoddisplay_Callback(hObject, eventdata, handles)
% hObject    handle to dmoddisplay (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of dmoddisplay as text
%        str2double(get(hObject,'String')) returns contents of dmoddisplay as a double


% --- Executes during object creation, after setting all properties.
function dmoddisplay_CreateFcn(hObject, eventdata, handles)
% hObject    handle to dmoddisplay (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
