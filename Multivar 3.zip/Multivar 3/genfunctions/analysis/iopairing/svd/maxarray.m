function [M, rIndx, cIndx] = maxarray(A)
% MAXARRAY  returns the maximum value of a numeric array and its index. 
% 
% SYNTAX
% [MAXM, INDX] = maxarray(M) returns the maximum value MAXM of a numeric 
% array M and its index INDX. 
% See also SVD_IOP.

% *************************************************************************
% Author:           Crystal Blackwell 
% Email:            Crystal.Blackwell@sta.uwi.edu
% Created:          January 2013; 
% Last revision:    29-June-2013;
% Useful websites:
%
% MATLAB VERSIONS USED IN PROGRAMMING PROCESS: 
% - MATLAB R2013a
%
% *************************************************************************
% NATIVE MATLAB FUNCTIONS USED TO CREATE THIS FUNCTION:
% nargin                    nargout                     error
% narginchk                 nargoutchk                  isnumeric
% max                                     
% *************************************************************************

    % Check for correct number of output arguments
    if nargout == 3
        % Check for correct number of input arguments
        if nargin == 1
            % Check to see that input is a numeric array
            if isnumeric(A) == 1
                M = max(max(A));
                [rIndx, cIndx] = find(A == M);  
            else
                % Display error if array is not numeric
                error('Multivar 1.0: M must be a numeric array.')
            end
        else
            % Display error if incorrect number of inputs
            narginchk(1, 1)
        end
    else
        % Display error if incorrect number of outputs
        nargoutchk(3, 3)
    end
end