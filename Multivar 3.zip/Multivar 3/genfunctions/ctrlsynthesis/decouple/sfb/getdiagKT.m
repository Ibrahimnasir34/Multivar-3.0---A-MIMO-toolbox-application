function [K, T] = getdiagKT(sys)
% SFBC  generates the state feedback gain matrix, K and the input gain 
% matrix, N for a state feedback control design determined via pole placement.
% 
% SYNTAX
% [K, T] = getdiagKT(SYS) returns a vector of steady state gains, K and a 
% vector of time constants, T for the diagonal elements of the system SYS 
% for use in the steady state decoupling function SFBD_GEN. The LTI system, 
% SYS  must contain no time delays and may be ss, tf or zpk.
% See also SFBD_GEN.

% *************************************************************************
% Author:           Crystal Blackwell 
% Email:            Crystal.Blackwell@sta.uwi.edu
% Created:          January 2013; 
% Last revision:    29-June-2013;
% Useful websites:
%
% MATLAB VERSIONS USED IN PROGRAMMING PROCESS: 
% - MATLAB R2013a
%
% *************************************************************************
% NATIVE MATLAB FUNCTIONS USED TO CREATE THIS FUNCTION:
% nargin                    nargout                     error
% narginchk                 nargoutchk                  size
% ones                      dcgain                      max
% real                      isstable                    pole
% abs                         
% *************************************************************************
% MULTIVAR FUNCTIONS USED TO CREATE THIS FUNCTION:
% modtyptest   
% *************************************************************************

    % Check for correct number of output arguments
    if nargout == 2
        
        % Check for correct number of input arguments
        if nargin == 1
            
            % Check type of model
            modnum = modtyptest(sys);
            if modnum == 2 || modnum == 4 || modnum == 6            

                % Determine the length that the K and T vectors are going
                % to be
                [m, p] = size(sys);
                if m < p
                    w = m;
                else
                    w = p;
                end

                % Preallocating K and T vectors
                K = ones(1, w);
                T = ones(1, w);

                for a = 1:1: w
                    % For  any order io channel, obtain the real part of
                    % the poles
                    iosys = sys(a, a);
                    pio = pole(iosys);
                    rpio = real(pio);                    
                    
                   
                    if isstable(iosys) == 1  % if io channel is stable                        
                        % Set steady state gain
                        K(a) = dcgain(iosys);
                        % Select the pole with the longest dynamics
                        mrpio = max(rpio);
                        
                    else % if io channel is NOT stable                        
                        % Set steady state gain
                        K(a) = -1* dcgain(iosys);                        
                        % Select the pole with the longest dynamics
                        mrpio = max(-1* abs(rpio));
                    end
                    
                    % if that pole is zero, set to a specific negative, non-zero value. 
                    if mrpio == 0
                        mrpio = -0.1;
                    end
                    % Determine time constant from the pole
                    T(a) = -1 / mrpio;

                end
            else                       
                error('Multivar 1.0: Inappropriate input system.')
            end    
        else
            % Display error if incorrect number of inputs
            narginchk(1, 1)
        end
        
    else
        % Display error if incorrect number of outputs
        nargoutchk(2, 2)
    end
end