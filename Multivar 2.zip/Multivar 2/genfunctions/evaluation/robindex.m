function [wti, msvti, wto, msvto,wsi, msvsi, wso, msvso] = robindex(Do, C, Di, G)
% ROBINDEX  Plots the input and output complementary sensitivity and sensitvity
% functions of a svd decoupled and controlled MIMO system.
%
% SYNTAX
% iiplot(SYS)
% (a)   robindex(Do, C, Di, G) plots the input and output complementary and
%       sensitvity functions on 4 subplots.
%        
% (b)   [wti, msvti, wto, msvto,wsi, msvsi, wso, msvso] = robindex(Do, C, Di, G)
%       returns 
%       1)  the vector of input complementary sensitivity values, msvti
%           and the corresponding vector of frequency values, wti
%       2)  the vector of output complementary sensitivity values msvto
%           and the corresponding vector of frequency values, wto.
%       3)  the vector of input sensitivity values msvsi
%           and the corresponding vector of frequency values, wsi.
%       4)  the vector of output sensitivity values msvso  
%           and the corresponding vector of frequency values, wsi.

% *************************************************************************
% Author:           Crystal Blackwell 
% Email:            Crystal.Blackwell@sta.uwi.edu
% Created:          January 2013; 
% Last revision:    29-June-2013;
% Useful websites:
%
% MATLAB VERSIONS USED IN PROGRAMMING PROCESS: 
% - MATLAB R2013a
%
% *************************************************************************
% NATIVE MATLAB FUNCTIONS USED TO CREATE THIS FUNCTION:
% sigma             size                max                 eye
% plot              subplot             gca                 xlabel
% ylabel            title               set                 eye
% *************************************************************************

F = Di * C * Do;

% Input uncertainty
Ti = F*G / (eye(size(F*G)) + F*G);
[svti,wti] = sigma(Ti);
msvti =   1./max(svti);

Si = inv(eye(size(F*G)) + F*G);
[svsi,wsi] = sigma(Si);
msvsi =   1./max(svsi);

% Output uncertainty
To = G*F / (eye(size(G*F)) + G*F);
[svto,wto] = sigma(To);
msvto =   1./max(svto);

So = inv(eye(size(G*F)) + G*F);
[svso,wso] = sigma(So);
msvso =   1./max(svso);
 
figure(1)
subplot(2, 2, 1)
plot(wti, msvti)
set(gca,'XScale','log','YScale','log')
ylabel('{\sigma}_m_a_x({\Delta}_i(j{\omega})) for Complementary Sensitivity function T', 'Color', [0 0 0])
xlabel('Frequency (rads/s)', 'Color', [0 0 0])

subplot(2, 2, 2)
plot(wto, msvto)
set(gca,'XScale','log','YScale','log')
ylabel('{\sigma}_m_a_x({\Delta}_o(j{\omega})) for Complementary Sensitivity function T', 'Color', [0 0 0])
xlabel('Frequency (rads/s)', 'Color', [0 0 0])

subplot(2, 2, 3)
plot(wsi, msvsi)
set(gca,'XScale','log','YScale','log')
ylabel('{\sigma}_m_a_x({\Delta}_i(j{\omega})) for Sensitivity function S', 'Color', [0 0 0])
xlabel('Frequency (rads/s)', 'Color', [0 0 0])

subplot(2, 2, 4)
plot(wso, msvso)
set(gca,'XScale','log','YScale','log')
ylabel('{\sigma}_m_a_x({\Delta}_o(j{\omega})) for Sensitivity function S', 'Color', [0 0 0])
xlabel('Frequency (rads/s)', 'Color', [0 0 0])


end