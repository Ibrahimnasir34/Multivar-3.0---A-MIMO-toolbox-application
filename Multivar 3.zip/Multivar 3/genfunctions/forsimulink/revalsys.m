function estring = revalsys(sys)
% REVALSYS  converts tf, zpk or ss system to equivalent string command.
% Useful for inputting sys property in LTI system block in Simulink. Can
% also be used with the EVAL function.
% 
% SYNTAX
% (a)   revalsys(Y) returns string command that can be used to generate Y. 
%        
% (b)   X = revalsys(Y) returns string command X that can be used to generate Y. 
% See also MODTYPTEST, REVALCELL, MAT2STR, EVAL.

% *************************************************************************
% Author:           Crystal Blackwell 
% Email:            Crystal.Blackwell@sta.uwi.edu
% Created:          January 2013; 
% Last revision:    29-June-2013;
% Useful websites:
%
% MATLAB VERSIONS USED IN PROGRAMMING PROCESS: 
% - MATLAB R2013a
%
% *************************************************************************
% NATIVE MATLAB FUNCTIONS USED TO CREATE THIS FUNCTION:
% nargin                    nargout                     error
% narginchk                 nargoutchk                  mat2str                 
% *************************************************************************
% MULTIVAR FUNCTIONS USED TO CREATE THIS FUNCTION:
% modtyptest                revalcell                                  
% *************************************************************************

    % Check for correct number of output arguments
    if nargout <= 1
        % Check for correct number of input arguments
        if nargin == 1

            modnum = modtyptest(sys); % Determine class of system
            % For tf systems with or without time delays
            if modnum == 1 || modnum == 2
                % Extract info from system
                num = sys.num;
                den = sys.den;
                del = sys.ioDelay;
                % Convert to string
                estringnum = revalcell(num);
                estringden = revalcell(den);
                estringdel = mat2str(del);
                estring = ['tf(', estringnum, ',', estringden, ',', '''ioDelay''',',', estringdel, ')'];
            end

            % For ss systems without time delays
            if modnum == 4
                % Extract info from system
                A = sys.a;
                B = sys.b;
                C = sys.c;
                D = sys.d;
                % Convert to string
                estringA = mat2str(A);
                estringB = mat2str(B);
                estringC = mat2str(C);
                estringD = mat2str(D);
                estring = ['ss(', estringA, ',' ,estringB, ',' , estringC, ',' , estringD, ')'];
            end

             % For zpk systems with or without time delays
             if modnum == 5 || modnum == 6
                % Extract info from system
                z = sys.z;
                p = sys.p;
                k = sys.k;
                del = sys.ioDelay;
                % Convert to string
                estringz = revalcell(z);
                estringp = revalcell(p);
                estringk = mat2str(k);
                estringdel = mat2str(del);
                estring = ['zpk(', estringz, ',', estringp, ',', estringk,',', '''ioDelay''',',', estringdel, ')'];            
             end

             % For invalid systems and ss systems with time delays
             if modnum == 0 || modnum == 3
                 error('System not compatible for use with this function.')
             end
        else
            % Display error if incorrect number of inputs
            narginchk(1, 1)
        end
    else
        % Display error if incorrect number of outputs
        nargoutchk(0, 1)
    end             
end