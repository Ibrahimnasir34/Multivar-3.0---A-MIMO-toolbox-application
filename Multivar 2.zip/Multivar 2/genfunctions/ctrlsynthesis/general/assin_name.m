function csys = assin_name(sys, csys, sbcpt)
% PID_VNAM  generates system CSYS with the input names designated
% by the SYS matrix model and the designated subscript.
% 
% SYNTAX
% CSYS = pid_vnam(SYS, CSYS, MPOS) returns the system CSYS with the input 
% and output name designated by the SYS matrix model. A subscript is also
% appended to the new names assigned to CSYS.
% See also IOSNAMES

% *************************************************************************
% Author:           Crystal Blackwell 
% Email:            Crystal.Blackwell@sta.uwi.edu
% Created:          January 2013; 
% Last revision:    29-June-2013;
% Useful websites:
%
% MATLAB VERSIONS USED IN PROGRAMMING PROCESS: 
% - MATLAB R2013a
%
% *************************************************************************
% NATIVE MATLAB FUNCTIONS USED TO CREATE THIS FUNCTION:
% nargin                    nargout                     error
% narginchk                 nargoutchk                  size
% length                    
% *************************************************************************
% MULTIVAR FUNCTIONS USED TO CREATE THIS FUNCTION:
% modtyptest                iosnames
% *************************************************************************  
    
    % Check for correct number of output arguments
    if nargout == 1
        
        % Check for correct number of input arguments
        if nargin == 3

            % Check type of model -sys
            modnum = modtyptest(sys);
            if modnum == 1 || modnum == 2 || modnum == 3 || modnum == 4 || modnum == 5 || modnum == 6
                sflag = 1; % set sflag high            
            else
                sflag = 0; % set sflag low
            end

            % Check type of model -csys
            modnum2 = modtyptest(csys);            
            if modnum2 == 1 || modnum2 == 2 || modnum2 == 3 || modnum2 == 4 || modnum2 == 5 || modnum2 == 6
                cflag = 1; % set cflag high
            else
                cflag = 0; % set cflag low
            end

            % Check that csys and sys are same size
            [mc, nc] = size(csys);
            [ms, ns] = size(sys);
            if mc <= ms && nc <= ns
                nflag = 1; % set nflag high 
            else
                nflag = 0; % set nflag low
            end
            
           
            if sflag == 1 && cflag == 1  && nflag == 1 % if inputs are acceptable
                % Assign names to un-named variables
                sys = iosnames(sys);                
               
                % Determining variable names from original system
                inname = sys.InputName;
%                 outname = sys.OutputName;

                % Assigning variable names to control system
                % Inputs
                for g = 1: 1: nc
                    c_inname{g} = [inname{g}, '_', sbcpt];
                end      
                csys.InputName = c_inname;

%                 % Outputs
%                 for h = 1: 1: length(outname)
%                     outname{h} = [outname{h}, '_c'];
%                 end  
%                 csys.OutputName = outname;
                
            else
                emessage = 'Multivar 1.0:';
                if sflag == 0
                    emessage = [emessage, 'System "sys" must be of type tf, ss, or zpk. '];
                end
                if cflag == 0
                    emessage = [emessage, 'System "csys" must be of type tf, ss, or zpk. '];
                end      
                if nflag == 0
                    emessage = [emessage, 'Both of the dimensions of "sys" must be greater that or equal to "csys". '];
                end 
                error(emessage)
            end
            
        else
            % Display error if incorrect number of inputs
            narginchk(3, 3)
        end
        
    else
        % Display error if incorrect number of outputs
        nargoutchk(1, 1)
    end                
 
end