function varargout = modeltype(varargin)
% MODELTYPE MATLAB code for modeltype.fig
%      MODELTYPE, by itself, creates a new MODELTYPE or raises the existing
%      singleton*.
%
%      H = MODELTYPE returns the handle to a new MODELTYPE or the handle to
%      the existing singleton*.
%
%      MODELTYPE('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in MODELTYPE.M with the given input arguments.
%
%      MODELTYPE('Property','Value',...) creates a new MODELTYPE or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before modeltype_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to modeltype_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help modeltype

% Last Modified by GUIDE v2.5 11-May-2014 18:41:57

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @modeltype_OpeningFcn, ...
                   'gui_OutputFcn',  @modeltype_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before modeltype is made visible.
function modeltype_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to modeltype (see VARARGIN)

% Choose default command line output for modeltype
handles.output = hObject;

% Get root application data
mstruct = getappdata(0, 'mlvappdata');

% Set position and size and title
set(handles.output, 'OuterPosition',mstruct.windowposition, 'Name', mstruct.gtitle);

% Set handle of previous page as gui/figure application data
setappdata(handles.output,'hprevpage',mstruct.phandlerecord(length(mstruct.phandlerecord)));

% Update the page handle record in the structure and then save structure as root application data
mstruct.phandlerecord = [mstruct.phandlerecord, handles.output];
setappdata(0, 'mlvappdata', mstruct)

% set gui page application data
setappdata(handles.output, 'gstruct', mstruct);

% Set Defaults
% Set Tag of selected object.
set(handles.poptions,'SelectedObject', handles.createss); 

% Get handles of all the objects inside of panss
ssobj = get(handles.panss, 'Children');

% Get handles of all the objects inside of pantf
tfobj = get(handles.pantf, 'Children');

% Get handles of all the objects inside of panzpk
zpkobj = get(handles.panzpk, 'Children');

% enable objects in first panel        
set(ssobj, 'Enable', 'on')
% disable objects in second panel
set(tfobj, 'Enable', 'off')
% disable objects in third panel
set(zpkobj, 'Enable', 'off')

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes modeltype wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = modeltype_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in nextbutt.
function nextbutt_Callback(hObject, eventdata, handles)
% hObject    handle to nextbutt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of nextbutt

% Get position struct from gui/figure application data.
mstruct = getappdata(handles.output, 'gstruct');

% Get data from textboxes depending on which radiobutton is selected
selbutt = get(handles.poptions,'SelectedObject');
switch selbutt
    case handles.createss
        ssout = str2double(get(handles.ssnumout,'String'));
        ssin =  str2double(get(handles.ssnumin,'String'));
        ssstate =  str2double(get(handles.ssnumstate,'String'));
        
        % Check if data is valid
        % check that entries are not empty
        if isempty(ssout)== 1    
            emessage = 'Multivar: Enter an integer for the number of outputs.';
            set(handles.msgbox,'String',emessage, 'ForegroundColor', [1 0 0]) 
        else
            if isempty(ssin)== 1
                emessage = 'Multivar: Enter an integer for the number of inputs.';
                set(handles.msgbox,'String',emessage, 'ForegroundColor', [1 0 0])
            else
                if isempty(ssstate)== 1                                    
                    emessage = 'Multivar: Enter an integer for the number of states.';
                    set(handles.msgbox,'String',emessage, 'ForegroundColor', [1 0 0])                
                else
                    % check that values are integers
                    if isposwnum(ssout) == 1             
                        if isposwnum(ssin) == 1 
                            if isposwnum(ssstate)== 1 
                                
                                % Clear message box
                                set(handles.msgbox,'String','')
                                
                                % If all three are valid execute, else provide error messages
                                A = zeros(ssstate, ssstate);
                                B = zeros(ssstate, ssin);
                                C = zeros(ssout, ssstate);
                                D = zeros(ssout, ssin);
                                sys_mod = ss(A, B, C, D);
                                
                                % Save emty system model to structure
                                mstruct.systemmodel = sys_mod;
                                
                                % Get position of the current GUI window and save as application window for
                                % the next GUI window.
                                mstruct.windowposition = get(gcf,'OuterPosition');

                                % Update root application data
                                setappdata(0, 'mlvappdata', mstruct);

                                % Activate new GUI window and close the last window
                                set(ssmimo_gui, 'Visible', 'On');
                                set(handles.output, 'Visible', 'Off');
                            else
                                emessage = 'Multivar: Enter an integer for the number of states.';
                                set(handles.msgbox,'String',emessage, 'ForegroundColor', [1 0 0]) 
                            end        
                        else
                            emessage = 'Multivar: Enter an integer for the number of inputs.';
                            set(handles.msgbox,'String',emessage, 'ForegroundColor', [1 0 0])
                        end    
                    else
                        emessage = 'Multivar: Enter an integer for the number of outputs.';
                        set(handles.msgbox,'String',emessage, 'ForegroundColor', [1 0 0]) 
                    end
                end
            end
        end

        
    case handles.createtf
        tfout = str2double(get(handles.tfnumout,'String'));
        tfin = str2double(get(handles.tfnumin,'String'));
        
        % Check if data is valid
        % check that entries are not empty
        if isempty(tfout) == 1   
            emessage = 'Multivar: Enter an integer for the number of outputs.';
            set(handles.msgbox,'String',emessage, 'ForegroundColor', [1 0 0]) 
        else
            if isempty(tfin) == 1
                emessage = 'Multivar: Enter an integer for the number of inputs.';
                set(handles.msgbox,'String',emessage, 'ForegroundColor', [1 0 0])
            else
                % check that values are integers
                if isposwnum(tfout) == 1             
                    if isposwnum(tfin) == 1   
                        
                        % Clear message box
                        set(handles.msgbox,'String','')  
                        
                        % If both are valid execute, else provide error messages
                        sys_mod = tf(zeros(tfout, tfin));                        
                       
                        % Save empty system model to structure
                        mstruct.systemmodel = sys_mod;  
                        
                        % Get position of the current GUI window and save as application window for
                        % the next GUI window.
                        mstruct.windowposition = get(gcf,'OuterPosition');

                        % Update root application data
                        setappdata(0, 'mlvappdata', mstruct);

                        % Activate new GUI window and close the last window
                        set(tfmimo_gui, 'Visible', 'On');
                        set(handles.output, 'Visible', 'Off');

                        % Update handles structure
                        guidata(hObject, handles);
                    else
                        emessage = 'Multivar: Enter an integer for the number of inputs.';
                        set(handles.msgbox,'String',emessage, 'ForegroundColor', [1 0 0])
                    end    
                else
                    emessage = 'Multivar: Enter an integer for the number of outputs.';
                    set(handles.msgbox,'String',emessage, 'ForegroundColor', [1 0 0]) 
                end
            end
        end
    case handles.createzpk
        zpkout = str2double(get(handles.zpknumout,'String'));
        zpkin = str2double(get(handles.zpknumin,'String'));
        
        % Check if data is valid
        % check that entries are not empty
        if isempty(zpkout) == 1   
            emessage = 'Multivar: Enter an integer for the number of outputs.';
            set(handles.msgbox,'String',emessage, 'ForegroundColor', [1 0 0]) 
        else
            if isempty(zpkin) == 1
                emessage = 'Multivar: Enter an integer for the number of inputs.';
                set(handles.msgbox,'String',emessage, 'ForegroundColor', [1 0 0])
            else
                % check that values are integers
                if isposwnum(zpkout) == 1            
                    if isposwnum(zpkin) == 1   
                        
                        % Clear message box
                        set(handles.msgbox,'String','')                        
                        
                        % If both are valid execute, else provide error messages
                        z = cell(zpkout, zpkin);
                        z(:) = {0};
                        p = cell(zpkout, zpkin);
                        p(:) = {0};
                        k = zeros(zpkout, zpkin);
                        sys_mod = zpk(z, p, k);                        
                       
                        % Save empty system model to structure
                        mstruct.systemmodel = sys_mod;  
                        
                        % Get position of the current GUI window and save as application window for
                        % the next GUI window.
                        mstruct.windowposition = get(gcf,'OuterPosition');

                        % Update root application data
                        setappdata(0, 'mlvappdata', mstruct);

                        % Activate new GUI window and close the last window
                        set(zpkmimo_gui, 'Visible', 'On');
                        set(handles.output, 'Visible', 'Off');

                        % Update handles structure
                        guidata(hObject, handles);
                    else
                        emessage = 'Multivar: Enter an integer for the number of inputs.';
                        set(handles.msgbox,'String',emessage, 'ForegroundColor', [1 0 0])
                    end    
                else
                    emessage = 'Multivar: Enter an integer for the number of outputs.';
                    set(handles.msgbox,'String',emessage, 'ForegroundColor', [1 0 0]) 
                end
            end
        end
end


function tfnumout_Callback(hObject, eventdata, handles)
% hObject    handle to tfnumout (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of tfnumout as text
%        str2double(get(hObject,'String')) returns contents of tfnumout as a double


% --- Executes during object creation, after setting all properties.
function tfnumout_CreateFcn(hObject, eventdata, handles)
% hObject    handle to tfnumout (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function ssnumout_Callback(hObject, eventdata, handles)
% hObject    handle to ssnumout (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of ssnumout as text
%        str2double(get(hObject,'String')) returns contents of ssnumout as a double


% --- Executes during object creation, after setting all properties.
function ssnumout_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ssnumout (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function ssnumin_Callback(hObject, eventdata, handles)
% hObject    handle to ssnumin (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of ssnumin as text
%        str2double(get(hObject,'String')) returns contents of ssnumin as a double


% --- Executes during object creation, after setting all properties.
function ssnumin_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ssnumin (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function ssnumstate_Callback(hObject, eventdata, handles)
% hObject    handle to ssnumstate (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of ssnumstate as text
%        str2double(get(hObject,'String')) returns contents of ssnumstate as a double


% --- Executes during object creation, after setting all properties.
function ssnumstate_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ssnumstate (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes when selected object is changed in poptions.
function poptions_SelectionChangeFcn(hObject, eventdata, handles)
% hObject    handle to the selected object in poptions 
% eventdata  structure with the following fields (see UIBUTTONGROUP)
%	EventName: string 'SelectionChanged' (read only)
%	OldValue: handle of the previously selected object or empty if none was selected
%	NewValue: handle of the currently selected object
% handles    structure with handles and user data (see GUIDATA)

% Get handles of all the objects inside of panss
ssobj = get(handles.panss, 'Children');

% Get handles of all the objects inside of pantf
tfobj = get(handles.pantf, 'Children');

% Get handles of all the objects inside of panzpk
zpkobj = get(handles.panzpk, 'Children');

% Get Tag of selected object.
bselected = get(handles.poptions,'SelectedObject'); 
switch bselected
    %Code for when the various togglebuttons are selected
    case handles.createss
        % enable objects in panel related to new value        
        set(ssobj, 'Enable', 'on')
        % disable objects in other panels  
        set(tfobj, 'Enable', 'off')
        set(zpkobj, 'Enable', 'off')
    case handles.createtf  
        % enable objects in panel related to new value 
        set(tfobj, 'Enable', 'on')
        % disable objects in other panels  
        set(ssobj, 'Enable', 'off')
        set(zpkobj, 'Enable', 'off')
    case handles.createzpk  
        % enable objects in panel related to new value 
        set(zpkobj, 'Enable', 'on')
        % disable objects in other panels  
        set(ssobj, 'Enable', 'off')
        set(tfobj, 'Enable', 'off')
end


function tfnumin_Callback(hObject, eventdata, handles)
% hObject    handle to tfnumin (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of tfnumin as text
%        str2double(get(hObject,'String')) returns contents of tfnumin as a double


% --- Executes during object creation, after setting all properties.
function tfnumin_CreateFcn(hObject, eventdata, handles)
% hObject    handle to tfnumin (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in goback.
function goback_Callback(hObject, eventdata, handles)
% hObject    handle to goback (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get structure from gui/figure application data
mstruct = getappdata(handles.output,'gstruct');

% Update/modify structure
% Get rid of the handle of the current figure
mstruct.phandlerecord = mstruct.phandlerecord(1: length(mstruct.phandlerecord) - 1);

% Get position of the current GUI window 
mstruct.windowposition = get(gcf,'OuterPosition');

% Update root application data
setappdata(0, 'mlvappdata', mstruct);

% Get handle of previous page from figure appdata
% Activate previous gui window and delete the handle of the current window
set(getappdata(handles.output,'hprevpage'), 'OuterPosition',mstruct.windowposition,'Visible', 'On');
set(handles.output, 'Visible', 'Off');
delete(handles.output)


% --- Executes when user attempts to close figure1.
function figure1_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: delete(hObject) closes the figure

% display a question dialog box 
selection = questdlg('Are you sure you want to close Multivar?','Close Request Function','Yes','No','Yes'); 

switch selection, 
    case 'Yes'     
        % delete all figures related to multivar
          mstruct = getappdata(handles.output,'gstruct');  
          delete(mstruct.phandlerecord) 
          exit_multivar
    case 'No'
       % Do nothing
end



function zpknumout_Callback(hObject, eventdata, handles)
% hObject    handle to zpknumout (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of zpknumout as text
%        str2double(get(hObject,'String')) returns contents of zpknumout as a double


% --- Executes during object creation, after setting all properties.
function zpknumout_CreateFcn(hObject, eventdata, handles)
% hObject    handle to zpknumout (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function zpknumin_Callback(hObject, eventdata, handles)
% hObject    handle to zpknumin (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of zpknumin as text
%        str2double(get(hObject,'String')) returns contents of zpknumin as a double


% --- Executes during object creation, after setting all properties.
function zpknumin_CreateFcn(hObject, eventdata, handles)
% hObject    handle to zpknumin (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function msgbox_Callback(hObject, eventdata, handles)
% hObject    handle to msgbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of msgbox as text
%        str2double(get(hObject,'String')) returns contents of msgbox as a double


% --- Executes during object creation, after setting all properties.
function msgbox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to msgbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
