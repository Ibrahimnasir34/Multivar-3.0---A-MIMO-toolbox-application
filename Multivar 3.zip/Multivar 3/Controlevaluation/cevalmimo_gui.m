function varargout = cevalmimo_gui(varargin)
% CEVALMIMO_GUI M-file for cevalmimo_gui.fig
%      CEVALMIMO_GUI, by itself, creates a new CEVALMIMO_GUI or raises the existing
%      singleton*.
%
%      H = CEVALMIMO_GUI returns the handle to a new CEVALMIMO_GUI or the handle to
%      the existing singleton*.
%
%      CEVALMIMO_GUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in CEVALMIMO_GUI.M with the given input arguments.
%
%      CEVALMIMO_GUI('Property','Value',...) creates a new CEVALMIMO_GUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before cevalmimo_gui_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to cevalmimo_gui_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help cevalmimo_gui

% Last Modified by GUIDE v2.5 26-May-2016 09:55:43

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @cevalmimo_gui_OpeningFcn, ...
                   'gui_OutputFcn',  @cevalmimo_gui_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before cevalmimo_gui is made visible.
function cevalmimo_gui_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to cevalmimo_gui (see VARARGIN)

% Choose default command line output for anal_gui
handles.output = hObject;

% Get root application data
mstruct = getappdata(0, 'mlvappdata');

% Set position and size and title
set(handles.output, 'OuterPosition',mstruct.windowposition, 'Name', mstruct.gtitle);

% Set handle of previous page as gui/figure application data
setappdata(handles.output,'hprevpage',mstruct.phandlerecord(length(mstruct.phandlerecord)));

% Update the page handle record in the structure and then save structure as root application data
mstruct.phandlerecord = [mstruct.phandlerecord, handles.output];
setappdata(0, 'mlvappdata', mstruct)

% set struct from root application data as gui/figure application data
setappdata(handles.output, 'gstruct', mstruct);

% Setting defaults
type_list{1} = 'Transient';
type_list{2} = 'Frequency Dependent';
set(handles.typepop,'String',type_list)
set(handles.typepop,'Value', 1)

trans_list{1} = 'Step Response';
trans_list{2} = 'Impulse Response';
trans_list{3} = 'Ramp Response';
trans_list{4} = 'Parabolic Response';
setappdata(handles.output, 'transsel', trans_list)

freq_list{1} = 'Bode';
freq_list{2} = 'Nyquist';
freq_list{3} = 'Nichols';        
setappdata(handles.output, 'freqsel', freq_list)

analtype = get(handles.typepop,'Value');
switch analtype
    case 1
        set(handles.analpop,'String',trans_list)
        set(handles.analpop,'Value', 1)
    case 2
        set(handles.analpop,'String',freq_list)
        set(handles.analpop,'Value', 1)
    otherwise
end


% Displaying original step response
horig = subplot(1,2,1); step(mstruct.arrsysmodel);
title('Step Response of ORIGINAL SYSTEM');

% Displaying control design step response
hctrl = subplot(1,2,2); step(mstruct.controlmodel);
title('Step Response of TOTAL CONTROL SYSTEM');

setappdata(handles.output, 'hsplots', [horig , hctrl])

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes cevalmimo_gui wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = cevalmimo_gui_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in goback.
function goback_Callback(hObject, eventdata, handles)
% hObject    handle to goback (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get position struct from gui/figure application data.
mstruct = getappdata(handles.output, 'gstruct');

% Update/modify structure
% Get rid of the handle of the current figure
mstruct.phandlerecord = mstruct.phandlerecord(1: length(mstruct.phandlerecord) - 1);

% Get position of the current GUI window 
mstruct.windowposition = get(gcf,'OuterPosition');

% Update root application data
setappdata(0, 'mlvappdata', mstruct);

% Get handle of previous page from figure appdata
% Activate previous gui window and delete the handle of the current window
set(getappdata(handles.output,'hprevpage'), 'OuterPosition',mstruct.windowposition,'Visible', 'On');
set(handles.output, 'Visible', 'Off');
delete(handles.output)


% --- Executes when user attempts to close figure1.
function figure1_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: delete(hObject) closes the figure

% display a question dialog box 
selection = questdlg('Are you sure you want to close Multivar?','Close Request Function','Yes','No','Yes'); 

switch selection, 
    case 'Yes'     
        % delete all figures related to multivar
          mstruct = getappdata(handles.output,'gstruct');  
          delete(mstruct.phandlerecord) 
          exit_multivar
    case 'No'
       % Do nothing
end


% --- Executes on selection change in typepop.
function typepop_Callback(hObject, eventdata, handles)
% hObject    handle to typepop (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns typepop contents as cell array
%        contents{get(hObject,'Value')} returns selected item from typepop

% Get figure/guivapplication data
mstruct = getappdata(handles.output,'gstruct');
trans_list = getappdata(handles.output, 'transsel');
freq_list = getappdata(handles.output, 'freqsel');

analtype = get(handles.typepop,'Value');
switch analtype
    case 1
        set(handles.analpop,'String',trans_list)
        set(handles.analpop,'Value', 1)

    case 2
        set(handles.analpop,'String',freq_list)
        set(handles.analpop,'Value', 1)        
    otherwise
end

% Determine type of analysis selected
analtype = get(handles.typepop,'Value');
analname = get(handles.analpop,'Value');

%Code for when the various options are selected
switch analtype
    case 1 
        switch analname 
            case 1
                    % Displaying original system step response
                    horig = subplot(1,2,1); step(mstruct.arrsysmodel);
                    title('Step Response of ORIGINAL SYSTEM');

                    % Displaying control design step response     
                    hctrl = subplot(1,2,2); step(mstruct.controlmodel);
                    title('Step Response of TOTAL CONTROL SYSTEM');

            case 2
                    % Displaying original system impulse response          
                    horig = subplot(1,2,1); impulse(mstruct.arrsysmodel);
                    title('Impulse Response of ORIGINAL SYSTEM');

                    % Displaying control design impulse response     
                    hctrl = subplot(1,2,2); impulse(mstruct.controlmodel);
                    title('Impulse Response of TOTAL CONTROL SYSTEM');

            case 3           
                    % Displaying original system ramp response           
                    horig = subplot(1,2,1); mlvramp(mstruct.arrsysmodel);
                    title('Ramp Response of ORIGINAL SYSTEM');

                    % Displaying control design ramp response
                    hctrl = subplot(1,2,2); mlvramp(mstruct.controlmodel);
                    title('Ramp Response of TOTAL CONTROL SYSTEM');

            case 4           
                    % Displaying original system parabolic response           
                    horig = subplot(1,2,1); mlvpara(mstruct.arrsysmodel);
                    title('Parabolic Response of TOTAL CONTROL SYSTEM');

                    % Displaying control design parabolic response
                    hctrl = subplot(1,2,2); mlvpara(mstruct.controlmodel);
                    title('Parabolic Response of TOTAL CONTROL SYSTEM');                

            otherwise
        end
    case 2
        switch analname 
            case 1
                    % Displaying original system bode plot
                    horig = subplot(1,2,1); bode(mstruct.arrsysmodel);
                    title('Bode Plots of ORIGINAL SYSTEM');

                    % Displaying control design bode plot     
                    hctrl = subplot(1,2,2); bode(mstruct.controlmodel);
                    title('Bode Plots of TOTAL CONTROL SYSTEM');

            case 2
                    % Displaying original system nyquist plot          
                    horig = subplot(1,2,1); nyquist(mstruct.arrsysmodel);
                    title('Nyquist Plots of ORIGINAL SYSTEM');

                    % Displaying control design nyquist plot     
                    hctrl = subplot(1,2,2); nyquist(mstruct.controlmodel);
                    title('Nyquist Plots of TOTAL CONTROL SYSTEM');

            case 3           
                    % Displaying original system nichols plot          
                    horig = subplot(1,2,1); nichols(mstruct.arrsysmodel);
                    title('Nichols Plots of ORIGINAL SYSTEM');

                    % Displaying control design nichols plot
                    hctrl = subplot(1,2,2); nichols(mstruct.controlmodel);
                    title('Nichols Plots of TOTAL CONTROL SYSTEM');      
            otherwise
        end
    otherwise
end   

if get(handles.gridctrl,'Value')== 1
    axes(horig)
    grid on
    axes(hctrl)
    grid on
else
    axes(horig)
    grid off
    axes(hctrl)
    grid off
end

setappdata(handles.output, 'hsplots', [horig , hctrl])


% --- Executes during object creation, after setting all properties.
function typepop_CreateFcn(hObject, eventdata, handles)
% hObject    handle to typepop (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on button press in ioeval.
function ioeval_Callback(hObject, eventdata, handles)
% hObject    handle to ioeval (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

mstruct = getappdata(handles.output, 'gstruct');

% For more detailed or better view of the analysis
analtype = get(handles.typepop,'Value');
analname = get(handles.analpop,'Value');
mstruct.cevalcurrent = [analtype, analname];

% Update window position in structure
mstruct.windowposition = get(gcf,'OuterPosition');

% Update root application data
setappdata(0, 'mlvappdata', mstruct);

% Activate new GUI window and close the last window
set(cevalio_gui, 'Visible', 'On');
set(handles.output, 'Visible', 'Off');

% Update handles structure
guidata(hObject, handles);


% --- Executes on button press in gridctrl.
function gridctrl_Callback(hObject, eventdata, handles)
% hObject    handle to gridctrl (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of gridctrl

if get(handles.gridctrl,'Value')== 1
    splothand = getappdata(handles.output, 'hsplots');
    axes(splothand(1))
    grid on
    axes(splothand(2))
    grid on
else
    splothand = getappdata(handles.output, 'hsplots');
    axes(splothand(1))
    grid off
    axes(splothand(2))
    grid off
end


% --- Executes on selection change in analpop.
function analpop_Callback(hObject, eventdata, handles)
% hObject    handle to analpop (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns analpop contents as cell array
%        contents{get(hObject,'Value')} returns selected item from analpop

% Get figure/guivapplication data
mstruct = getappdata(handles.output,'gstruct');

% Determine type of analysis selected
analtype = get(handles.typepop,'Value');
analname = get(handles.analpop,'Value');

%Code for when the various options are selected
switch analtype
    case 1 
        switch analname 
            case 1
                    % Displaying original system step response
                    horig = subplot(1,2,1); step(mstruct.arrsysmodel);
                    title('Step Response of ORIGINAL SYSTEM');

                    % Displaying control design step response     
                    hctrl = subplot(1,2,2); step(mstruct.controlmodel);
                    title('Step Response of TOTAL CONTROL SYSTEM');

            case 2
                    % Displaying original system impulse response          
                    horig = subplot(1,2,1); impulse(mstruct.arrsysmodel);
                    title('Impulse Response of ORIGINAL SYSTEM');

                    % Displaying control design impulse response     
                    hctrl = subplot(1,2,2); impulse(mstruct.controlmodel);
                    title('Impulse Response of TOTAL CONTROL SYSTEM');

            case 3           
                    % Displaying original system ramp response           
                    horig = subplot(1,2,1); mlvramp(mstruct.arrsysmodel);
                    title('Ramp Response of ORIGINAL SYSTEM');

                    % Displaying control design ramp response
                    hctrl = subplot(1,2,2); mlvramp(mstruct.controlmodel);
                    title('Ramp Response of TOTAL CONTROL SYSTEM');

            case 4           
                    % Displaying original system parabolic response           
                    horig = subplot(1,2,1); mlvpara(mstruct.arrsysmodel);
                    title('Parabolic Response of TOTAL CONTROL SYSTEM');

                    % Displaying control design parabolic response
                    hctrl = subplot(1,2,2); mlvpara(mstruct.controlmodel);
                    title('Parabolic Response of TOTAL CONTROL SYSTEM');                

            otherwise
        end
    case 2
        switch analname 
            case 1
                    % Displaying original system bode plot
                    horig = subplot(1,2,1); bode(mstruct.arrsysmodel);
                    title('Bode Plots of ORIGINAL SYSTEM');

                    % Displaying control design bode plot     
                    hctrl = subplot(1,2,2); bode(mstruct.controlmodel);
                    title('Bode Plots of TOTAL CONTROL SYSTEM');

            case 2
                    % Displaying original system nyquist plot          
                    horig = subplot(1,2,1); nyquist(mstruct.arrsysmodel);
                    title('Nyquist Plots of ORIGINAL SYSTEM');

                    % Displaying control design nyquist plot     
                    hctrl = subplot(1,2,2); nyquist(mstruct.controlmodel);
                    title('Nyquist Plots of TOTAL CONTROL SYSTEM');

            case 3           
                    % Displaying original system nichols plot          
                    horig = subplot(1,2,1); nichols(mstruct.arrsysmodel);
                    title('Nichols Plots of ORIGINAL SYSTEM');

                    % Displaying control design nichols plot
                    hctrl = subplot(1,2,2); nichols(mstruct.controlmodel);
                    title('Nichols Plots of TOTAL CONTROL SYSTEM');      
            otherwise
        end
    otherwise
end   


if get(handles.gridctrl,'Value')== 1
    axes(horig)
    grid on
    axes(hctrl)
    grid on
else
    axes(horig)
    grid off
    axes(hctrl)
    grid off
end

setappdata(handles.output, 'hsplots', [horig , hctrl])
   



% --- Executes during object creation, after setting all properties.
function analpop_CreateFcn(hObject, eventdata, handles)
% hObject    handle to analpop (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in nextbutt.
function nextbutt_Callback(hObject, eventdata, handles)
% hObject    handle to nextbutt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get position struct from gui/figure application data.
mstruct = getappdata(handles.output, 'gstruct');

% Update window position in structure
mstruct.windowposition = get(gcf,'OuterPosition');

% Update root application data
setappdata(0, 'mlvappdata', mstruct);

% Activate new GUI window and close the last window
set(final_gui, 'Visible', 'On');
set(handles.output, 'Visible', 'Off');

% Update handles structure
guidata(hObject, handles);


% --- Executes on button press in pfipage.
function pfipage_Callback(hObject, eventdata, handles)
% hObject    handle to pfipage (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get position struct from gui/figure application data.
mstruct = getappdata(handles.output, 'gstruct');

% Update window position in structure
mstruct.windowposition = get(gcf,'OuterPosition');

% Update root application data
setappdata(0, 'mlvappdata', mstruct);

% Activate new GUI window and close the last window
set(pfresults, 'Visible', 'On');
set(handles.output, 'Visible', 'Off');

% Update handles structure
guidata(hObject, handles);


% --- Executes on button press in iipage.
function iipage_Callback(hObject, eventdata, handles)
% hObject    handle to iipage (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get position struct from gui/figure application data.
mstruct = getappdata(handles.output, 'gstruct');

% Update window position in structure
mstruct.windowposition = get(gcf,'OuterPosition');

% Update root application data
setappdata(0, 'mlvappdata', mstruct);

% Activate new GUI window and close the last window
set(frq_interaction, 'Visible', 'On');
set(handles.output, 'Visible', 'Off');

% Update handles structure
guidata(hObject, handles);
