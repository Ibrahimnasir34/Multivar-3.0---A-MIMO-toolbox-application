function [Abar, Bbar, Cbar, Dbar, T, k] = kcsf(sys)
% KCSF  generate the Kalman Controllable Staircase Form(KCSF)of a supplied 
% MIMO system.
% 
% SYNTAX
% [Abar, Bbar, Cbar, Dbar, T, k] = kcsf(sys) returns the Kalman Controllable
% Staircase Form(KCSF)of the MIMO system SYS and its matrices Abar, Bbar, 
% Cbar, Dbar, and the Transformation matrix T. k represents the number of 
% controllable states factored out during each step of the transformation 
% matrix calculation.

% *************************************************************************
% Author:           Crystal Blackwell 
% Email:            Crystal.Blackwell@sta.uwi.edu
% Created:          January 2013; 
% Last revision:    29-June-2013;
% Useful websites:
%
% MATLAB VERSIONS USED IN PROGRAMMING PROCESS: 
% - MATLAB R2013a
%
% *************************************************************************
% NATIVE MATLAB FUNCTIONS USED TO CREATE THIS FUNCTION:
% class                     ctrbf                                           
% *************************************************************************


    % Check if input argument is a state-space system
    if strcmp(class(sys), 'ss') == 1
        A = sys.a;
        B = sys.b;
        C = sys.c;
        D = sys.d;
        [Abar,Bbar,Cbar,T,k] = ctrbf(A,B,C);
        Dbar = D;
    else
        % error('Multivar 1.0: System must be in state space form.')
        Abar = [];
        Bbar = [];
        Cbar = [];
        Dbar = [];
        T = [];
        k = [];        
    end
end





