function estring = revalcell(carray)
% REVALCELL  converts a cell array of numeric arrays to a string command. 
% Can be used with the EVAL function.
% 
% SYNTAX
% (a)   revalcell(Y) returns string command that can be used to generate Y.  
%        
% (b)   X = revalcell(Y) returns string command X that can be used to generate Y. 
% See also REVALCELL, MAT2STR, EVAL.

% *************************************************************************
% Author:           Crystal Blackwell 
% Email:            Crystal.Blackwell@sta.uwi.edu
% Created:          January 2013; 
% Last revision:    29-June-2013;
% Useful websites:
%
% MATLAB VERSIONS USED IN PROGRAMMING PROCESS: 
% - MATLAB R2013a
%
% *************************************************************************
% NATIVE MATLAB FUNCTIONS USED TO CREATE THIS FUNCTION:
% nargin                    nargout                     error
% narginchk                 nargoutchk                  iscell
% cellfun                   cell2mat                         
% *************************************************************************

    % Check for correct number of output arguments
    if nargout <= 1
        % Check for correct number of input arguments
        if nargin == 1
            
            [m,n] = size(carray);
            estring = '{';
            % walk through each element of the cell array
            for g = 1:1:m
                for h = 1:1:n
                    % convert the array found at that cell array position
                    % to a string
                    estringvec = mat2str(carray{g,h});  
                    
                    if h == n % if at the end of the row
                        % add string and semicolon to the orginal string
                        estring = [estring, estringvec, ';']; 
                    else % otherwise
                        % add string and comma to the orginal string
                        estring = [estring, estringvec, ','];
                    end
                end
            end
            % Change final semicolon to closing curly bracket
            estring(length(estring))= '}';
            
        else
            % Display error if incorrect number of inputs
            narginchk(1, 1)
        end
    else
        % Display error if incorrect number of outputs
        nargoutchk(0, 1)
    end       
end