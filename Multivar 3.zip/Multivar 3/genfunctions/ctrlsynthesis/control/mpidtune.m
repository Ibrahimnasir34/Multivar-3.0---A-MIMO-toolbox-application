function C = mpidtune(sys, type)
[m, p] = size(sys);
if m <p
    a = m;
else
    a = p;
end

C = tf(zeros(a));
for k = 1: 1: a
    iosys  = sys(k, k);
    % Tune controller
    iopid = pidtune(iosys,type);
    C(k, k) = iopid;
end



