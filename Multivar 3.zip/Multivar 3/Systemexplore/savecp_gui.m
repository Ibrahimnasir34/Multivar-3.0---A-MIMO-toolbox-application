function varargout = savecp_gui(varargin)
% SAVECP_GUI MATLAB code for savecp_gui.fig
%      SAVECP_GUI, by itself, creates a new SAVECP_GUI or raises the existing
%      singleton*.
%
%      H = SAVECP_GUI returns the handle to a new SAVECP_GUI or the handle to
%      the existing singleton*.
%
%      SAVECP_GUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in SAVECP_GUI.M with the given input arguments.
%
%      SAVECP_GUI('Property','Value',...) creates a new SAVECP_GUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before savecp_gui_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to savecp_gui_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help savecp_gui

% Last Modified by GUIDE v2.5 23-Nov-2017 16:57:55

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @savecp_gui_OpeningFcn, ...
                   'gui_OutputFcn',  @savecp_gui_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before savecp_gui is made visible.
function savecp_gui_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to savecp_gui (see VARARGIN)

% Choose default command line output for savecp_gui
handles.output = hObject;

% Get root application data
mstruct = getappdata(0, 'mlvappdata');

% Set position and size and title
set(handles.output, 'OuterPosition',mstruct.windowposition, 'Name', mstruct.gtitle);

% Set handle of previous page as gui/figure application data
setappdata(handles.output,'hprevpage',mstruct.phandlerecord(length(mstruct.phandlerecord)));

% Update the page handle record in the structure and then save structure as root application data
mstruct.phandlerecord = [mstruct.phandlerecord, handles.output];
setappdata(0, 'mlvappdata', mstruct)

% set struct from root application data as gui/figure application data
setappdata(handles.output, 'gstruct', mstruct);

% Set Defaults
% get application data
mstruct = getappdata(handles.output,'gstruct');

% get default path and model file name
deffol = mstruct.projectpath;
filename = mstruct.matfile;

% generate default name for control system
defname = [filename(1:length(filename)-4), '_param']; % take off .mat off filename and append '_param'
cnt = 1; 
filepath = [deffol, '\', defname, num2str(cnt), '.mat'];
% check if filename exists at path
while(exist(filepath, 'file'))
    % if so increment count
    cnt = cnt + 1;
    filepath = [deffol, '\', defname, num2str(cnt), '.mat'];
end
[deffol, defname, ext] = fileparts(filepath);

set(handles.saveloc,'String', deffol);
set(handles.csname, 'String', defname);

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes savecp_gui wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = savecp_gui_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



% --- Executes on button press in savebutt.
function savebutt_Callback(hObject, eventdata, handles)
% hObject    handle to savebutt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of savebutt

slocation = get(handles.saveloc,'String');
csmodel = get(handles.csname,'String');

% Check if location is valid 
if(exist(slocation, 'dir'))

    % Check if name for file is entered 
    if isempty(csmodel)
        emessage = 'Multivar 1.0: Enter name';
        set(handles.msgbox,'String',emessage, 'ForegroundColor', [1 0 0])
    else % If name was entered, get information        
        fpath = [slocation, '\', csmodel, '.mat'];

        % check if .MAT file exists and if so display error message
        if(exist(fpath, 'file'))
            emessage = 'Multivar 1.0: .MAT file already exists';
            set(handles.msgbox,'String',emessage, 'ForegroundColor', [1 0 0]) 
        else
            % set struct from root application data as gui/figure application data
            mstruct = getappdata(handles.output, 'gstruct');
            dectrlinfo = [mstruct.decopinfo, mstruct.controlinfo];
            % Save model to .mat file 
            eval([csmodel, '= dectrlinfo;'])
            save(fpath, csmodel);

            % Display save message
            emessage = ['Multivar 1.0: Control system model saved to ', fpath, '.'];
            set(handles.msgbox,'String',emessage, 'ForegroundColor', [0 0 1])  

        end
    end
end
    
% Update handles structure
guidata(hObject, handles);


function saveloc_Callback(hObject, eventdata, handles)
% hObject    handle to saveloc (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of saveloc as text
%        str2double(get(hObject,'String')) returns contents of saveloc as a double


% --- Executes during object creation, after setting all properties.
function saveloc_CreateFcn(hObject, eventdata, handles)
% hObject    handle to saveloc (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function csname_Callback(hObject, eventdata, handles)
% hObject    handle to csname (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of csname as text
%        str2double(get(hObject,'String')) returns contents of csname as a double


% --- Executes during object creation, after setting all properties.
function csname_CreateFcn(hObject, eventdata, handles)
% hObject    handle to csname (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function browloc_CreateFcn(hObject, eventdata, handles)
% hObject    handle to browloc (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes on button press in browloc.
function browloc_Callback(hObject, eventdata, handles)
% hObject    handle to browloc (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get last location and open dialog box for retrieving folders
foldloc = get(handles.saveloc, 'String');
get_dir = uigetdir(foldloc);

% Display selection if vaid
if get_dir ~= 0
    set(handles.saveloc,'String', get_dir );
end





% --- Executes when user attempts to close figure1.
function figure1_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: delete(hObject) closes the figure

% display a question dialog box 
selection = questdlg('Are you sure you want to close Multivar?','Close Request Function','Yes','No','Yes'); 

switch selection, 
    case 'Yes'     
        % delete all figures related to multivar
          mstruct = getappdata(handles.output,'gstruct');  
          delete(mstruct.phandlerecord) 
          exit_multivar
    case 'No'
       % Do nothing
end


% --- Executes on button press in go_back.
function go_back_Callback(hObject, eventdata, handles)
% hObject    handle to go_back (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get structure from gui/figure application data
mstruct = getappdata(handles.output,'gstruct');

% Update/modify structure
% Get rid of the handle of the current figure
mstruct.phandlerecord = mstruct.phandlerecord(1: length(mstruct.phandlerecord) - 1);

% Get position of the current GUI window 
mstruct.windowposition = get(gcf,'OuterPosition');

% Update root application data
setappdata(0, 'mlvappdata', mstruct);

% Get handle of previous page from figure appdata
% Activate previous gui window and delete the handle of the current window
set(getappdata(handles.output,'hprevpage'), 'OuterPosition',mstruct.windowposition,'Visible', 'On');
set(handles.output, 'Visible', 'Off');
delete(handles.output)



function msgbox_Callback(hObject, eventdata, handles)
% hObject    handle to msgbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of msgbox as text
%        str2double(get(hObject,'String')) returns contents of msgbox as a double


% --- Executes during object creation, after setting all properties.
function msgbox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to msgbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
