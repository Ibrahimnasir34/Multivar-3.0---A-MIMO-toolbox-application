function varargout = svddec(varargin)
% SVDDEC M-file for svddec.fig
%      SVDDEC, by itself, creates a new SVDDEC or raises the existing
%      singleton*.
%
%      H = SVDDEC returns the handle to a new SVDDEC or the handle to
%      the existing singleton*.
%
%      SVDDEC('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in SVDDEC.M with the given input arguments.
%
%      SVDDEC('Property','Value',...) creates a new SVDDEC or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before svddec_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to svddec_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help svddec

% Last Modified by GUIDE v2.5 23-Nov-2017 14:45:42

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @svddec_OpeningFcn, ...
                   'gui_OutputFcn',  @svddec_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before svddec is made visible.
function svddec_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to svddec (see VARARGIN)

% Choose default command line output for svddec
handles.output = hObject;

% Get root application data
mstruct = getappdata(0, 'mlvappdata');

% Set position and size and title
set(handles.output, 'OuterPosition',mstruct.windowposition, 'Name', mstruct.gtitle);

% Set handle of previous page as gui/figure application data
setappdata(handles.output,'hprevpage',mstruct.phandlerecord(length(mstruct.phandlerecord)));

% Update the page handle record in the structure and then save structure as root application data
mstruct.phandlerecord = [mstruct.phandlerecord, handles.output];
setappdata(0, 'mlvappdata', mstruct)

% set struct from root application data as gui/figure application data
setappdata(handles.output, 'gstruct', mstruct);

% Setting defaults
% Display image
imshow('svdpic.jpg');

% Setting model display
switch class(mstruct.arrsysmodel)
    case 'tf'
        sys = mstruct.arrsysmodel;
    case 'zpk'
        sys = mstruct.arrsysmodel;
    case 'ss'
        sys = mstruct.arrsysmodel;
    otherwise
        return
end
% Set model (exact or approximate) for decoupling as gui/figure application data
setappdata(handles.output, 'modfordecop', sys);

sys_text = evalc('sys');
tlines = strsplit(sys_text,'\n');
set(handles.moddisplay,'FontName', 'Monospaced','String',tlines);

% Displaying steady state values
%Display number of inputs and outputs for original model
[m, r] = size(sys);
sm = num2str(m);
sr = num2str(r);
set(handles.noout,'String',sm);
set(handles.noin,'String',sr);

% Performing SVD
[U, S, V] = svd(dcgain(sys));
if m==1 || r ==1
    scalval = S(1,1);
else
    scalval = diag(S);
end
[U, S, V, Sc, precomp, postcomp] = svdd(sys, scalval, 0);
dsys = svdd_gen(sys, precomp, postcomp);

% No of loops controlled
[m2, r2] = size(S);
sm2 = num2str(m2);
set(handles.nocl,'String',sm2);

% Condition no.
CN = cond(S);
sCN = num2str(CN);
set(handles.sscn,'String',sCN);

%Displaying matrices U, S, V and scalvec
scalmat =1 :1: m2;
scalmat =[scalmat', scalval];
set(handles.umatrix,'Data',U, 'BackgroundColor',[0.5 1 0.5],'ColumnEditable', false);
set(handles.smatrix,'Data',S, 'BackgroundColor',[1 1 0.5]  ,'ColumnEditable', false);
set(handles.vmatrix,'Data',V, 'BackgroundColor',[0.5 1 1]  ,'ColumnEditable', false);
set(handles.scalvec,'Data',scalmat, 'BackgroundColor',[1 0.5 1]  ,'ColumnEditable', [false, true]);

%Displaying compensator matrices
set(handles.mprecomp,'Data',precomp, 'BackgroundColor',[0.5 1 1]  ,'ColumnEditable', false);
set(handles.mpostcomp,'Data',postcomp, 'BackgroundColor',[0.7 0.7 1]  ,'ColumnEditable', false);

% Setting decoupled model display
dsys_text = evalc('dsys');
tlines = strsplit(dsys_text,'\n');
set(handles.dmoddisplay,'FontName', 'Monospaced', 'String',tlines); 

%Display number of inputs and outputs for decoupled system
[dm, dr] = size(dsys);
dsm = num2str(dm);
dsr = num2str(dr);
set(handles.dnoout,'String',dsm);
set(handles.dnoin,'String',dsr);


% Update handles structure
guidata(hObject, handles);

% UIWAIT makes svddec wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = svddec_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes during object creation, after setting all properties.
function sscn_CreateFcn(hObject, eventdata, handles)
% hObject    handle to sscn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes when user attempts to close figure1.
function figure1_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: delete(hObject) closes the figure

% display a question dialog box 
selection = questdlg('Are you sure you want to close Multivar?','Close Request Function','Yes','No','Yes'); 

switch selection, 
    case 'Yes'     
        % delete all figures related to multivar
          mstruct = getappdata(handles.output,'gstruct');  
          delete(mstruct.phandlerecord) 
          exit_multivar
    case 'No'
       % Do nothing
end


% --- Executes on button press in goback.
function goback_Callback(hObject, eventdata, handles)
% hObject    handle to goback (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get position struct from gui/figure application data.
mstruct = getappdata(handles.output, 'gstruct');

% Update/modify structure
% Get rid of the handle of the current figure
mstruct.phandlerecord = mstruct.phandlerecord(1: length(mstruct.phandlerecord) - 1);

% Get position of the current GUI window 
mstruct.windowposition = get(gcf,'OuterPosition');

% Update root application data
setappdata(0, 'mlvappdata', mstruct);

% Get handle of previous page from figure appdata
% Activate previous gui window and delete the handle of the current window
set(getappdata(handles.output,'hprevpage'), 'OuterPosition',mstruct.windowposition,'Visible', 'On');
set(handles.output, 'Visible', 'Off');
delete(handles.output)



function moddisplay_Callback(hObject, eventdata, handles)
% hObject    handle to moddisplay (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of moddisplay as text
%        str2double(get(hObject,'String')) returns contents of moddisplay as a double


% --- Executes during object creation, after setting all properties.
function moddisplay_CreateFcn(hObject, eventdata, handles)
% hObject    handle to moddisplay (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in nextbutt.
function nextbutt_Callback(hObject, eventdata, handles)
% hObject    handle to nextbutt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% get gui/figure application data
mstruct = getappdata(handles.output, 'gstruct');
sys = getappdata(handles.output, 'modfordecop');

% Save decoupling info
scalmat = get(handles.scalvec, 'Data');
scalval = scalmat(:,2);
[U, S, V, Sc, precomp, postcomp] = svdd(sys, scalval,0);
dsys = svdd_gen(sys, precomp, postcomp);
mstruct.decopinfo = {precomp, postcomp, dsys};

% Update control model
mstruct.controlmodel = dsys;

% Update window position in structure
mstruct.windowposition = get(gcf,'OuterPosition');

% Update root application data
setappdata(0, 'mlvappdata', mstruct);

% Activate new GUI window and close the last window
set(svddec2,'Visible', 'On');
set(handles.output, 'Visible', 'Off');

% Update handles structure
guidata(hObject, handles);



function dmoddisplay_Callback(hObject, eventdata, handles)
% hObject    handle to dmoddisplay (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of dmoddisplay as text
%        str2double(get(hObject,'String')) returns contents of dmoddisplay as a double


% --- Executes during object creation, after setting all properties.
function dmoddisplay_CreateFcn(hObject, eventdata, handles)
% hObject    handle to dmoddisplay (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function msgbox_Callback(hObject, eventdata, handles)
% hObject    handle to msgbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of msgbox as text
%        str2double(get(hObject,'String')) returns contents of msgbox as a double


% --- Executes during object creation, after setting all properties.
function msgbox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to msgbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes when entered data in editable cell(s) in scalvec.
function scalvec_CellEditCallback(hObject, eventdata, handles)
% hObject    handle to scalvec (see GCBO)
% eventdata  structure with the following fields (see UITABLE)
%	Indices: row and column indices of the cell(s) edited
%	PreviousData: previous data for the cell(s) edited
%	EditData: string(s) entered by the user
%	NewData: EditData or its converted form set on the Data property. Empty if Data was not changed
%	Error: error string when failed to convert EditData to appropriate value for Data
% handles    structure with handles and user data (see GUIDATA)

% get gui/figure application data
sys = getappdata(handles.output, 'modfordecop');

% Get scaling values from gui
scalmat = get(handles.scalvec, 'Data');
scalval = scalmat(:,2);
[U, S, V, Sc, precomp, postcomp] = svdd(sys, scalval, 0);
dsys = svdd_gen(sys, precomp, postcomp);

CN = cond(S);
sCN = num2str(CN);
set(handles.sscn,'String',sCN);

%Update postcompensator matrix
set(handles.mpostcomp,'Data',postcomp);

% Update decoupled model display
dsys_text = evalc('dsys');
tlines = strsplit(dsys_text,'\n');
set(handles.dmoddisplay,'FontName', 'Monospaced', 'String',tlines); 

% Update handles structure
guidata(hObject, handles);


% --- Executes when uipanel31 is resized.
function uipanel31_ResizeFcn(hObject, eventdata, handles)
% hObject    handle to uipanel31 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
