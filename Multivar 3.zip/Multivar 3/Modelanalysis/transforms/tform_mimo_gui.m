function varargout = tform_mimo_gui(varargin)
% TFORM_MIMO_GUI M-file for tform_mimo_gui.fig
%      TFORM_MIMO_GUI, by itself, creates a new TFORM_MIMO_GUI or raises the existing
%      singleton*.
%
%      H = TFORM_MIMO_GUI returns the handle to a new TFORM_MIMO_GUI or the handle to
%      the existing singleton*.
%
%      TFORM_MIMO_GUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in TFORM_MIMO_GUI.M with the given input arguments.
%
%      TFORM_MIMO_GUI('Property','Value',...) creates a new TFORM_MIMO_GUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before tform_mimo_gui_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to tform_mimo_gui_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help tform_mimo_gui

% Last Modified by GUIDE v2.5 20-Dec-2013 19:24:48

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @tform_mimo_gui_OpeningFcn, ...
                   'gui_OutputFcn',  @tform_mimo_gui_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before tform_mimo_gui is made visible.
function tform_mimo_gui_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to tform_mimo_gui (see VARARGIN)

% Choose default command line output for tform_mimo_gui
handles.output = hObject;

% Get root application data
mstruct = getappdata(0, 'mlvappdata');

% Set position and size and title
set(handles.output, 'OuterPosition',mstruct.windowposition, 'Name', mstruct.gtitle);

% Set handle of previous page as gui/figure application data
setappdata(handles.output,'hprevpage',mstruct.phandlerecord(length(mstruct.phandlerecord)));

% Update the page handle record in the structure and then save structure as root application data
mstruct.phandlerecord = [mstruct.phandlerecord, handles.output];
setappdata(0, 'mlvappdata', mstruct)

% set struct from root application data as gui/figure application data
setappdata(handles.output, 'gstruct', mstruct);

% Setting defaults
switch mstruct.modnum
    case 1
        % tf with delays
        G = ss(mstruct.approxmodel);
    case 2
        % tf without delays
        G = mstruct.approxmodel;
    case 4
        % ss without delays
        G = mstruct.systemmodel;
    case 5
        % zpk with delays
        G = ss(mstruct.approxmodel);
    case 6
        % zpk without delays
        G = mstruct.approxmodel;
end
% set appropriate model form as gui/figure application data depending on
% classification of system
setappdata(handles.output, 'formmod', G);


% Set properties for tables Abar, Bbar, Cbar, Dbar
set(handles.Atable,'BackgroundColor',[1 1 0.75],'ColumnEditable', false,'ColumnWidth', {170});
set(handles.Btable,'BackgroundColor',[1 1 0.75],'ColumnEditable', false,'ColumnWidth', {170});
set(handles.Ctable,'BackgroundColor',[1 1 0.75],'ColumnEditable', false,'ColumnWidth', {170});
set(handles.Dtable,'BackgroundColor',[1 1 0.75], 'ColumnEditable', false,'ColumnWidth', {170});
set(handles.Ttable,'BackgroundColor',[0.75 0.75 1],'ColumnEditable', false,'ColumnWidth', {170});


% Set default to MCF
set(handles.uibuttongroup1,'SelectedObject', handles.morig);
desstr = 'The original system or an approximation of the original system is displayed.';
set(handles.fdesc,'String',desstr);

% Set values for tables A, B, C, D, T
set(handles.Atable,'Data',G.a,'ColumnWidth', {170});
set(handles.Btable,'Data',G.b,'ColumnWidth', {170});
set(handles.Ctable,'Data',G.c,'ColumnWidth', {170});
set(handles.Dtable,'Data',G.d,'ColumnWidth', {170});
T = [];
set(handles.Ttable,'Data',T,'ColumnWidth', {170});
set(handles.msgbox, 'String', '')

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes tform_mimo_gui wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = tform_mimo_gui_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes when selected object is changed in uibuttongroup1.
function uibuttongroup1_SelectionChangeFcn(hObject, eventdata, handles)
% hObject    handle to the selected object in uibuttongroup1 
% eventdata  structure with the following fields (see UIBUTTONGROUP)
%	EventName: string 'SelectionChanged' (read only)
%	OldValue: handle of the previously selected object or empty if none was selected
%	NewValue: handle of the currently selected object
% handles    structure with handles and user data (see GUIDATA)
 
% Get state space matrices from application data
G = getappdata(handles.output,'formmod');

%Get Tag of selected object.
bselected = get(handles.uibuttongroup1,'SelectedObject'); 

%Code for when the various togglebuttons are selected
switch bselected 
    case handles.morig
        desstr = 'The original system or an approximation of the original system is displayed.';
        set(handles.fdesc,'String',desstr);
        
        % Set values for tables A, B, C, D, T
        set(handles.Atable,'Data',G.a,'ColumnWidth', {170});
        set(handles.Btable,'Data',G.b,'ColumnWidth', {170});
        set(handles.Ctable,'Data',G.c,'ColumnWidth', {170});
        set(handles.Dtable,'Data',G.d,'ColumnWidth', {170});
        T = [];
        set(handles.Ttable,'Data',T, 'ColumnWidth', {170});
        set(handles.msgbox, 'String', '')
        
    case handles.bmcf
        desstr = ['The Modal Canonical Form(MCF) is a similarity ',...
            'transformation. In modal form, "A" is a block-diagonal matrix.',...
            'The block size is typically 1-by-1 for real eigenvalues and ',...
            '2-by-2 for complex eigenvalues. However, if there are repeated ',...
            'eigenvalues or clusters of nearby eigenvalues, the block size ',...
            'can be larger.''Note: Whenever a similarity transformation is ',...
            'performed, the properties of the the transformed system (e.g. ',...
            'the characteristic equation, eigenvectors, eigenvalues,and ',...
            'transfer function) are all preserved.'];
        set(handles.fdesc,'String',desstr);
        try
            [Abar, Bbar, Cbar, Dbar, T] = mcf(G);
            set(handles.msgbox, 'String', '')
        catch err
            Abar = [];
            Bbar = [];
            Cbar = [];
            Dbar = [];
            T = [];
            set(handles.msgbox, 'String', err.message)
        end
        % Set values for tables A, B, C, D, T
        set(handles.Atable,'Data',Abar,'ColumnWidth', {170});
        set(handles.Btable,'Data',Bbar,'ColumnWidth', {170});
        set(handles.Ctable,'Data',Cbar,'ColumnWidth', {170});
        set(handles.Dtable,'Data',Dbar,'ColumnWidth', {170});
        set(handles.Ttable,'Data',T,'ColumnWidth', {170}); 


    case handles.bcpcf
        desstr = ['The Companion Canonical Form(CPCF) is a similarity ',...
            'transformation. In the companion realization, the ',...
            'characteristic polynomial of the system appears explicitly ',...
            'in the rightmost column of the A matrix. The companion ',...
            'transformation requires that the system be controllable from ',...
            'the first input. The companion form is poorly conditioned for ',...
            'most state-space computations; avoid using it when possible.',...
            'Note: Whenever a similarity transformation is performed, the properties ',...
            'of the the transformed system (e.g. the characteristic ',...
            'equation, eigenvectors, eigenvalues,and transfer function) are ',...
            'all preserved.'];
        set(handles.fdesc,'String',desstr);
        try
            [Abar, Bbar, Cbar, Dbar, T] = cpcf(G);
            set(handles.msgbox, 'String', '')
        catch err
            Abar = [];
            Bbar = [];
            Cbar = [];
            Dbar = [];
            T = [];
            set(handles.msgbox, 'String', err.message)
        end
        % Set values for tables A, B, C, D, T
        set(handles.Atable,'Data',Abar,'ColumnWidth', {170});
        set(handles.Btable,'Data',Bbar,'ColumnWidth', {170});
        set(handles.Ctable,'Data',Cbar,'ColumnWidth', {170});
        set(handles.Dtable,'Data',Dbar,'ColumnWidth', {170});
        set(handles.Ttable,'Data',T,'ColumnWidth', {170});

        
    case handles.bocf
        desstr = ['The Observable Canonical Form(OCF) is a similarity ',...
            'transformation used to give indication whether a system is ',...
            'state observable. For a system to be state observable, the ',...
            'transformed "A" matrix will have (1) ones on a diagonal next to ',...
            'the leading diagonal, (2) the negatives of the coefficients of ',...
            'the characteristic equation will form the furthest column on ',...
            'the opposite side of leading diagonal and (3)zeros everywhere else.',...
            'Note: Whenever a similarity transformation is performed, the properties ',...
            'of the the transformed system (e.g. the characteristic ',...
            'equation, eigenvectors, eigenvalues,and transfer function) are ',...
            'all preserved.'];
        set(handles.fdesc,'String',desstr);
        [Abar, Bbar, Cbar, Dbar, T, fb] = ocf(G);        
        % Set values for tables A, B, C, D, T
        set(handles.Atable,'Data',Abar,'ColumnWidth', {170});
        set(handles.Btable,'Data',Bbar,'ColumnWidth', {170});
        set(handles.Ctable,'Data',Cbar,'ColumnWidth', {170});
        set(handles.Dtable,'Data',Dbar,'ColumnWidth', {170});
        set(handles.Ttable,'Data',T,'ColumnWidth', {170}); 
        msg ='Multivar 1.0: This form is not available as the number of outputs is greater than 1.';
        if fb == 0
            set(handles.msgbox, 'String', msg)
        else
            set(handles.msgbox, 'String', '')
        end


    case handles.bccf
        desstr = ['The Controllable Canonical Form(CCF) is a similarity ',...
            'transformation used to give indication whether a system is ',...
            'state controllable. For a system to be state controllable, the ',...
            'transformed "A" matrix will be almost an identity matrix ',...
            '(ones of the leading diagonal) except that the bottom-most or the ',...
            'top-most row of transformed "A" matrix will contain the ',...
            'negative of the coefficients of the characteristic equation. ',...
            'Note: Whenever a similarity transformation is performed, the properties ',...
            'of the the transformed system (e.g. the characteristic ',...
            'equation, eigenvectors, eigenvalues,and transfer function) are ',...
            'all preserved.'];
        set(handles.fdesc,'String',desstr);
        [Abar, Bbar, Cbar, Dbar, T ,fb] = ccf(G);
        % Set values for tables A, B, C, D, T
        set(handles.Atable,'Data',Abar,'ColumnWidth', {170});
        set(handles.Btable,'Data',Bbar,'ColumnWidth', {170});
        set(handles.Ctable,'Data',Cbar,'ColumnWidth', {170});
        set(handles.Dtable,'Data',Dbar,'ColumnWidth', {170});
        set(handles.Ttable,'Data',T,'ColumnWidth', {170});
        msg ='Multivar 1.0: This form is not available as the number of inputs is greater than 1.';
        if fb == 0
            set(handles.msgbox, 'String', msg)
        else
            set(handles.msgbox, 'String', '')
        end
    
    case handles.bdcf
        desstr = ['The Diagonal Canonical Form(DCF) is a similarity ',...
            'transformation in which the transformed state equations ',...
            'are decoupled from each other and therefore can be solved ',...
            'individually. The transformed "A" matrix is a diagonal ',...
            'matrix whose n diagonal elements are the n distinct ',...
            'eigenvalues of the state matrix, A.'];
        set(handles.fdesc,'String',desstr);
        [Abar, Bbar, Cbar, Dbar, T] = dcf(G);
        % Set values for tables A, B, C, D, T
        set(handles.Atable,'Data',Abar,'ColumnWidth', {170});
        set(handles.Btable,'Data',Bbar,'ColumnWidth', {170});
        set(handles.Ctable,'Data',Cbar,'ColumnWidth', {170});
        set(handles.Dtable,'Data',Dbar,'ColumnWidth', {170});
        set(handles.Ttable,'Data',T,'ColumnWidth', {170});
        set(handles.msgbox, 'String', '')

    case handles.bjcf
        desstr = ['The Jordan Canonical Form(JCF) is a similarity ',...
            'transformation used when the state matrix A has ',...
            'multiple-order eigenvalues. If the matrix is not symmetric ',...
            'with real elements, it cannot be transformed into a diagonal ',...
            'matrix. In the JCF the transformed "A" matrix is block ',...
            'diagonal instead of diagonal. To perform the JCF ',...
            'transformation, the transformation matrix T is first formed ',...
            'using the eigenvectors and generalized eigenvectors as its ',...
            'columns and then the same calculations used to determine the ',...
            'DCF are performed'];
        set(handles.fdesc,'String',desstr);
        [Abar, Bbar, Cbar, Dbar, T] = jcf(G);
        % Set values for tables A, B, C, D, T
        set(handles.Atable,'Data',Abar,'ColumnWidth', {170});
        set(handles.Btable,'Data',Bbar,'ColumnWidth', {170});
        set(handles.Ctable,'Data',Cbar,'ColumnWidth', {170});
        set(handles.Dtable,'Data',Dbar,'ColumnWidth', {170});
        set(handles.Ttable,'Data',T,'ColumnWidth', {170});
        set(handles.msgbox, 'String', '')

    case handles.bkosf
        desstr = ['The Kalman Observability Staircase Form(KOSF) is a ',...
            'similarity transformation that utilises the state observability ',...
            'matrix to effect its transformation. This form displays ',...
            'block matrices Ao, Bo, Co (SEEN IN GREEN) in the transformed  ',...
            '"A", "B" and "C" matrices respectively where Ao, Bo, Co are ',...
            'the observable portions of the transformed matrices. It also displays ',...
            'block matrices Ano, Bno (SEEN IN RED) in the transformed ',...
            '"A" and "B" matrices respectively where Ano and Bno are ',...
            'the unobservable portions of the transformed matrices. The ',...
            'areas that provide information that is not relevant ',...
            'observability are shown in BLACK.'];
        set(handles.fdesc,'String',desstr);
        try
            [Abar, Bbar, Cbar, Dbar, T, k] = kosf(G);
            set(handles.msgbox, 'String', '')            
        % Set values for tables A, B, C, D, T
            nst = sum(k);
            [colourA, colourB, colourC] = kosfcolors(nst, Abar, Bbar, Cbar);
            tcellcolor(handles.Atable, Abar, colourA);
            tcellcolor(handles.Btable, Bbar, colourB);
            tcellcolor(handles.Ctable, Cbar, colourC);
        catch err
            Abar = [];
            Bbar = [];
            Cbar = [];
            Dbar = [];
            T = [];
            %k = [];
            set(handles.msgbox, 'String', err.message)
        % Set values for tables A, B, C, D, T
            set(handles.Atable,'Data',Abar,'ColumnWidth', {170});
            set(handles.Btable,'Data',Bbar,'ColumnWidth', {170});
            set(handles.Ctable,'Data',Cbar,'ColumnWidth', {170});
        end
        % Set values for tables Dbar, T
        set(handles.Dtable,'Data',Dbar,'ColumnWidth', {170});
        set(handles.Ttable,'Data',T,'ColumnWidth', {170}); 


    case handles.bkcsf
        desstr = ['The Kalman Controllability Staircase Form(KCSF) is a ',...
            'similarity transformation that utilises the state controllability ',...
            'matrix to effect its transformation. This form displays ',...
            'block matrices Ac, Bc, Cc (SEEN IN GREEN) in the transformed  ',...
            '"A", "B" and "C" matrices respectively where Ac, Bc, Cc are ',...
            'the controllable portions of the transformed matrices. The ',...
            'eigenvalues of Ac are controllable. It also displays ',...
            'block matrices Anc and Cnc (SEEN IN RED) in the transformed ',...
            '"A" and "C" matrices respectively where Anc and Cnc are ',...
            'the uncontrollable portions of the transformed matrices. The ',...
            'areas that provide information that is not relevant ',...
            'controllability are shown in BLACK.'];
        set(handles.fdesc,'String',desstr);
        try
            [Abar, Bbar, Cbar, Dbar, T, k] = kcsf(G);
            set(handles.msgbox, 'String', '')            
        % Set values for tables A, B, C, D, T
            nst = sum(k);
            [colourA, colourB, colourC] = kcsfcolors(nst, Abar, Bbar, Cbar);
            tcellcolor(handles.Atable, Abar, colourA);
            tcellcolor(handles.Btable, Bbar, colourB);
            tcellcolor(handles.Ctable, Cbar, colourC);
        catch err
            Abar = [];
            Bbar = [];
            Cbar = [];
            Dbar = [];
            T = [];
            %k = [];
            set(handles.msgbox, 'String', err.message)
        % Set values for tables A, B, C, D, T
            set(handles.Atable,'Data',Abar,'ColumnWidth', {170});
            set(handles.Btable,'Data',Bbar,'ColumnWidth', {170});
            set(handles.Ctable,'Data',Cbar,'ColumnWidth', {170});
        end
        % Set values for tables Dbar, T
        set(handles.Dtable,'Data',Dbar,'ColumnWidth', {170});
        set(handles.Ttable,'Data',T,'ColumnWidth', {170}); 


    otherwise
        %Code for when there is no match.
end

% Update handles structure
guidata(hObject, handles);


% --- Executes on button press in goback.
function goback_Callback(hObject, eventdata, handles)
% hObject    handle to goback (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get structure from gui/figure application data
mstruct = getappdata(handles.output,'gstruct');

% Update/modify structure
% Get rid of the handle of the current figure
mstruct.phandlerecord = mstruct.phandlerecord(1: length(mstruct.phandlerecord) - 1);

% Get position of the current GUI window 
mstruct.windowposition = get(gcf,'OuterPosition');

% Update root application data
setappdata(0, 'mlvappdata', mstruct);

% Get handle of previous page from figure appdata
% Activate previous gui window and delete the handle of the current window
set(getappdata(handles.output,'hprevpage'), 'OuterPosition',mstruct.windowposition,'Visible', 'On');
set(handles.output, 'Visible', 'Off');
delete(handles.output)


% --- Executes when user attempts to close figure1.
function figure1_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: delete(hObject) closes the figure

% display a question dialog box 
selection = questdlg('Are you sure you want to close Multivar?','Close Request Function','Yes','No','Yes'); 

switch selection, 
    case 'Yes'     
        % delete all figures related to multivar
          mstruct = getappdata(handles.output,'gstruct');  
          delete(mstruct.phandlerecord) 
          exit_multivar
    case 'No'
       % Do nothing
end



function msgbox_Callback(hObject, eventdata, handles)
% hObject    handle to msgbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of msgbox as text
%        str2double(get(hObject,'String')) returns contents of msgbox as a double


% --- Executes during object creation, after setting all properties.
function msgbox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to msgbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function fdesc_Callback(hObject, eventdata, handles)
% hObject    handle to fdesc (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of fdesc as text
%        str2double(get(hObject,'String')) returns contents of fdesc as a double


% --- Executes during object creation, after setting all properties.
function fdesc_CreateFcn(hObject, eventdata, handles)
% hObject    handle to fdesc (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
