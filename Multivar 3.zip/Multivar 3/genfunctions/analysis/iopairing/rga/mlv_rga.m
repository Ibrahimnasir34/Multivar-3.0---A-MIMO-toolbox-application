function [G,R,S,MCN] = mlv_rga(sys, w)
% MLV_RGA  returns the gain matrix, relative gain array and input output
% selection matrix for the system at a particular frequency. 
% 
% SYNTAX
% [R, S] = mlv_rga(SYS, w) returns the relative gain array R and 
% input-output selection matrix S for the system SYS at a particular
% frequency. The system may be zpk, tf or ss and may or may not contain 
% time delays. It may also be either square or non-square. 
% See also SVD_IOP.

% *************************************************************************
% Author:           Crystal Blackwell 
% Email:            Crystal.Blackwell@sta.uwi.edu
% Created:          January 2013; 
% Last revision:    29-June-2013;
% Useful websites:
%
% MATLAB VERSIONS USED IN PROGRAMMING PROCESS: 
% - MATLAB R2013a
%
% *************************************************************************
% NATIVE MATLAB FUNCTIONS USED TO CREATE THIS FUNCTION:
% nargin                    nargout                     error
% narginchk                 nargoutchk                  isscalar
% evalfr                    tf                          pinv                      
% norm                      round                       svd
% cond                      
% *************************************************************************
% MULTIVAR FUNCTIONS USED TO CREATE THIS FUNCTION:
% modtyptest
% *************************************************************************

    % Check for correct number of output arguments
    if nargout == 4
        % Check for correct number of input arguments
        if nargin == 2 

            % Check if w is a scalar and positive
            if isscalar(w) == 1 &&  w >= 0
                
                % Check the type of input system
                modnum = modtyptest(sys);
                if modnum == 1 || modnum == 2 || modnum == 3 || modnum == 4 || modnum == 5 || modnum == 6
                    
                    % if system is state space convert to tf
                    if  modnum == 3 || modnum == 4 
                        sys = tf(sys);
                    end

                    % Determine gain matrix at particular frequency
                    G = evalfr(sys, w);                   
                  
                    % Determine the RGA
                    R = G .* (pinv(G))'; 
                    
                    % Determine Approximate Minimised Condition number
                    MCN = sum(sum(abs(R)));

                    S = R; % initialising S 
                    
                    % Updating pairing selection matrix                    
                    while norm(round(S)-S)>1e-9
                        % Set all terms less than 0.5 to zero
                        S(S <= 0.5) = 0;

                        % Set all terms greater than 2 to zero
                        S(S >= 5) = 0;
                        S = S .* (pinv(S))'; 
                    end  
                    
                    S = round(S);

                else
                    error('Multivar 1.0: Inappropriate input system.')
                end
            else
                error('Multivar 1.0: Frequency w must be a scalar greater than zero.')
            end
        else
            % Display error if incorrect number of inputs
            narginchk(2, 2)
        end
    else
        % Display error if incorrect number of outputs
        nargoutchk(4, 4)
    end
end