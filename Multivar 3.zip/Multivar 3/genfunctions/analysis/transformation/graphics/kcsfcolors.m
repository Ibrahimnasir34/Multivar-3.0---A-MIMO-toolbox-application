function [colourA, colourB, colourC] = kcsfcolors(nst, Abar, Bbar, Cbar)
% KCSFCOLORS  generates three text colour cell string arrays corresponding to the
% KCSF-transformed A, B and C matrices. Useful for graphically displaying 
% the controllable states in a uitable.
% 
% SYNTAX
% [colourA, colourB, colourC] = kcsfcolors(nst, Abar, Bbar, Cbar)
% returns the text colour cell arrays of the transformed A, B and C matrices after
% performing the kcsf similarity transformation.
% See also TCELLCOLOR, KCSF

% *************************************************************************
% Author:           Crystal Blackwell 
% Email:            Crystal.Blackwell@sta.uwi.edu
% Created:          January 2013; 
% Last revision:    29-June-2013;
% Useful websites:
%
% MATLAB VERSIONS USED IN PROGRAMMING PROCESS: 
% - MATLAB R2013a
%
% *************************************************************************
% NATIVE MATLAB FUNCTIONS USED TO CREATE THIS FUNCTION:
% nargin                    nargout                     error
% narginchk                 nargoutchk                  ismatrix
% size                      cell                         
% *************************************************************************
% MULTIVAR FUNCTIONS USED TO CREATE THIS FUNCTION:
% isposwnum                    
% *************************************************************************
    

    % Check for correct number of output arguments
    if nargout == 3
        % Check for correct number of input arguments
        if nargin == 4 
            % Check that Abar, Bbar and Cbar are matrices
            if ismatrix(Abar)== 1 && ismatrix(Cbar)== 1 && ismatrix(Cbar)== 1
                
                % Check that the dimensions of Abar, Bbar and Cbar are correct
                Asize = size(Abar);
                Bsize = size(Bbar);
                Csize = size(Cbar);
                if Asize(1) == Asize(2) && Asize(1) == Bsize(1) && Asize(1) == Csize(2)

                    % Check that nst is an positive whole number
                    if isposwnum(nst) == 1
                        colourA = Acolors(nst, Asize);
                        colourB = CbBcolors(nst, Bsize);
                        colourC = CbCcolors(nst, Csize);
                    else
                        error('Multivar 1.0: nst must be a positive whole number.')
                    end
                else
                    error('Multivar 1.0: State space matrices are not matching dimensions.')
                end
            else
                error('Multivar 1.0: Abar, Bbar and Cbar must be valid state space matrices.')
            end
        else
            % Display error if incorrect number of inputs
            narginchk(4, 4)
        end
    else
        % Display error if incorrect number of outputs
        nargoutchk(3, 3)
    end            
end

function colarray = Acolors(nstates, Msize)
    % preallocating empty cell array of dimension Msize
    colarray = cell(Msize);      
    
    % Determining the boundaries
    m = Msize(1);
    n = Msize(2);    
    vbder = m - nstates;
    hbder = n - nstates;
    
    % Setting values of each entry in the cell array
    colarray(1:vbder, 1:hbder) = {'red'};
    colarray(1:vbder, hbder + 1 : n) = {'black'};
    colarray(vbder + 1 : m, 1:hbder) = {'black'};
    colarray(vbder + 1 : m, hbder + 1 : n) = {'green'};
end

function colarray = CbBcolors(nstates, Msize)
    % preallocating empty cell array of dimension Msize
    colarray = cell(Msize);
    
    % Determining the boundary
    m = Msize(1);
    n = Msize(2);
    bder = m - nstates;
    
    % Setting values of each entry in the cell array
    colarray(1:bder,:) = {'black'};
    colarray(bder + 1 : m, :) = {'green'};
end

function colarray = CbCcolors(nstates, Msize)
    % preallocating empty cell array of dimension Msize
    colarray = cell(Msize);
    
    % Determining the boundary
    m = Msize(1);
    n = Msize(2);
    bder = n - nstates;
    
    % Setting values of each entry in the cell array
    colarray(:, 1:bder) = {'red'};
    colarray(:, bder + 1 : n) = {'green'};
end