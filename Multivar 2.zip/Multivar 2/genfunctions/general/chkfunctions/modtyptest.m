function modnum = modtyptest(sys)
% MODTYPTEST  Returns the Multivar specified classification of the system. 
% There are six different classifications. They are useful in determining 
% which analysis and design techniques can be applied to the system.
% 
% SYNTAX
% (a)    modtyptest(SYS) returns a number according to the Multivar
% specified classification of the system. 
% 
% (b)    MODNUM = modtyptest(SYS) returns a number MODNUM according to the Multivar
% specified classification of the system. 
% 
% The various Multivar classifications are as follows:
% 0 - for systems that cannot be inputted to Multivar.   
% 1 - for tf systems with time delays
% 2 - for tf systems without time delays
% 3 - for ss systems with time delays
% 4 - for ss systems without time delays
% 5 - for zpk systems with time delays
% 6 - for zpk systems without time delays
% 
% See also CLASS, HASDELAY.

% *************************************************************************
% Author:           Crystal Blackwell 
% Email:            Crystal.Blackwell@sta.uwi.edu
% Created:          January 2013; 
% Last revision:    29-June-2013;
% Useful websites:
%
% MATLAB VERSIONS USED IN PROGRAMMING PROCESS: 
% - MATLAB R2013a
%
% *************************************************************************
% NATIVE MATLAB FUNCTIONS USED TO CREATE THIS FUNCTION:
% nargin                    nargout                     class             
% hasdelay                  narginchk                   nargoutchk
% *************************************************************************


    % Check for correct number of output arguments
    if nargout <= 1
        % Check for correct number of input arguments
        if nargin == 1
            
            % determine the class of the system model    
            modclass = class(sys);
            switch modclass
                case 'tf'
                    if hasdelay(sys) == 1
                         % transfer function representation with delays
                         modnum = 1;
                    else
                         % transfer function representation without delays
                         modnum = 2;
                    end        
                case 'ss'
                    if hasdelay(sys) == 1
                         % state space representation with delays                
                         modnum = 3;
                    else
                         % state space representation without delays                
                         modnum = 4;
                    end
                case 'zpk'
                    if hasdelay(sys) == 1
                         % zero pole gain representation with delays                
                         modnum = 5;
                    else
                         modnum = 6;
                         % zero pole gain representation without delays                 
                    end        
                otherwise
                         % any other data entry            
                    modnum = 0;
            end
            
        else
            % Display error if incorrect number of inputs
            narginchk(1, 1)
        end
    else
        % Display error if incorrect number of outputs
        nargoutchk(0, 1)
    end
end