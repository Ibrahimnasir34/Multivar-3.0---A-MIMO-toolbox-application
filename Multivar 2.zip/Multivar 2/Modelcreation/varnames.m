function varargout = varnames(varargin)
% VARNAMES M-file for varnames.fig
%      VARNAMES, by itself, creates a new VARNAMES or raises the existing
%      singleton*.
%
%      H = VARNAMES returns the handle to a new VARNAMES or the handle to
%      the existing singleton*.
%
%      VARNAMES('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in VARNAMES.M with the given input arguments.
%
%      VARNAMES('Property','Value',...) creates a new VARNAMES or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before varnames_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to varnames_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help varnames

% Last Modified by GUIDE v2.5 11-May-2014 18:57:50

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @varnames_OpeningFcn, ...
                   'gui_OutputFcn',  @varnames_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before varnames is made visible.
function varnames_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to varnames (see VARARGIN)

% Choose default command line output for varnames
handles.output = hObject;

% Get root application data
mstruct = getappdata(0, 'mlvappdata');

% Set position and size and title
set(handles.output, 'OuterPosition',mstruct.windowposition, 'Name', mstruct.gtitle);

% Set handle of previous page as gui/figure application data
setappdata(handles.output,'hprevpage',mstruct.phandlerecord(length(mstruct.phandlerecord)));

% Update the page handle record in the structure and then save structure as root application data
mstruct.phandlerecord = [mstruct.phandlerecord, handles.output];
% assign default names
mstruct.systemmodel = iosnames(mstruct.systemmodel);
setappdata(0, 'mlvappdata', mstruct)

% set struct from root application data as gui/figure application data
setappdata(handles.output, 'gstruct', mstruct);

% Get input and output names
sys = mstruct.systemmodel; 
Inames = get(sys, 'InputName');
Onames = get(sys, 'OutputName');

% if State space
% Get handles of all the objects inside of pannew
statobj = get(handles.statpan, 'Children');
if isa(sys, 'ss')
    % enable objects in state panel     
    set(statobj, 'Enable', 'on')
    % Get state names
    Snames = get(sys, 'StateName');
else
    % disable objects in state panel     
    set(statobj, 'Enable', 'off')
end

%Set properties for tables
set(handles.outnames,'Data', Onames, 'BackgroundColor',[0.5 1 0.5],'ColumnWidth',{240},'ColumnEditable', true);
set(handles.innames,'Data', Inames, 'BackgroundColor',[1 0.6 0.6],'ColumnWidth',{240},'ColumnEditable', true);
set(handles.statnames,'Data', {}, 'BackgroundColor',[0.6 0.6 1],'ColumnWidth',{240},'ColumnEditable', true);
if isa(sys, 'ss')
    set(handles.statnames,'Data', Snames, 'BackgroundColor',[0.6 0.6 1],'ColumnWidth',{240},'ColumnEditable', true);
end

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes varnames wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = varnames_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in next_butt.
function next_butt_Callback(hObject, eventdata, handles)
% hObject    handle to next_butt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get struct from gui/figure application data.
mstruct = getappdata(handles.output, 'gstruct');

% Create vector containing the names of all variables
Onamedata = get(handles.outnames,'Data');
Inamedata = get(handles.innames,'Data');

% Check that all the entries in Output table are filled
if any(cellfun('isempty', Onamedata))
    Ofill_chk = 0;
else
    Ofill_chk = 1;
end
% Check that all the entries in Output table are strings
if iscellstr(Onamedata) == 1
    Ostr_chk = 1;
else
    Ostr_chk = 0;
end

% Check that all the entries in Input table are filled
if any(cellfun('isempty', Inamedata))
    Ifill_chk = 0;
else
    Ifill_chk = 1;
end
% Check that all the entries in Input table are strings
if iscellstr(Inamedata) == 1 
    Istr_chk = 1;
else
    Istr_chk = 0;
end

if isa(mstruct.systemmodel, 'ss') %for state space only
    Snamedata = get(handles.statnames,'Data');
    putdata = vertcat(Onamedata, Inamedata, Snamedata);
    
    % Check that all the entries in State table are filled
    if any(cellfun('isempty', Snamedata))
        Sfill_chk = 0;
    else
        Sfill_chk = 1;
    end
    % Check that all the entries in State table are strings
    if iscellstr(Snamedata) == 1 
        Sstr_chk = 1;
    else
        Sstr_chk = 0;
    end

else % for others
    putdata = vertcat(Onamedata, Inamedata);
end

% Check that all the variables have unique names
if size(putdata) == size(unique(putdata))
    Uname_chk = 1;
else
    Uname_chk = 0;
end

% Create flag vector
if isa(mstruct.systemmodel, 'ss') %for state space only
    flag_chk = [Ofill_chk, Ifill_chk, Sfill_chk, Ostr_chk, Istr_chk, Sstr_chk, Uname_chk];
else %for others
    flag_chk = [Ofill_chk, Ifill_chk, Ostr_chk, Istr_chk, Uname_chk];
end


if flag_chk == ones(size(flag_chk))
    % Save variable names to model
    sys = mstruct.systemmodel;
    sys.InputName = Inamedata;
    sys.OutputName = Onamedata;
    if isa(mstruct.systemmodel, 'ss')
        sys.StateName = Snamedata;      
    end
    mstruct.systemmodel = sys;

    % Get position of the current GUI window and update
    % structure
    mstruct.windowposition = get(gcf,'OuterPosition');

    % Update root application data
    setappdata(0, 'mlvappdata', mstruct);

    % Activate new GUI window and close the last window
    set(savesysmodel, 'Visible', 'On');
    set(handles.output, 'Visible', 'Off');
else
    % Display message in message box
    if isa(mstruct.systemmodel, 'ss') % for state space
        emessage = 'Multivar: ';
        emessage1 = 'Please complete the list of output variable names. ';
        emessage2 = 'Please complete the list of input variable names. ';
        emessage3 = 'Please complete the list of state variable names. '
        emessage4 = 'All output variables must be strings. ';
        emessage5 = 'All input variables must be strings. ';
        emessage6 = 'All state variables must be strings. ';
        emessage7 = 'All variable names must be unique. ';
    else % for others
        emessage = 'Multivar: ';
        emessage1 = 'Please complete the list of output variable names. ';
        emessage2 = 'Please complete the list of input variable names. ';
        emessage3 = 'All output variables must be strings. ';
        emessage4 = 'All input variables must be strings. ';
        emessage5 = 'All variable names must be unique. ';
    end
    
    for a = 1 : 1: length(flag_chk)
        if flag_chk(a) == 0
            emessage = [emessage, eval(['emessage', num2str(a)])];
        end
    end  
    set(handles.msgbox,'String',emessage, 'ForegroundColor', [1 0 0]) 
end

% Update handles structure
guidata(hObject, handles);    


% --- Executes on button press in goback.
function goback_Callback(hObject, eventdata, handles)
% hObject    handle to goback (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get structure from gui/figure application data
mstruct = getappdata(handles.output,'gstruct');

% Update/modify structure
% Get rid of the handle of the current figure
mstruct.phandlerecord = mstruct.phandlerecord(1: length(mstruct.phandlerecord) - 1);

% Get position of the current GUI window 
mstruct.windowposition = get(gcf,'OuterPosition');

% Update root application data
setappdata(0, 'mlvappdata', mstruct);

% Get handle of previous page from figure appdata
% Activate previous gui window and delete the handle of the current window
set(getappdata(handles.output,'hprevpage'), 'OuterPosition',mstruct.windowposition,'Visible', 'On');
set(handles.output, 'Visible', 'Off');
delete(handles.output)


% --- Executes when user attempts to close figure1.
function figure1_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: delete(hObject) closes the figure

% display a question dialog box 
selection = questdlg('Are you sure you want to close Multivar?','Close Request Function','Yes','No','Yes'); 

switch selection, 
    case 'Yes'     
        % delete all figures related to multivar
          mstruct = getappdata(handles.output,'gstruct');  
          delete(mstruct.phandlerecord) 
          exit_multivar
    case 'No'
       % Do nothing
end



function msgbox_Callback(hObject, eventdata, handles)
% hObject    handle to msgbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of msgbox as text
%        str2double(get(hObject,'String')) returns contents of msgbox as a double


% --- Executes during object creation, after setting all properties.
function msgbox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to msgbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
