function varargout = sfbdec2(varargin)
% SFBDEC2 M-file for sfbdec2.fig
%      SFBDEC2, by itself, creates a new SFBDEC2 or raises the existing
%      singleton*.
%
%      H = SFBDEC2 returns the handle to a new SFBDEC2 or the handle to
%      the existing singleton*.
%
%      SFBDEC2('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in SFBDEC2.M with the given input arguments.
%
%      SFBDEC2('Property','Value',...) creates a new SFBDEC2 or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before sfbdec2_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to sfbdec2_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help sfbdec2

% Last Modified by GUIDE v2.5 15-Dec-2013 17:50:28

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @sfbdec2_OpeningFcn, ...
                   'gui_OutputFcn',  @sfbdec2_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before sfbdec2 is made visible.
function sfbdec2_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to sfbdec2 (see VARARGIN)

% Choose default command line output for sfbdec2
handles.output = hObject;

% Get root application data
mstruct = getappdata(0, 'mlvappdata');

% Set position and size and title
set(handles.output, 'OuterPosition',mstruct.windowposition, 'Name', mstruct.gtitle);

% Set handle of previous page as gui/figure application data
setappdata(handles.output,'hprevpage',mstruct.phandlerecord(length(mstruct.phandlerecord)));

% Update the page handle record in the structure and then save structure as root application data
mstruct.phandlerecord = [mstruct.phandlerecord, handles.output];
setappdata(0, 'mlvappdata', mstruct)

% set struct from root application data as gui/figure application data
setappdata(handles.output, 'gstruct', mstruct);

% Setting defaults
% clear message box
set(handles.msgbox, 'String', '')   

% Display image
imshow('pestimator.jpg')

% Setting defaults
SSsys = mstruct.decopinfo{3};
dsys = mstruct.decopinfo{4};
setappdata(handles.output, 'sysforestim', SSsys)
   
%Display number of inputs and outputs for original model
[m, p] = size(SSsys);
sm = num2str(m);
sp = num2str(p);
set(handles.noout,'String',sm);
set(handles.noin,'String',sp);

% No of loops controlled
if m == p
    set(handles.nocl,'String',sm);
end

% Display decoupled system
sys_text = evalc('dsys');
tlines = strsplit(sys_text,'\n');
set(handles.moddisplay,'FontName', 'Monospaced', 'String',tlines);

% determine controllability and observability of decoupled system
A = SSsys.a;
B = SSsys.b;
C = SSsys.c;

% Number of states
nostat = length(A);
set(handles.nstate, 'String', nostat)

% Determine  controllability matrix
Co = ctrb(A,B);  

% Number of controllable states
nco = rank(Co);
set(handles.ncostates, 'String', nco)

% Number of uncontrollable states
nunco = nostat - nco;
set(handles.nuncostates, 'String', nunco)   

% Determine  observability matrix   
Ob = obsv(A,C);    

% Number of observable states
nob = rank(Ob);
set(handles.nobstates, 'String', nob)

% Number of unobservable states
nunob = nostat - nob;
set(handles.nunobstates, 'String', nunob)      

% Determine estimator poles in poles table (Columns are 1)system poles, 2)multipliers,
% 3)estimator poles)

syspoles = pole(dsys);
mult = ones(size(syspoles));
epoles = syspoles .* mult;
setappdata(handles.output, 'polesys', syspoles)

% Find maximum pole
mspole = max(abs(syspoles));
npoles = length(syspoles);
for w = 1 : 1: npoles
    while abs(epoles(w)) <= mspole
        mult(w) =  mult(w) + 1;
        epoles(w) = syspoles(w) * mult(w);
    end
end

epoles = syspoles;

matrixsep = zeros(npoles, 3);
matrixsep(:,1) = syspoles;
matrixsep(:,2) = mult;
matrixsep(:,3) = epoles;

set(handles.s_epoles,'Data',matrixsep, 'BackgroundColor',[1 1 0.5]  ,'ColumnWidth',{160},'ColumnEditable', [false, true, false]);

try
    % Determine and display estimator gain
    L = place(A',C',epoles).';
    set(handles.lmatrix,'Data',L, 'BackgroundColor',[0.5 1 1]  ,'ColumnEditable', false);  

    % Create and display estimator
    est = estim(SSsys,L, 1:m, 1:p); 
    estim_text = evalc('est');
    elines = strsplit(estim_text,'\n');
    set(handles.estimdisp,'FontName', 'Monospaced', 'String',elines);
    
    set(handles.msgbox, 'String','') 
    set(handles.nextbutt, 'Enable', 'on') 
catch err
   set(handles.msgbox, 'String',['MULTIVAR: Attempt editing the multipliers in the System and Observer poles table.', char(10), err.message]) 
   set(handles.nextbutt, 'Enable', 'off') 
end
% Update handles structure
guidata(hObject, handles);

% UIWAIT makes sfbdec2 wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = sfbdec2_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes when user attempts to close figure1.
function figure1_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: delete(hObject) closes the figure

% display a question dialog box 
selection = questdlg('Are you sure you want to close Multivar?','Close Request Function','Yes','No','Yes'); 

switch selection, 
    case 'Yes'     
        % delete all figures related to multivar
          mstruct = getappdata(handles.output,'gstruct');  
          delete(mstruct.phandlerecord) 
          exit_multivar
    case 'No'
       % Do nothing
end


% --- Executes on button press in goback.
function goback_Callback(hObject, eventdata, handles)
% hObject    handle to goback (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get position struct from gui/figure application data.
mstruct = getappdata(handles.output, 'gstruct');

% Update/modify structure
% Get rid of the handle of the current figure
mstruct.phandlerecord = mstruct.phandlerecord(1: length(mstruct.phandlerecord) - 1);

% Get position of the current GUI window 
mstruct.windowposition = get(gcf,'OuterPosition');

% Update root application data
setappdata(0, 'mlvappdata', mstruct);

% Get handle of previous page from figure appdata
% Activate previous gui window and delete the handle of the current window
set(getappdata(handles.output,'hprevpage'), 'OuterPosition',mstruct.windowposition,'Visible', 'On');
set(handles.output, 'Visible', 'Off');
delete(handles.output)


% --- Executes on button press in nextbutt.
function nextbutt_Callback(hObject, eventdata, handles)
% hObject    handle to nextbutt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% get figure application data
mstruct = getappdata(handles.output, 'gstruct');
SSsys = getappdata(handles.output, 'sysforestim');
syspoles = getappdata(handles.output, 'polesys');

% Calculate L matrix
matrixsep = get(handles.s_epoles, 'Data');
estpoles = syspoles .* matrixsep(:,2);
A = SSsys.a;
C = SSsys.c;
L = place(A',C',estpoles).';

% Create estimator
[m, p] = size(SSsys.d);
est = estim(SSsys,L, 1:m, 1:p); 

% Evaluate decoupled system
F = mstruct.decopinfo{1};
G = mstruct.decopinfo{2};
I = eye(p);
n = length(A);
est3 = est((m + 1) : (m + n), (1 : p));
est4 = est((m + 1) : (m + n) , (p + 1): (p + m));
fbp = F * (est3 + (est4 * SSsys));
sfbs = feedback(I,fbp, +1);
dsys = SSsys * sfbs * G;
dsys = assin_name(SSsys, dsys, 'd');

% Update decoupling info
mstruct.decopinfo{4} = dsys;
mstruct.decopinfo{5} = est;

% Update Control model
mstruct.controlmodel = dsys;

% Update window position in structure
mstruct.windowposition = get(gcf,'OuterPosition');

% Update root application data
setappdata(0, 'mlvappdata', mstruct);

% Activate new GUI window and close the last window
set(sfbdec3, 'Visible', 'On');
set(handles.output, 'Visible', 'Off');

% Update handles structure
guidata(hObject, handles);



function moddisplay_Callback(hObject, eventdata, handles)
% hObject    handle to moddisplay (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of moddisplay as text
%        str2double(get(hObject,'String')) returns contents of moddisplay as a double


% --- Executes during object creation, after setting all properties.
function moddisplay_CreateFcn(hObject, eventdata, handles)
% hObject    handle to moddisplay (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function msgbox_Callback(hObject, eventdata, handles)
% hObject    handle to msgbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of msgbox as text
%        str2double(get(hObject,'String')) returns contents of msgbox as a double


% --- Executes during object creation, after setting all properties.
function msgbox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to msgbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes when entered data in editable cell(s) in s_epoles.
function s_epoles_CellEditCallback(hObject, eventdata, handles)
% hObject    handle to s_epoles (see GCBO)
% eventdata  structure with the following fields (see UITABLE)
%	Indices: row and column indices of the cell(s) edited
%	PreviousData: previous data for the cell(s) edited
%	EditData: string(s) entered by the user
%	NewData: EditData or its converted form set on the Data property. Empty if Data was not changed
%	Error: error string when failed to convert EditData to appropriate value for Data
% handles    structure with handles and user data (see GUIDATA)

% Get model for decoupling from gui/figure application data
SSsys = getappdata(handles.output, 'sysforestim');
syspoles = getappdata(handles.output, 'polesys');

% Get index of edited cell
cedit = eventdata.Indices;

% Get data from table
matrixsep = get(handles.s_epoles, 'Data');
matrixsep(cedit(1), cedit(2)  + 1) = syspoles(cedit(1)) * matrixsep(cedit(1), cedit(2)); 
estpoles = syspoles .* matrixsep(:,2);
set(handles.s_epoles, 'Data', matrixsep);
A = SSsys.a;
C = SSsys.c;
D = SSsys.d;

try
    % Update L matrix
    L = place(A',C',estpoles).';
    set(handles.lmatrix,'Data',L, 'BackgroundColor',[0.5 1 1]  ,'ColumnEditable', false);

    % Create and display estimator
    [m, p] = size(D);
    est = estim(SSsys,L, 1:m, 1:p);  
    estim_text = evalc('est');
    elines = strsplit(estim_text,'\n');
    set(handles.estimdisp,'FontName', 'Monospaced', 'String',elines);

    set(handles.msgbox, 'String','') 
    set(handles.nextbutt, 'Enable', 'on') 
catch err
   set(handles.msgbox, 'String',['MULTIVAR: Attempt editing the multipliers in the System and Observer poles table.', char(10), err.message]) 
   set(handles.nextbutt, 'Enable', 'off') 
end

function estimdisp_Callback(hObject, eventdata, handles)
% hObject    handle to estimdisp (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of estimdisp as text
%        str2double(get(hObject,'String')) returns contents of estimdisp as a double


% --- Executes during object creation, after setting all properties.
function estimdisp_CreateFcn(hObject, eventdata, handles)
% hObject    handle to estimdisp (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
