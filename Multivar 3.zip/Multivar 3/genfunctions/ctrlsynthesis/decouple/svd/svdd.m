function [U, S, V, K, precomp, postcomp] = svdd(sys, scalval, w)
% SVDD  Uses svd to diagonally decouple both square and non-square MIMO 
% systems. This function can be applied to LTI systems and also to transfer
% function systems with time delays.
%
% SYNTAX
% [dsys, CN] = svdd(sys)
%
% FUNCTION INPUT ARGUMENTS
% sys  - transfer function matrix, state space, or zero pole gain 
% representation of MIMO system
% scalval - vector containiing the proposed loop gains for scaled response.
% To make postcomp = U', set scalval = diag(S)
% w - decoupling frequency
%
% FUNCTION OUTPUT ARGUMENTS
% U - orthogonal matrix from SVD decomposition
% S - Singular value matrix from SVD decomposition
% V - orthogonal matrix from SVD decomposition
% Sc - Diagonal matrix containing the loop gain values in scalval
% precomp - precompensator. This value is equal to V.
% postcomp - post compensator. This value is equal to K * inverse of S
% * the inverse of U.

% *************************************************************************
% Author:           Crystal Blackwell 
% Email:            Crystal.Blackwell@sta.uwi.edu
% Created:          January 2013; 
% Last revision:    29-June-2013;
% Useful websites:
%
% MATLAB VERSIONS USED IN PROGRAMMING PROCESS: 
% - MATLAB R2013a
%
% *************************************************************************
% NATIVE MATLAB FUNCTIONS USED TO CREATE THIS FUNCTION:
% dcgain            svd                 size                minreal 
% inv               error                         
% *************************************************************************


    % if sys is in state space form or transfer function form  execute...
    if isa(sys, 'ss') == 1 || isa(sys, 'tf') == 1 || isa(sys, 'zpk') ==1        
     
        % determine gain matrix
        s = 1i*w;
        Gm = evalfr(sys, s);
                
        % run SVD if gain matrix only has finite values
        testGss = isfinite(Gm);
        if testGss == ones(size(Gm))
            % find svd and condition number
            [U, S, V] = svd(Gm, 'econ');         
          
            % determine precompensator
            precomp = V;     
                                 
            % determine scaling matrix
            [m, n]= size(sys);
            if m < n
                scalval = scalval(1:m);              
            else
                scalval = scalval(1:n);
            end
            K = diag(scalval);

            % determine postcompensator
              postcomp = K / S * U';  
        else
            error('Multivar 1.0: Steady state matrix has non-finite values')
        end
    else
        error('Multivar 1.0: System must be in either state space, transfer function or zero pole gain form')
    end
end
