function [Abar, Bbar, Cbar, Dbar, T] = cpcf(sys)
% CPCF  generate the Companion Canonical Form(CPCF)of a supplied 
% MIMO system.
% 
% SYNTAX
% [Abar, Bbar, Cbar, Dbar, T] = cpcf(sys) returns the Companion
% Canonical Form(CPCF) of the MIMO system SYS and its matrices Abar, Bbar, 
% Cbar, Dbar and the Transformation matrix T.

% *************************************************************************
% Author:           Crystal Blackwell 
% Email:            Crystal.Blackwell@sta.uwi.edu
% Created:          January 2013; 
% Last revision:    29-June-2013;
% Useful websites:
%
% MATLAB VERSIONS USED IN PROGRAMMING PROCESS: 
% - MATLAB R2013a
%
% *************************************************************************
% NATIVE MATLAB FUNCTIONS USED TO CREATE THIS FUNCTION:
% canon                  
% *************************************************************************

    % Check if input argument is a state-space system
    if strcmp(class(sys), 'ss') == 1
        [csys, T] = canon(sys,'companion');
        Abar = csys.a;
        Bbar = csys.b;
        Cbar = csys.c;
        Dbar = csys.d;
    else
        % error('Multivar 1.0: System must be in state space form.')
        Abar = [];
        Bbar = [];
        Cbar = [];
        Dbar = [];
        T = [];      
    end
end






