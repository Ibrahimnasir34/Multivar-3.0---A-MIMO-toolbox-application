function [Ti, Si, To, So] = csvdcsfdis(Do, C, Di, G)
    Fp = Di * C; 
    Gp = Do * G;
    Ti = Fp*Gp / (eye(size(Fp*Gp)) + Fp*Gp);
    Si = inv(eye(size(Fp*Gp)) + Fp*Gp);
    To = Gp*Fp / (eye(size(Gp*Fp)) + Gp*Fp);               
    So = inv(eye(size(Gp*Fp)) + Gp*Fp);
end