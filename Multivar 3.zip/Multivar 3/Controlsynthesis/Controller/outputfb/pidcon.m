function varargout = pidcon(varargin)
% PIDCON MATLAB code for pidcon.fig
%      PIDCON, by itself, creates a new PIDCON or raises the existing
%      singleton*.
%
%      H = PIDCON returns the handle to a new PIDCON or the handle to
%      the existing singleton*.
%
%      PIDCON('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in PIDCON.M with the given input arguments.
%
%      PIDCON('Property','Value',...) creates a new PIDCON or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before pidcon_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to pidcon_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help pidcon

% Last Modified by GUIDE v2.5 23-Nov-2017 16:09:10

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @pidcon_OpeningFcn, ...
                   'gui_OutputFcn',  @pidcon_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before pidcon is made visible.
function pidcon_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to pidcon (see VARARGIN)

% Choose default command line output for pidcon
handles.output = hObject;

% Get root application data
mstruct = getappdata(0, 'mlvappdata');

% Set position and size and title
set(handles.output, 'OuterPosition',mstruct.windowposition, 'Name', mstruct.gtitle);

% Set handle of previous page as gui/figure application data
setappdata(handles.output,'hprevpage',mstruct.phandlerecord(length(mstruct.phandlerecord)));

% Update the page handle record in the structure and then save structure as root application data
mstruct.phandlerecord = [mstruct.phandlerecord, handles.output];
setappdata(0, 'mlvappdata', mstruct)

% set struct from root application data as gui/figure application data
setappdata(handles.output, 'gstruct', mstruct);

% set defaults
% clear message box
set(handles.msgbox, 'String', '')

% set options of loop popups
tpairing = mstruct.iopairing;
[nloops, col] = size(tpairing);
loop_list = arrayfun(@num2str, (1:1:nloops)','UniformOutput', 0);
set(handles.looppop,'String',loop_list)
setappdata(handles.output, 'poploop', loop_list);

% Set options of input and output popups according to pairing
sys = mstruct.controlmodel;
in_list = sys.InputName;
out_list = sys.OutputName;
set(handles.inpop,'String',in_list)
set(handles.outpop,'String',out_list)
setappdata(handles.output, 'popin', in_list);
setappdata(handles.output, 'popout', out_list);

% set value of loop, input and output popups
loopnum = 1;
set(handles.looppop,'Value', loopnum)
set(handles.inpop,'Value', loopnum)
set(handles.outpop,'Value', loopnum)

% set options of controller type popup
type_list{1} = 'P';
type_list{2} = 'I';
type_list{3} = 'PI';
type_list{4} = 'PD';
type_list{5} = 'PDF';
type_list{6} = 'PID';
type_list{7} = 'PIDF';
set(handles.typepop,'String',type_list)
setappdata(handles.output, 'poptype', type_list);
% set value of controller type popup
set(handles.typepop,'Value', 1)

% set options of controller form popup
form_list{1} = 'Parallel';
form_list{2} = 'Standard';
set(handles.formpop,'String',form_list)
setappdata(handles.output, 'popform', form_list);
% set value of controller form popup
set(handles.formpop,'Value', 1)

% set options of display setting popup
disp_list{1} = 'Step';
disp_list{2} = 'Bode';
disp_list{3} = 'Nyquist';
disp_list{4} = 'Nichols';
disp_list{5} = 'Root locus'; 
set(handles.disppop, 'String', disp_list)
setappdata(handles.output, 'popdisp', disp_list);
% set value of controller type popup
set(handles.disppop,'Value', 1)


% set type matrix default, values range from 1 to 7 based on controller type
tmatrix = ones(nloops, 1);
% set form matrix default, values range from 1 to 2 based on controller form
fmatrix = ones(nloops, 1);
% set pid controller matrix default
looppid = cell(nloops, 1);

% generate default tuned parallel P controllers
for loopnum = 1: 1: nloops   

    ctype = 'P';
    % Find P in list and find the corresponding number
    tindx = find(ismember(type_list,ctype));
    % Set value in column vector tmatrix
    tmatrix(loopnum) = tindx;
    
    cform = 'Parallel';
    % Find Parallel in list and find the corresponding number
    findx = find(ismember(form_list,cform));
    % Set value in column vector fmatrix
    fmatrix(loopnum) = findx;   

    iosys  = sys(loopnum, loopnum);
    if hasInternalDelay(iosys) == 1
        % Determine number of unstable poles
        rpole = real(pole(iosys));        
        nup = sum(rpole>0);
        opt = pidtuneOptions('NumUnstablePoles',nup);
        % Tune controller
        C = pidtune(iosys,ctype, opt);
    else
        % Tune controller
        C = pidtune(iosys,ctype);  
    end
    looppid{loopnum} = C;
end

% Save controller and type matrices as figure/gui application data
setappdata(handles.output, 'PIDct', looppid)
setappdata(handles.output, 'tmat', tmatrix)
setappdata(handles.output, 'fmat', fmatrix)

% For first loop
vloop = 1;
% If first loop turn off "PREVIOUS" button
if vloop == 1
    set(handles.loopprevbutt, 'Enable', 'off')
else
    set(handles.loopprevbutt, 'Enable', 'on')
end

% If last loop turn off "NEXT" button
if vloop == nloops
    set(handles.loopnextbutt, 'Enable', 'off')
else
    set(handles.loopnextbutt, 'Enable', 'on')
end

% Get controller and parameters
C = looppid{vloop};
switch findx
    case 1
        [Kp,Ki,Kd,Tf] = piddata(C);
    case 2
        [Kp,Ti,Td,N] = pidstddata(C);
end

% set Value text
set(handles.pval, 'String', num2str(Kp))
set(handles.ival, 'String', num2str(Ki))
set(handles.dval, 'String', num2str(Kd))
set(handles.fnval, 'String', num2str(Tf))

% Display step response of control loop with parallel controller
iosys  = sys(vloop, vloop);
fpsys = iosys * C; % forward path
fbsys = 1; % unity feedback path
csys = feedback(fpsys,fbsys);
csys = assin_name(iosys, csys, 'c');

subplot(1,1,1); step(csys);
title('Step Response of Control Loop');

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes pidcon wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = pidcon_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in go_back.
function go_back_Callback(hObject, eventdata, handles)
% hObject    handle to go_back (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get structure from gui/figure application data
mstruct = getappdata(handles.output,'gstruct');

% Update/modify structure
% Get rid of the handle of the current figure
mstruct.phandlerecord = mstruct.phandlerecord(1: length(mstruct.phandlerecord) - 1);

% Get position of the current GUI window 
mstruct.windowposition = get(gcf,'OuterPosition');

% Update root application data
setappdata(0, 'mlvappdata', mstruct);

% Get handle of previous page from figure appdata
% Activate previous gui window and delete the handle of the current window
set(getappdata(handles.output,'hprevpage'), 'OuterPosition',mstruct.windowposition,'Visible', 'On');
set(handles.output, 'Visible', 'Off');
delete(handles.output)


% --- Executes when user attempts to close figure1.
function figure1_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: delete(hObject) closes the figure

% display a question dialog box 
selection = questdlg('Are you sure you want to close Multivar?','Close Request Function','Yes','No','Yes'); 

switch selection, 
    case 'Yes'     
        % delete all figures related to multivar
          mstruct = getappdata(handles.output,'gstruct');  
          delete(mstruct.phandlerecord) 
          exit_multivar
    case 'No'
       % Do nothing
end


% --- Executes on button press in nextbutt.
function nextbutt_Callback(hObject, eventdata, handles)
% hObject    handle to nextbutt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get values from figure/ gui application data
mstruct = getappdata(handles.output, 'gstruct');
type_list = getappdata(handles.output, 'poptype');

% get form and type matrix
fmatrix = getappdata(handles.output, 'fmat');
tmatrix = getappdata(handles.output, 'tmat');

% Get figure application data
looppid = getappdata(handles.output, 'PIDct');

% Get values of controller parameters
getpval = str2double(get(handles.pval, 'String')); 
getival = str2double(get(handles.ival, 'String'));
getdval = str2double(get(handles.dval, 'String'));
getfnval = str2double(get(handles.fnval, 'String'));
cflag  = 0; 

% Get form of controller and generate controller
cform = get(handles.formpop,'Value'); 
switch cform
    case 1 % Parallel form
        Kp = getpval;
        Ki = getival;
        Kd = getdval;
        if getfnval >= 0 % if Tf is a real, finite, and non-negative value.
            Tf = getfnval;
            % generate controller
            C = pid(Kp,Ki,Kd,Tf); 
            cflag  = 1;
        else
            % display error message in msgbox
            set(handles.msgbox, 'String', 'Multivar 1.0: Tf must be a real, finite, and non-negative value.', 'ForegroundColor', [0 0 1])
        end          
    case 2 % Standard form
        Kp = getpval;
        if getival > 0 % if Ti is a real and positive value.
            Ti = getival;
            if getdval >= 0 % if Td is a real, finite, and non-negative value.
                Td = getdval;
                if getfnval > 0 % if N is a real and positive value.
                    N = getfnval;
                    % generate controller
                    C = pidstd(Kp,Ti,Td,N);
                    cflag  = 1;
                else
                    % display error message in msgbox
                    set(handles.msgbox, 'String', 'Multivar 1.0: N must be a real and positive value.', 'ForegroundColor', [0 0 1])                    
                end
            else
                % display error message in msgbox
                set(handles.msgbox, 'String', 'Multivar 1.0: Td must be a real, finite, and non-negative value.', 'ForegroundColor', [0 0 1])                
            end
        else
            % display error message in msgbox
            set(handles.msgbox, 'String', 'Multivar 1.0: Ti must be a real and positive value.', 'ForegroundColor', [0 0 1])            
        end
    otherwise
end

if cflag == 1
    % Get values of loop pop-up
    vloop = get(handles.looppop, 'Value');
    
    % Modify looppid matrix and save as figure application data
    looppid{vloop} = C;
    setappdata(handles.output, 'PIDct', looppid)
    
    % Modify tmatrix matrix and save as figure application data
    strtype = getType(C);
    ctype = find(ismember(type_list,strtype));
    tmatrix(vloop) = ctype;
    setappdata(handles.output, 'tmat', tmatrix)
    
    % Modify fmatrix matrix and save as figure application data
    cform = get(handles.formpop, 'Value');
    fmatrix(vloop) = cform;
    setappdata(handles.output, 'fmat', fmatrix)
    
    % Save controller information and new model
    [a, b] = size(looppid);
    piddarray = tf(zeros(a));
    for k = 1: 1: a
        piddarray(k, k) = looppid{k};
    end
    sys = mstruct.controlmodel;
    t_fpsys = sys * piddarray; % total forward path
    t_fbsys = eye(size(piddarray)); % total unity feedback path  on diagonal
    t_csys = feedback(t_fpsys,t_fbsys);
    t_csys = assin_name(mstruct.controlmodel, t_csys, 'c');
    
    mstruct.controlinfo = {piddarray, fmatrix, sys, t_csys};
    mstruct.controlmodel = t_csys;
    
    % Update window position in structure
    mstruct.windowposition = get(gcf,'OuterPosition');

    % Update root application data
    setappdata(0, 'mlvappdata', mstruct);

    % Activate new GUI window and close the last window
    set(pidcon2, 'Visible', 'On');
    set(handles.output, 'Visible', 'Off');

    % Update handles structure
    guidata(hObject, handles);
end


function pval_Callback(hObject, eventdata, handles)
% hObject    handle to pval (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of pval as text
%        str2double(get(hObject,'String')) returns contents of pval as a double

getpval = str2double(get(handles.pval, 'String')); 
getival = str2double(get(handles.ival, 'String'));
getdval = str2double(get(handles.dval, 'String'));
getfnval = str2double(get(handles.fnval, 'String'));
cflag  = 0; 

cform = get(handles.formpop,'Value'); 
switch cform
    case 1 % Parallel form
        Kp = getpval;
        Ki = getival;
        Kd = getdval;
        if getfnval >= 0 % if Tf is a real, finite, and non-negative value.
            Tf = getfnval;
            % generate controller
            C = pid(Kp,Ki,Kd,Tf); 
            cflag  = 1;
        else
            % display error message in msgbox
            set(handles.msgbox, 'String', 'Multivar 1.0: Tf must be a real, finite, and non-negative value.', 'ForegroundColor', [0 0 1])
        end          
    case 2 % Standard form
        Kp = getpval;
        if getival > 0 % if Ti is a real and positive value.
            Ti = getival;
            if getdval >= 0 % if Td is a real, finite, and non-negative value.
                Td = getdval;
                if getfnval > 0 % if N is a real and positive value.
                    N = getfnval;
                    % generate controller
                    C = pidstd(Kp,Ti,Td,N);
                    cflag  = 1;
                else
                    % display error message in msgbox
                    set(handles.msgbox, 'String', 'Multivar 1.0: N must be a real and positive value.', 'ForegroundColor', [0 0 1])                    
                end
            else
                % display error message in msgbox
                set(handles.msgbox, 'String', 'Multivar 1.0: Td must be a real, finite, and non-negative value.', 'ForegroundColor', [0 0 1])                
            end
        else
            % display error message in msgbox
            set(handles.msgbox, 'String', 'Multivar 1.0: Ti must be a real and positive value.', 'ForegroundColor', [0 0 1])            
        end
    otherwise
end

if cflag == 1
    % Get values from figure/ gui application data
    mstruct = getappdata(handles.output, 'gstruct');
    loop_list = getappdata(handles.output, 'poploop');
    type_list = getappdata(handles.output, 'poptype');
    in_list = getappdata(handles.output, 'popin');
    out_list = getappdata(handles.output, 'popout');    
    
    % Update controller type
    ctype = getType(C);
    tindx = find(ismember(type_list,ctype));
    set(handles.typepop,'Value', tindx)

    % Update display
    sys = mstruct.controlmodel;
    vloop = str2double(loop_list{get(handles.looppop,'Value')});
    iosys  = sys(vloop, vloop);
    
    cdisp = get(handles.disppop,'Value');  % get current display request     
    fpsys = iosys * C; % forward path
    fbsys = 1; % unity feedback path
    csys = feedback(fpsys,fbsys);
    csys = assin_name(iosys, csys, 'c');
    
    switch cdisp
        case 1
            % Display step response of control loop
            subplot(1,1,1); step(csys);
            title('Step Response of Control Loop');
        case 2
            % Display Bode Plot of control loop
            subplot(1,1,1); bode(csys);
            title('Bode Plot of Control Loop');                    
        case 3
            % Display Nyquist Plot of control loop
            subplot(1,1,1); nyquist(csys);
            title('Nyquist Plot of Control Loop');                    
        case 4
            % Display Nichols Plot of control loop
            subplot(1,1,1); nichols(csys);
            title('Nichols Plot of Control Loop');          
        case 5
            % Display Root Locus plot of control loop
            subplot(1,1,1); rlocus(csys);
            title('Root Locus plot of Control Loop');               
        otherwise
    end
end



% --- Executes during object creation, after setting all properties.
function pval_CreateFcn(hObject, eventdata, handles)
% hObject    handle to pval (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function ival_Callback(hObject, eventdata, handles)
% hObject    handle to ival (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of ival as text
%        str2double(get(hObject,'String')) returns contents of ival as a double
     
getpval = str2double(get(handles.pval, 'String')); 
getival = str2double(get(handles.ival, 'String'));
getdval = str2double(get(handles.dval, 'String'));
getfnval = str2double(get(handles.fnval, 'String'));
cflag  = 0; 

cform = get(handles.formpop,'Value'); 
switch cform
    case 1 % Parallel form
        Kp = getpval;
        Ki = getival;
        Kd = getdval;
        if getfnval >= 0 % if Tf is a real, finite, and non-negative value.
            Tf = getfnval;
            % generate controller
            C = pid(Kp,Ki,Kd,Tf); 
            cflag  = 1;
        else
            % display error message in msgbox
            set(handles.msgbox, 'String', 'Multivar 1.0: Tf must be a real, finite, and non-negative value.', 'ForegroundColor', [0 0 1])
        end          
    case 2 % Standard form
        Kp = getpval;
        if getival > 0 % if Ti is a real and positive value.
            Ti = getival;
            if getdval >= 0 % if Td is a real, finite, and non-negative value.
                Td = getdval;
                if getfnval > 0 % if N is a real and positive value.
                    N = getfnval;
                    % generate controller
                    C = pidstd(Kp,Ti,Td,N);
                    cflag  = 1;
                else
                    % display error message in msgbox
                    set(handles.msgbox, 'String', 'Multivar 1.0: N must be a real and positive value.', 'ForegroundColor', [0 0 1])                    
                end
            else
                % display error message in msgbox
                set(handles.msgbox, 'String', 'Multivar 1.0: Td must be a real, finite, and non-negative value.', 'ForegroundColor', [0 0 1])                
            end
        else
            % display error message in msgbox
            set(handles.msgbox, 'String', 'Multivar 1.0: Ti must be a real and positive value.', 'ForegroundColor', [0 0 1])            
        end
    otherwise
end

if cflag == 1
    % Get values from figure/ gui application data
    mstruct = getappdata(handles.output, 'gstruct');
    loop_list = getappdata(handles.output, 'poploop');
    type_list = getappdata(handles.output, 'poptype');
    in_list = getappdata(handles.output, 'popin');
    out_list = getappdata(handles.output, 'popout');    
    
    % Update controller type
    ctype = getType(C);
    tindx = find(ismember(type_list,ctype));
    set(handles.typepop,'Value', tindx)

    % Update display
    sys = mstruct.controlmodel;
    vloop = str2double(loop_list{get(handles.looppop,'Value')});
    iosys  = sys(vloop, vloop);
    
    cdisp = get(handles.disppop,'Value');  % get current display request     
    fpsys = iosys * C; % forward path
    fbsys = 1; % unity feedback path
    csys = feedback(fpsys,fbsys);
    csys = assin_name(iosys, csys, 'c');
    
    switch cdisp
        case 1
            % Display step response of control loop
            subplot(1,1,1); step(csys);
            title('Step Response of Control Loop');
        case 2
            % Display Bode Plot of control loop
            subplot(1,1,1); bode(csys);
            title('Bode Plot of Control Loop');                    
        case 3
            % Display Nyquist Plot of control loop
            subplot(1,1,1); nyquist(csys);
            title('Nyquist Plot of Control Loop');                    
        case 4
            % Display Nichols Plot of control loop
            subplot(1,1,1); nichols(csys);
            title('Nichols Plot of Control Loop');          
        case 5
            % Display Root Locus plot of control loop
            subplot(1,1,1); rlocus(csys);
            title('Root Locus plot of Control Loop');               
        otherwise
    end
end


% --- Executes during object creation, after setting all properties.
function ival_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ival (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function dval_Callback(hObject, eventdata, handles)
% hObject    handle to dval (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of dval as text
%        str2double(get(hObject,'String')) returns contents of dval as a double

getpval = str2double(get(handles.pval, 'String')); 
getival = str2double(get(handles.ival, 'String'));
getdval = str2double(get(handles.dval, 'String'));
getfnval = str2double(get(handles.fnval, 'String'));
cflag  = 0; 

cform = get(handles.formpop,'Value'); 
switch cform
    case 1 % Parallel form
        Kp = getpval;
        Ki = getival;
        Kd = getdval;
        if getfnval >= 0 % if Tf is a real, finite, and non-negative value.
            Tf = getfnval;
            % generate controller
            C = pid(Kp,Ki,Kd,Tf); 
            cflag  = 1;
        else
            % display error message in msgbox
            set(handles.msgbox, 'String', 'Multivar 1.0: Tf must be a real, finite, and non-negative value.', 'ForegroundColor', [0 0 1])
        end          
    case 2 % Standard form
        Kp = getpval;
        if getival > 0 % if Ti is a real and positive value.
            Ti = getival;
            if getdval >= 0 % if Td is a real, finite, and non-negative value.
                Td = getdval;
                if getfnval > 0 % if N is a real and positive value.
                    N = getfnval;
                    % generate controller
                    C = pidstd(Kp,Ti,Td,N);
                    cflag  = 1;
                else
                    % display error message in msgbox
                    set(handles.msgbox, 'String', 'Multivar 1.0: N must be a real and positive value.', 'ForegroundColor', [0 0 1])                    
                end
            else
                % display error message in msgbox
                set(handles.msgbox, 'String', 'Multivar 1.0: Td must be a real, finite, and non-negative value.', 'ForegroundColor', [0 0 1])                
            end
        else
            % display error message in msgbox
            set(handles.msgbox, 'String', 'Multivar 1.0: Ti must be a real and positive value.', 'ForegroundColor', [0 0 1])            
        end
    otherwise
end

if cflag == 1
    % Get values from figure/ gui application data
    mstruct = getappdata(handles.output, 'gstruct');
    loop_list = getappdata(handles.output, 'poploop');
    type_list = getappdata(handles.output, 'poptype');
    in_list = getappdata(handles.output, 'popin');
    out_list = getappdata(handles.output, 'popout');    
    
    % Update controller type
    ctype = getType(C);
    tindx = find(ismember(type_list,ctype));
    set(handles.typepop,'Value', tindx)

    % Update display
    sys = mstruct.controlmodel;
    vloop = str2double(loop_list{get(handles.looppop,'Value')});
    iosys  = sys(vloop, vloop);
    
    cdisp = get(handles.disppop,'Value');  % get current display request     
    fpsys = iosys * C; % forward path
    fbsys = 1; % unity feedback path
    csys = feedback(fpsys,fbsys);
    csys = assin_name(iosys, csys, 'c');
    
    switch cdisp
        case 1
            % Display step response of control loop
            subplot(1,1,1); step(csys);
            title('Step Response of Control Loop');
        case 2
            % Display Bode Plot of control loop
            subplot(1,1,1); bode(csys);
            title('Bode Plot of Control Loop');                    
        case 3
            % Display Nyquist Plot of control loop
            subplot(1,1,1); nyquist(csys);
            title('Nyquist Plot of Control Loop');                    
        case 4
            % Display Nichols Plot of control loop
            subplot(1,1,1); nichols(csys);
            title('Nichols Plot of Control Loop');          
        case 5
            % Display Root Locus plot of control loop
            subplot(1,1,1); rlocus(csys);
            title('Root Locus plot of Control Loop');               
        otherwise
    end
end
    

% --- Executes during object creation, after setting all properties.
function dval_CreateFcn(hObject, eventdata, handles)
% hObject    handle to dval (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function fnval_Callback(hObject, eventdata, handles)
% hObject    handle to fnval (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of fnval as text
%        str2double(get(hObject,'String')) returns contents of fnval as a double

getpval = str2double(get(handles.pval, 'String')); 
getival = str2double(get(handles.ival, 'String'));
getdval = str2double(get(handles.dval, 'String'));
getfnval = str2double(get(handles.fnval, 'String'));
cflag  = 0; 

cform = get(handles.formpop,'Value'); 
switch cform
    case 1 % Parallel form
        Kp = getpval;
        Ki = getival;
        Kd = getdval;
        if getfnval >= 0 % if Tf is a real, finite, and non-negative value.
            Tf = getfnval;
            % generate controller
            C = pid(Kp,Ki,Kd,Tf); 
            cflag  = 1;
        else
            % display error message in msgbox
            set(handles.msgbox, 'String', 'Multivar 1.0: Tf must be a real, finite, and non-negative value.', 'ForegroundColor', [0 0 1])
        end          
    case 2 % Standard form
        Kp = getpval;
        if getival > 0 % if Ti is a real and positive value.
            Ti = getival;
            if getdval >= 0 % if Td is a real, finite, and non-negative value.
                Td = getdval;
                if getfnval > 0 % if N is a real and positive value.
                    N = getfnval;
                    % generate controller
                    C = pidstd(Kp,Ti,Td,N);
                    cflag  = 1;
                else
                    % display error message in msgbox
                    set(handles.msgbox, 'String', 'Multivar 1.0: N must be a real and positive value.', 'ForegroundColor', [0 0 1])                    
                end
            else
                % display error message in msgbox
                set(handles.msgbox, 'String', 'Multivar 1.0: Td must be a real, finite, and non-negative value.', 'ForegroundColor', [0 0 1])                
            end
        else
            % display error message in msgbox
            set(handles.msgbox, 'String', 'Multivar 1.0: Ti must be a real and positive value.', 'ForegroundColor', [0 0 1])            
        end
    otherwise
end

if cflag == 1
    % Get values from figure/ gui application data
    mstruct = getappdata(handles.output, 'gstruct');
    loop_list = getappdata(handles.output, 'poploop');    
    type_list = getappdata(handles.output, 'poptype');
    in_list = getappdata(handles.output, 'popin');
    out_list = getappdata(handles.output, 'popout');    
    
    % Update controller type
    ctype = getType(C);
    tindx = find(ismember(type_list,ctype));
    set(handles.typepop,'Value', tindx)

    % Update display
    sys = mstruct.controlmodel;
    vloop = str2double(loop_list{get(handles.looppop,'Value')});
    iosys  = sys(vloop, vloop);
    
    cdisp = get(handles.disppop,'Value');  % get current display request     
    fpsys = iosys * C; % forward path
    fbsys = 1; % unity feedback path
    csys = feedback(fpsys,fbsys);
    csys = assin_name(iosys, csys, 'c');
    
    switch cdisp
        case 1
            % Display step response of control loop
            subplot(1,1,1); step(csys);
            title('Step Response of Control Loop');
        case 2
            % Display Bode Plot of control loop
            subplot(1,1,1); bode(csys);
            title('Bode Plot of Control Loop');                    
        case 3
            % Display Nyquist Plot of control loop
            subplot(1,1,1); nyquist(csys);
            title('Nyquist Plot of Control Loop');                    
        case 4
            % Display Nichols Plot of control loop
            subplot(1,1,1); nichols(csys);
            title('Nichols Plot of Control Loop');          
        case 5
            % Display Root Locus plot of control loop
            subplot(1,1,1); rlocus(csys);
            title('Root Locus plot of Control Loop');               
        otherwise
    end
end


% --- Executes during object creation, after setting all properties.
function fnval_CreateFcn(hObject, eventdata, handles)
% hObject    handle to fnval (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in disppop.
function disppop_Callback(hObject, eventdata, handles)
% hObject    handle to disppop (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns disppop contents as cell array
%        contents{get(hObject,'Value')} returns selected item from disppop

getpval = str2double(get(handles.pval, 'String')); 
getival = str2double(get(handles.ival, 'String'));
getdval = str2double(get(handles.dval, 'String'));
getfnval = str2double(get(handles.fnval, 'String'));
cflag  = 0; 

cform = get(handles.formpop,'Value'); 
switch cform
    case 1 % Parallel form
        Kp = getpval;
        Ki = getival;
        Kd = getdval;
        if getfnval >= 0 % if Tf is a real, finite, and non-negative value.
            Tf = getfnval;
            % generate controller
            C = pid(Kp,Ki,Kd,Tf); 
            cflag  = 1;
        else
            % display error message in msgbox
            set(handles.msgbox, 'String', 'Multivar 1.0: Tf must be a real, finite, and non-negative value.', 'ForegroundColor', [0 0 1])
        end          
    case 2 % Standard form
        Kp = getpval;
        if getival > 0 % if Ti is a real and positive value.
            Ti = getival;
            if getdval >= 0 % if Td is a real, finite, and non-negative value.
                Td = getdval;
                if getfnval > 0 % if N is a real and positive value.
                    N = getfnval;
                    % generate controller
                    C = pidstd(Kp,Ti,Td,N);
                    cflag  = 1;
                else
                    % display error message in msgbox
                    set(handles.msgbox, 'String', 'Multivar 1.0: N must be a real and positive value.', 'ForegroundColor', [0 0 1])                    
                end
            else
                % display error message in msgbox
                set(handles.msgbox, 'String', 'Multivar 1.0: Td must be a real, finite, and non-negative value.', 'ForegroundColor', [0 0 1])                
            end
        else
            % display error message in msgbox
            set(handles.msgbox, 'String', 'Multivar 1.0: Ti must be a real and positive value.', 'ForegroundColor', [0 0 1])            
        end
    otherwise
end

if cflag == 1
    % Get values from figure/ gui application data
    mstruct = getappdata(handles.output, 'gstruct');
    loop_list = getappdata(handles.output, 'poploop');    
    type_list = getappdata(handles.output, 'poptype');
    in_list = getappdata(handles.output, 'popin');
    out_list = getappdata(handles.output, 'popout');    
    
    % Update controller type
    ctype = getType(C);
    tindx = find(ismember(type_list,ctype));
    set(handles.typepop,'Value', tindx)

    % Update display
    sys = mstruct.controlmodel;
    vloop = str2double(loop_list{get(handles.looppop,'Value')});
    iosys  = sys(vloop, vloop);
    
    cdisp = get(handles.disppop,'Value');  % get current display request     
    fpsys = iosys * C; % forward path
    fbsys = 1; % unity feedback path
    csys = feedback(fpsys,fbsys);
    csys = assin_name(iosys, csys, 'c');
    
    switch cdisp
        case 1
            % Display step response of control loop
            subplot(1,1,1); step(csys);
            title('Step Response of Control Loop');
        case 2
            % Display Bode Plot of control loop
            subplot(1,1,1); bode(csys);
            title('Bode Plot of Control Loop');                    
        case 3
            % Display Nyquist Plot of control loop
            subplot(1,1,1); nyquist(csys);
            title('Nyquist Plot of Control Loop');                    
        case 4
            % Display Nichols Plot of control loop
            subplot(1,1,1); nichols(csys);
            title('Nichols Plot of Control Loop');          
        case 5
            % Display Root Locus plot of control loop
            subplot(1,1,1); rlocus(csys);
            title('Root Locus plot of Control Loop');               
        otherwise
    end
end


% --- Executes during object creation, after setting all properties.
function disppop_CreateFcn(hObject, eventdata, handles)
% hObject    handle to disppop (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit1_Callback(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double


% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in loopprevbutt.
function loopprevbutt_Callback(hObject, eventdata, handles)
% hObject    handle to loopprevbutt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get values from figure/ gui application data
mstruct = getappdata(handles.output, 'gstruct');
type_list = getappdata(handles.output, 'poptype');
in_list = getappdata(handles.output, 'popin');
out_list = getappdata(handles.output, 'popout');

% Save last controller developed
% get form and type matrices
fmatrix = getappdata(handles.output, 'fmat');
tmatrix = getappdata(handles.output, 'tmat');

% Get figure application data
looppid = getappdata(handles.output, 'PIDct');

% Get values of controller parameters
getpval = str2double(get(handles.pval, 'String')); 
getival = str2double(get(handles.ival, 'String'));
getdval = str2double(get(handles.dval, 'String'));
getfnval = str2double(get(handles.fnval, 'String'));
cflag  = 0; 

% Get form of controller and generate controller
cform = get(handles.formpop,'Value'); 
switch cform
    case 1 % Parallel form
        Kp = getpval;
        Ki = getival;
        Kd = getdval;
        if getfnval >= 0 % if Tf is a real, finite, and non-negative value.
            Tf = getfnval;
            % generate controller
            C = pid(Kp,Ki,Kd,Tf); 
            cflag  = 1;
        else
            % display error message in msgbox
            set(handles.msgbox, 'String', 'Multivar 1.0: Tf must be a real, finite, and non-negative value.', 'ForegroundColor', [0 0 1])
        end          
    case 2 % Standard form
        Kp = getpval;
        if getival > 0 % if Ti is a real and positive value.
            Ti = getival;
            if getdval >= 0 % if Td is a real, finite, and non-negative value.
                Td = getdval;
                if getfnval > 0 % if N is a real and positive value.
                    N = getfnval;
                    % generate controller
                    C = pidstd(Kp,Ti,Td,N);
                    cflag  = 1;
                else
                    % display error message in msgbox
                    set(handles.msgbox, 'String', 'Multivar 1.0: N must be a real and positive value.', 'ForegroundColor', [0 0 1])                    
                end
            else
                % display error message in msgbox
                set(handles.msgbox, 'String', 'Multivar 1.0: Td must be a real, finite, and non-negative value.', 'ForegroundColor', [0 0 1])                
            end
        else
            % display error message in msgbox
            set(handles.msgbox, 'String', 'Multivar 1.0: Ti must be a real and positive value.', 'ForegroundColor', [0 0 1])            
        end
    otherwise
end

if cflag == 1
    % Get values of loop pop-up
    vloop = get(handles.looppop, 'Value');
    
    % Modify looppid matrix and save as figure application data
    looppid{vloop} = C;
    setappdata(handles.output, 'PIDct', looppid)
    
    % Modify tmatrix matrix and save as figure application data
    strtype = getType(C);
    ctype = find(ismember(type_list,strtype));
    tmatrix(vloop) = ctype;
    setappdata(handles.output, 'tmat', tmatrix)
    
    % Modify fmatrix matrix and save as figure application data
    cform = get(handles.formpop, 'Value');
    fmatrix(vloop) = cform;
    setappdata(handles.output, 'fmat', fmatrix)

    % Go to new loop
    % to facilitate stepping through the matrix
    [m, n] = size(looppid);

    if vloop ~= 1  % if not at the start      
        vloop = vloop - 1; % decrement
        % Update pop-up menu values
        set(handles.inpop, 'Value', vloop);
        set(handles.outpop, 'Value', vloop);
        set(handles.looppop, 'Value', vloop);
    end

    % If at the beginning of the matrix turn off "PREVIOUS" button
    if vloop == 1
        set(handles.loopprevbutt, 'Enable', 'off')
    else
        set(handles.loopprevbutt, 'Enable', 'on')
    end

    % If at the end of the matrix turn off "NEXT" button
    if vloop == m
        set(handles.loopnextbutt, 'Enable', 'off')
    else
        set(handles.loopnextbutt, 'Enable', 'on')
    end

    % Display plot   
    sys = mstruct.controlmodel;
    iosys  = sys(vloop, vloop);
    
    % Get controller
    C = looppid{vloop};
    
    % Display controller type
    ctype = tmatrix(vloop);
    set(handles.typepop,'Value', ctype);
    
    % Display controller form
    cform = fmatrix(vloop);    
    set(handles.formpop,'Value', cform)
    
    % Display controller parameters based on controller form
    switch cform
        case 1 % parallel
            % Obtain parameters for parallel pid form
            [Kp,Ki,Kd,Tf] = piddata(C);        
            % set value Kp
            set(handles.pval, 'String', num2str(Kp))
            % set value Ki
            set(handles.ival, 'String', num2str(Ki))
            % set value Kd
            set(handles.dval, 'String', num2str(Kd))
            % set value Tf
            set(handles.fnval, 'String', num2str(Tf))          
        case 2 % standard
            % Obtain parameters for standard pid form        
            [Kp,Ti,Td,N]= pidstddata(C);     
            % set value Kp
            set(handles.pval, 'String', num2str(Kp))       
            % set value Ti
            set(handles.ival, 'String', num2str(Ti))       
            % set value Td
            set(handles.dval, 'String', num2str(Td))       
            % set value N
            set(handles.fnval, 'String', num2str(N))     
        otherwise
    end
  
    fpsys = iosys * C; % forward path
    fbsys = 1; % unity feedback path
    csys = feedback(fpsys,fbsys);
    csys = assin_name(iosys, csys, 'c');

    cdisp = get(handles.disppop,'Value');  % get current display request 
    switch cdisp
        case 1
            % Display step response of control loop
            subplot(1,1,1); step(csys);
            title('Step Response of Control Loop');
        case 2
            % Display Bode Plot of control loop
            subplot(1,1,1); bode(csys);
            title('Bode Plot of Control Loop');                    
        case 3
            % Display Nyquist Plot of control loop
            subplot(1,1,1); nyquist(csys);
            title('Nyquist Plot of Control Loop');                    
        case 4
            % Display Nichols Plot of control loop
            subplot(1,1,1); nichols(csys);
            title('Nichols Plot of Control Loop');          
        case 5
            % Display Root Locus plot of control loop
            subplot(1,1,1); rlocus(csys);
            title('Root Locus plot of Control Loop');               
        otherwise
    end
end


% Update handles structure
guidata(hObject, handles);


% --- Executes on button press in loopnextbutt.
function loopnextbutt_Callback(hObject, eventdata, handles)
% hObject    handle to loopnextbutt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get values from figure/ gui application data
mstruct = getappdata(handles.output, 'gstruct');
type_list = getappdata(handles.output, 'poptype');
in_list = getappdata(handles.output, 'popin');
out_list = getappdata(handles.output, 'popout');

% Save last controller developed
% get form and type matrices
fmatrix = getappdata(handles.output, 'fmat');
tmatrix = getappdata(handles.output, 'tmat');

% Get figure application data
looppid = getappdata(handles.output, 'PIDct');

% Get values of controller parameters
getpval = str2double(get(handles.pval, 'String')); 
getival = str2double(get(handles.ival, 'String'));
getdval = str2double(get(handles.dval, 'String'));
getfnval = str2double(get(handles.fnval, 'String'));
cflag  = 0; 

% Get form of controller and generate controller
cform = get(handles.formpop,'Value'); 
switch cform
    case 1 % Parallel form
        Kp = getpval;
        Ki = getival;
        Kd = getdval;
        if getfnval >= 0 % if Tf is a real, finite, and non-negative value.
            Tf = getfnval;
            % generate controller
            C = pid(Kp,Ki,Kd,Tf); 
            cflag  = 1;
        else
            % display error message in msgbox
            set(handles.msgbox, 'String', 'Multivar 1.0: Tf must be a real, finite, and non-negative value.', 'ForegroundColor', [0 0 1])
        end          
    case 2 % Standard form
        Kp = getpval;
        if getival > 0 % if Ti is a real and positive value.
            Ti = getival;
            if getdval >= 0 % if Td is a real, finite, and non-negative value.
                Td = getdval;
                if getfnval > 0 % if N is a real and positive value.
                    N = getfnval;
                    % generate controller
                    C = pidstd(Kp,Ti,Td,N);
                    cflag  = 1;
                else
                    % display error message in msgbox
                    set(handles.msgbox, 'String', 'Multivar 1.0: N must be a real and positive value.', 'ForegroundColor', [0 0 1])                    
                end
            else
                % display error message in msgbox
                set(handles.msgbox, 'String', 'Multivar 1.0: Td must be a real, finite, and non-negative value.', 'ForegroundColor', [0 0 1])                
            end
        else
            % display error message in msgbox
            set(handles.msgbox, 'String', 'Multivar 1.0: Ti must be a real and positive value.', 'ForegroundColor', [0 0 1])            
        end
    otherwise
end

if cflag == 1
    % Get values of loop pop-up
    vloop = get(handles.looppop, 'Value');
    
    % Modify looppid matrix and save as figure application data
    looppid{vloop} = C;
    setappdata(handles.output, 'PIDct', looppid)
    
    % Modify tmatrix matrix and save as figure application data
    strtype = getType(C);
    ctype = find(ismember(type_list,strtype));
    tmatrix(vloop) = ctype;
    setappdata(handles.output, 'tmat', tmatrix)
    
    % Modify fmatrix matrix and save as figure application data
    cform = get(handles.formpop, 'Value');
    fmatrix(vloop) = cform;
    setappdata(handles.output, 'fmat', fmatrix)
    
    % Go to new loop
    % to facilitate stepping through the matrix
    [m, n] = size(looppid);

    if vloop ~= m  % if not at the end of the loops       
        vloop = vloop + 1; % increment
        % Update pop-up menu values
        set(handles.inpop, 'Value', vloop);
        set(handles.outpop, 'Value', vloop);
        set(handles.looppop, 'Value', vloop);
    end

    % If at the beginning of the matrix turn off "PREVIOUS" button
    if vloop == 1
        set(handles.loopprevbutt, 'Enable', 'off')
    else
        set(handles.loopprevbutt, 'Enable', 'on')
    end

    % If at the end of the matrix turn off "NEXT" button
    if vloop == m
        set(handles.loopnextbutt, 'Enable', 'off')
    else
        set(handles.loopnextbutt, 'Enable', 'on')
    end

    % Display plot   
    sys = mstruct.controlmodel;
    iosys  = sys(vloop, vloop);
    
    % Get controller
    C = looppid{vloop};
    
    % Display controller type
    ctype = tmatrix(vloop);
    set(handles.typepop,'Value', ctype)
    
    % Display controller form
    cform = fmatrix(vloop);    
    set(handles.formpop,'Value', cform)
    
    % Display controller parameters based on controller form
    switch cform
        case 1 % parallel
            % Obtain parameters for parallel pid form
            [Kp,Ki,Kd,Tf] = piddata(C);        
            % set value Kp
            set(handles.pval, 'String', num2str(Kp))
            % set value Ki
            set(handles.ival, 'String', num2str(Ki))
            % set value Kd
            set(handles.dval, 'String', num2str(Kd))
            % set value Tf
            set(handles.fnval, 'String', num2str(Tf))          
        case 2 % standard
            % Obtain parameters for standard pid form        
            [Kp,Ti,Td,N]= pidstddata(C);     
            % set value Kp
            set(handles.pval, 'String', num2str(Kp))       
            % set value Ti
            set(handles.ival, 'String', num2str(Ti))       
            % set value Td
            set(handles.dval, 'String', num2str(Td))       
            % set value N
            set(handles.fnval, 'String', num2str(N))     
        otherwise
    end
  
    fpsys = iosys * C; % forward path
    fbsys = 1; % unity feedback path
    csys = feedback(fpsys,fbsys);
    csys = assin_name(iosys, csys, 'c');
    
    cdisp = get(handles.disppop,'Value');  % get current display request 
    switch cdisp
        case 1
            % Display step response of control loop
            subplot(1,1,1); step(csys);
            title('Step Response of Control Loop');
        case 2
            % Display Bode Plot of control loop
            subplot(1,1,1); bode(csys);
            title('Bode Plot of Control Loop');                    
        case 3
            % Display Nyquist Plot of control loop
            subplot(1,1,1); nyquist(csys);
            title('Nyquist Plot of Control Loop');                    
        case 4
            % Display Nichols Plot of control loop
            subplot(1,1,1); nichols(csys);
            title('Nichols Plot of Control Loop');          
        case 5
            % Display Root Locus plot of control loop
            subplot(1,1,1); rlocus(csys);
            title('Root Locus plot of Control Loop');               
        otherwise
    end
end


% Update handles structure
guidata(hObject, handles);


% --- Executes on selection change in typepop.
function typepop_Callback(hObject, eventdata, handles)
% hObject    handle to typepop (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns typepop contents as cell array
%        contents{get(hObject,'Value')} returns selected item from typepop

% Get values from figure/ gui application data
mstruct = getappdata(handles.output, 'gstruct');
loop_list = getappdata(handles.output, 'poploop');
in_list = getappdata(handles.output, 'popin');
out_list = getappdata(handles.output, 'popout');
type_list = getappdata(handles.output, 'poptype');

% generate tuned controller for the control loop
ctype = get(handles.typepop,'Value');
sys = mstruct.controlmodel;
vloop = str2double(loop_list{get(handles.looppop,'Value')});
iosys  = sys(vloop, vloop);

if hasInternalDelay(iosys) == 1
    % Determine number of unstable poles
    rpole = real(pole(iosys));        
    nup = sum(rpole>0);
    opt = pidtuneOptions('NumUnstablePoles',nup);
    % Tune controller
   C = pidtune(iosys,type_list{ctype}, opt);
else
    % Tune controller
    C = pidtune(iosys,type_list{ctype});
end


% Determine form selected
cform = get(handles.formpop,'Value');
switch cform % Make changes based on selection
    case 1 % parallel
        % Obtain parameters for parallel pid form
        [Kp,Ki,Kd,Tf] = piddata(C);        
        % set value Kp
        set(handles.pval, 'String', num2str(Kp))
        % set value Ki
        set(handles.ival, 'String', num2str(Ki))
        % set value Kd
        set(handles.dval, 'String', num2str(Kd))
        % set value Tf
        set(handles.fnval, 'String', num2str(Tf))          
    case 2 % standard
        % Obtain parameters for standard pid form        
        [Kp,Ti,Td,N]= pidstddata(C);     
        % set value Kp
        set(handles.pval, 'String', num2str(Kp))       
        % set value Ti
        set(handles.ival, 'String', num2str(Ti))       
        % set value Td
        set(handles.dval, 'String', num2str(Td))       
        % set value N
        set(handles.fnval, 'String', num2str(N))     
    otherwise
end

% Update display
cdisp = get(handles.disppop,'Value');  % get current display request     
fpsys = iosys * C; % forward path
fbsys = 1; % unity feedback path
csys = feedback(fpsys,fbsys);
csys = assin_name(iosys, csys, 'c');

switch cdisp
    case 1
        % Display step response of control loop
        subplot(1,1,1); step(csys);
        title('Step Response of Control Loop');
    case 2
        % Display Bode Plot of control loop
        subplot(1,1,1); bode(csys);
        title('Bode Plot of Control Loop');                    
    case 3
        % Display Nyquist Plot of control loop
        subplot(1,1,1); nyquist(csys);
        title('Nyquist Plot of Control Loop');                    
    case 4
        % Display Nichols Plot of control loop
        subplot(1,1,1); nichols(csys);
        title('Nichols Plot of Control Loop');          
    case 5
        % Display Root Locus plot of control loop
        subplot(1,1,1); rlocus(csys);
        title('Root Locus plot of Control Loop');               
    otherwise
end
    



% --- Executes during object creation, after setting all properties.
function typepop_CreateFcn(hObject, eventdata, handles)
% hObject    handle to typepop (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in formpop.
function formpop_Callback(hObject, eventdata, handles)
% hObject    handle to formpop (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns formpop contents as cell array
%        contents{get(hObject,'Value')} returns selected item from formpop

% Get values from figure/ gui application data
mstruct = getappdata(handles.output, 'gstruct');
loop_list = getappdata(handles.output, 'poploop');
in_list = getappdata(handles.output, 'popin');
out_list = getappdata(handles.output, 'popout');
type_list = getappdata(handles.output, 'poptype');

% generate tuned controller for the control loop
ctype = get(handles.typepop,'Value');
sys = mstruct.controlmodel;
vloop = str2double(loop_list{get(handles.looppop,'Value')});
iosys  = sys(vloop, vloop);

if hasInternalDelay(iosys) == 1
    % Determine number of unstable poles
    rpole = real(pole(iosys));        
    nup = sum(rpole>0);
    opt = pidtuneOptions('NumUnstablePoles',nup);
    % Tune controller
   C = pidtune(iosys,type_list{ctype}, opt);
else
    % Tune controller
    C = pidtune(iosys,type_list{ctype});
end

% Determine form selected
cform = get(handles.formpop,'Value');
% Make changes based on selection
switch cform
    case 1 % parallel
        % Change text strings to labels for the form
        set(handles.ptext, 'String', 'Kp:')
        set(handles.itext, 'String', 'Ki:')
        set(handles.dtext, 'String', 'Kd:')
        set(handles.fntext, 'String', 'Tf:')
        
        % Obtain parameters for parallel pid form
        [Kp,Ki,Kd,Tf] = piddata(C);        
        % set value Kp
        set(handles.pval, 'String', num2str(Kp))
        % set value Ki
        set(handles.ival, 'String', num2str(Ki))
        % set value Kd
        set(handles.dval, 'String', num2str(Kd))
        % set value Tf
        set(handles.fnval, 'String', num2str(Tf))          
    case 2 % standard
        % Change text strings to labels for the form
        set(handles.ptext, 'String', 'Kp:')
        set(handles.itext, 'String', 'Ti:')
        set(handles.dtext, 'String', 'Td:')
        set(handles.fntext, 'String', 'N:')
        
        % Obtain parameters for standard pid form        
        [Kp,Ti,Td,N]= pidstddata(C);     
        % set value Kp
        set(handles.pval, 'String', num2str(Kp))       
        % set value Ti
        set(handles.ival, 'String', num2str(Ti))       
        % set value Td
        set(handles.dval, 'String', num2str(Td))       
        % set value N
        set(handles.fnval, 'String', num2str(N))     
    otherwise
end

% Update display
cdisp = get(handles.disppop,'Value');  % get current display request     
fpsys = iosys * C; % forward path
fbsys = 1; % unity feedback path
csys = feedback(fpsys,fbsys);
csys = assin_name(iosys, csys, 'c');

switch cdisp
    case 1
        % Display step response of control loop
        subplot(1,1,1); step(csys);
        title('Step Response of Control Loop');
    case 2
        % Display Bode Plot of control loop
        subplot(1,1,1); bode(csys);
        title('Bode Plot of Control Loop');                    
    case 3
        % Display Nyquist Plot of control loop
        subplot(1,1,1); nyquist(csys);
        title('Nyquist Plot of Control Loop');                    
    case 4
        % Display Nichols Plot of control loop
        subplot(1,1,1); nichols(csys);
        title('Nichols Plot of Control Loop');          
    case 5
        % Display Root Locus plot of control loop
        subplot(1,1,1); rlocus(csys);
        title('Root Locus plot of Control Loop');               
    otherwise
end

% --- Executes during object creation, after setting all properties.
function formpop_CreateFcn(hObject, eventdata, handles)
% hObject    handle to formpop (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in inpop.
function inpop_Callback(hObject, eventdata, handles)
% hObject    handle to inpop (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns inpop contents as cell array
%        contents{get(hObject,'Value')} returns selected item from inpop

% Get values from figure/ gui application data
mstruct = getappdata(handles.output, 'gstruct');
type_list = getappdata(handles.output, 'poptype');
in_list = getappdata(handles.output, 'popin');
out_list = getappdata(handles.output, 'popout');

% Save last controller developed
% get form and type matrices
fmatrix = getappdata(handles.output, 'fmat');
tmatrix = getappdata(handles.output, 'tmat');

% Get figure application data
looppid = getappdata(handles.output, 'PIDct');

% Get values of controller parameters
getpval = str2double(get(handles.pval, 'String')); 
getival = str2double(get(handles.ival, 'String'));
getdval = str2double(get(handles.dval, 'String'));
getfnval = str2double(get(handles.fnval, 'String'));
cflag  = 0; 

% Get form of controller and generate controller
cform = get(handles.formpop,'Value'); 
switch cform
    case 1 % Parallel form
        Kp = getpval;
        Ki = getival;
        Kd = getdval;
        if getfnval >= 0 % if Tf is a real, finite, and non-negative value.
            Tf = getfnval;
            % generate controller
            C = pid(Kp,Ki,Kd,Tf); 
            cflag  = 1;
        else
            % display error message in msgbox
            set(handles.msgbox, 'String', 'Multivar 1.0: Tf must be a real, finite, and non-negative value.', 'ForegroundColor', [0 0 1])
        end          
    case 2 % Standard form
        Kp = getpval;
        if getival > 0 % if Ti is a real and positive value.
            Ti = getival;
            if getdval >= 0 % if Td is a real, finite, and non-negative value.
                Td = getdval;
                if getfnval > 0 % if N is a real and positive value.
                    N = getfnval;
                    % generate controller
                    C = pidstd(Kp,Ti,Td,N);
                    cflag  = 1;
                else
                    % display error message in msgbox
                    set(handles.msgbox, 'String', 'Multivar 1.0: N must be a real and positive value.', 'ForegroundColor', [0 0 1])                    
                end
            else
                % display error message in msgbox
                set(handles.msgbox, 'String', 'Multivar 1.0: Td must be a real, finite, and non-negative value.', 'ForegroundColor', [0 0 1])                
            end
        else
            % display error message in msgbox
            set(handles.msgbox, 'String', 'Multivar 1.0: Ti must be a real and positive value.', 'ForegroundColor', [0 0 1])            
        end
    otherwise
end

if cflag == 1
    % Get value of prev loop number from an unchanged popup
    vloop = get(handles.looppop, 'Value');
    
    % Modify looppid matrix and save as figure application data
    looppid{vloop} = C;
    setappdata(handles.output, 'PIDct', looppid)
    
    % Modify tmatrix matrix and save as figure application data
    strtype = getType(C);
    ctype = find(ismember(type_list,strtype));
    tmatrix(vloop) = ctype;
    setappdata(handles.output, 'tmat', tmatrix)
    
    % Modify fmatrix matrix and save as figure application data
    cform = get(handles.formpop, 'Value');
    fmatrix(vloop) = cform;
    setappdata(handles.output, 'fmat', fmatrix)

    % Go to new loop
    % to facilitate stepping through the matrix
    [m, n] = size(looppid);
    
    % Get value of new loop number corresponding to input popup and update
    % display
    vloop = get(handles.inpop, 'Value');
  
    % Update pop-up menu values
    set(handles.inpop, 'Value', vloop);
    set(handles.outpop, 'Value', vloop);
    set(handles.looppop, 'Value', vloop);


    % If at the beginning of the matrix turn off "PREVIOUS" button
    if vloop == 1
        set(handles.loopprevbutt, 'Enable', 'off')
    else
        set(handles.loopprevbutt, 'Enable', 'on')
    end

    % If at the end of the matrix turn off "NEXT" button
    if vloop == m
        set(handles.loopnextbutt, 'Enable', 'off')
    else
        set(handles.loopnextbutt, 'Enable', 'on')
    end

    % Display plot   
    sys = mstruct.controlmodel;
    iosys  = sys(vloop, vloop);
    
    % Get controller
    C = looppid{vloop};
    
    % Display controller type
    ctype = tmatrix(vloop);
    set(handles.typepop,'Value', ctype)
    
    % Display controller form
    cform = fmatrix(vloop);    
    set(handles.formpop,'Value', cform)
    
    % Display controller parameters based on controller form
    switch cform
        case 1 % parallel
            % Obtain parameters for parallel pid form
            [Kp,Ki,Kd,Tf] = piddata(C);        
            % set value Kp
            set(handles.pval, 'String', num2str(Kp))
            % set value Ki
            set(handles.ival, 'String', num2str(Ki))
            % set value Kd
            set(handles.dval, 'String', num2str(Kd))
            % set value Tf
            set(handles.fnval, 'String', num2str(Tf))          
        case 2 % standard
            % Obtain parameters for standard pid form        
            [Kp,Ti,Td,N]= pidstddata(C);     
            % set value Kp
            set(handles.pval, 'String', num2str(Kp))       
            % set value Ti
            set(handles.ival, 'String', num2str(Ti))       
            % set value Td
            set(handles.dval, 'String', num2str(Td))       
            % set value N
            set(handles.fnval, 'String', num2str(N))     
        otherwise
    end
  
    fpsys = iosys * C; % forward path
    fbsys = 1; % unity feedback path
    csys = feedback(fpsys,fbsys);
    csys = assin_name(iosys, csys, 'c');    
   
    cdisp = get(handles.disppop,'Value');  % get current display request 
    switch cdisp
        case 1
            % Display step response of control loop
            subplot(1,1,1); step(csys);
            title('Step Response of Control Loop');
        case 2
            % Display Bode Plot of control loop
            subplot(1,1,1); bode(csys);
            title('Bode Plot of Control Loop');                    
        case 3
            % Display Nyquist Plot of control loop
            subplot(1,1,1); nyquist(csys);
            title('Nyquist Plot of Control Loop');                    
        case 4
            % Display Nichols Plot of control loop
            subplot(1,1,1); nichols(csys);
            title('Nichols Plot of Control Loop');          
        case 5
            % Display Root Locus plot of control loop
            subplot(1,1,1); rlocus(csys);
            title('Root Locus plot of Control Loop');               
        otherwise
    end
end


% --- Executes during object creation, after setting all properties.
function inpop_CreateFcn(hObject, eventdata, handles)
% hObject    handle to inpop (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in outpop.
function outpop_Callback(hObject, eventdata, handles)
% hObject    handle to outpop (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns outpop contents as cell array
%        contents{get(hObject,'Value')} returns selected item from outpop

% Get values from figure/ gui application data
mstruct = getappdata(handles.output, 'gstruct');
type_list = getappdata(handles.output, 'poptype');
in_list = getappdata(handles.output, 'popin');
out_list = getappdata(handles.output, 'popout');

% Save last controller developed
% get form and type matrices
fmatrix = getappdata(handles.output, 'fmat');
tmatrix = getappdata(handles.output, 'tmat');

% Get figure application data
looppid = getappdata(handles.output, 'PIDct');

% Get values of controller parameters
getpval = str2double(get(handles.pval, 'String')); 
getival = str2double(get(handles.ival, 'String'));
getdval = str2double(get(handles.dval, 'String'));
getfnval = str2double(get(handles.fnval, 'String'));
cflag  = 0; 

% Get form of controller and generate controller
cform = get(handles.formpop,'Value'); 
switch cform
    case 1 % Parallel form
        Kp = getpval;
        Ki = getival;
        Kd = getdval;
        if getfnval >= 0 % if Tf is a real, finite, and non-negative value.
            Tf = getfnval;
            % generate controller
            C = pid(Kp,Ki,Kd,Tf); 
            cflag  = 1;
        else
            % display error message in msgbox
            set(handles.msgbox, 'String', 'Multivar 1.0: Tf must be a real, finite, and non-negative value.', 'ForegroundColor', [0 0 1])
        end          
    case 2 % Standard form
        Kp = getpval;
        if getival > 0 % if Ti is a real and positive value.
            Ti = getival;
            if getdval >= 0 % if Td is a real, finite, and non-negative value.
                Td = getdval;
                if getfnval > 0 % if N is a real and positive value.
                    N = getfnval;
                    % generate controller
                    C = pidstd(Kp,Ti,Td,N);
                    cflag  = 1;
                else
                    % display error message in msgbox
                    set(handles.msgbox, 'String', 'Multivar 1.0: N must be a real and positive value.', 'ForegroundColor', [0 0 1])                    
                end
            else
                % display error message in msgbox
                set(handles.msgbox, 'String', 'Multivar 1.0: Td must be a real, finite, and non-negative value.', 'ForegroundColor', [0 0 1])                
            end
        else
            % display error message in msgbox
            set(handles.msgbox, 'String', 'Multivar 1.0: Ti must be a real and positive value.', 'ForegroundColor', [0 0 1])            
        end
    otherwise
end

if cflag == 1
    % Get value of prev loop number from an unchanged popup
    vloop = get(handles.looppop, 'Value');
    
    % Modify looppid matrix and save as figure application data
    looppid{vloop} = C;
    setappdata(handles.output, 'PIDct', looppid)
    
    % Modify tmatrix matrix and save as figure application data
    strtype = getType(C);
    ctype = find(ismember(type_list,strtype));
    tmatrix(vloop) = ctype;
    setappdata(handles.output, 'tmat', tmatrix)
    
    % Modify fmatrix matrix and save as figure application data
    cform = get(handles.formpop, 'Value');
    fmatrix(vloop) = cform;
    setappdata(handles.output, 'fmat', fmatrix)
    
    % Go to new loop
    % to facilitate stepping through the matrix
    [m, n] = size(looppid);
    
    % Get value of new loop number from output popup
    vloop = get(handles.outpop, 'Value');

    % Update pop-up menu values
    set(handles.inpop, 'Value', vloop);
    set(handles.outpop, 'Value', vloop);
    set(handles.looppop, 'Value', vloop);


    % If at the beginning of the matrix turn off "PREVIOUS" button
    if vloop == 1
        set(handles.loopprevbutt, 'Enable', 'off')
    else
        set(handles.loopprevbutt, 'Enable', 'on')
    end

    % If at the end of the matrix turn off "NEXT" button
    if vloop == m
        set(handles.loopnextbutt, 'Enable', 'off')
    else
        set(handles.loopnextbutt, 'Enable', 'on')
    end

    % Display plot   
    sys = mstruct.controlmodel;
    iosys  = sys(vloop, vloop);
    
    % Get controller
    C = looppid{vloop};
    
    % Display controller type
    ctype = tmatrix(vloop);
    set(handles.typepop,'Value', ctype)
    
    % Display controller form
    cform = fmatrix(vloop);    
    set(handles.formpop,'Value', cform)
    
    % Display controller parameters based on controller form
    switch cform
        case 1 % parallel
            % Obtain parameters for parallel pid form
            [Kp,Ki,Kd,Tf] = piddata(C);        
            % set value Kp
            set(handles.pval, 'String', num2str(Kp))
            % set value Ki
            set(handles.ival, 'String', num2str(Ki))
            % set value Kd
            set(handles.dval, 'String', num2str(Kd))
            % set value Tf
            set(handles.fnval, 'String', num2str(Tf))          
        case 2 % standard
            % Obtain parameters for standard pid form        
            [Kp,Ti,Td,N]= pidstddata(C);     
            % set value Kp
            set(handles.pval, 'String', num2str(Kp))       
            % set value Ti
            set(handles.ival, 'String', num2str(Ti))       
            % set value Td
            set(handles.dval, 'String', num2str(Td))       
            % set value N
            set(handles.fnval, 'String', num2str(N))     
        otherwise
    end
  
    fpsys = iosys * C; % forward path
    fbsys = 1; % unity feedback path
    csys = feedback(fpsys,fbsys);
    csys = assin_name(iosys, csys, 'c');    
   
    cdisp = get(handles.disppop,'Value');  % get current display request 
    switch cdisp
        case 1
            % Display step response of control loop
            subplot(1,1,1); step(csys);
            title('Step Response of Control Loop');
        case 2
            % Display Bode Plot of control loop
            subplot(1,1,1); bode(csys);
            title('Bode Plot of Control Loop');                    
        case 3
            % Display Nyquist Plot of control loop
            subplot(1,1,1); nyquist(csys);
            title('Nyquist Plot of Control Loop');                    
        case 4
            % Display Nichols Plot of control loop
            subplot(1,1,1); nichols(csys);
            title('Nichols Plot of Control Loop');          
        case 5
            % Display Root Locus plot of control loop
            subplot(1,1,1); rlocus(csys);
            title('Root Locus plot of Control Loop');               
        otherwise
    end
end


% --- Executes during object creation, after setting all properties.
function outpop_CreateFcn(hObject, eventdata, handles)
% hObject    handle to outpop (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in looppop.
function looppop_Callback(hObject, eventdata, handles)
% hObject    handle to looppop (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns looppop contents as cell array
%        contents{get(hObject,'Value')} returns selected item from looppop

% Get values from figure/ gui application data
mstruct = getappdata(handles.output, 'gstruct');
type_list = getappdata(handles.output, 'poptype');
in_list = getappdata(handles.output, 'popin');
out_list = getappdata(handles.output, 'popout');

% Save last controller developed
% get form and type matrices
fmatrix = getappdata(handles.output, 'fmat');
tmatrix = getappdata(handles.output, 'tmat');

% Get figure application data
looppid = getappdata(handles.output, 'PIDct');

% Get values of controller parameters
getpval = str2double(get(handles.pval, 'String')); 
getival = str2double(get(handles.ival, 'String'));
getdval = str2double(get(handles.dval, 'String'));
getfnval = str2double(get(handles.fnval, 'String'));
cflag  = 0; 

% Get form of controller and generate controller
cform = get(handles.formpop,'Value'); 
switch cform
    case 1 % Parallel form
        Kp = getpval;
        Ki = getival;
        Kd = getdval;
        if getfnval >= 0 % if Tf is a real, finite, and non-negative value.
            Tf = getfnval;
            % generate controller
            C = pid(Kp,Ki,Kd,Tf); 
            cflag  = 1;
        else
            % display error message in msgbox
            set(handles.msgbox, 'String', 'Multivar 1.0: Tf must be a real, finite, and non-negative value.', 'ForegroundColor', [0 0 1])
        end          
    case 2 % Standard form
        Kp = getpval;
        if getival > 0 % if Ti is a real and positive value.
            Ti = getival;
            if getdval >= 0 % if Td is a real, finite, and non-negative value.
                Td = getdval;
                if getfnval > 0 % if N is a real and positive value.
                    N = getfnval;
                    % generate controller
                    C = pidstd(Kp,Ti,Td,N);
                    cflag  = 1;
                else
                    % display error message in msgbox
                    set(handles.msgbox, 'String', 'Multivar 1.0: N must be a real and positive value.', 'ForegroundColor', [0 0 1])                    
                end
            else
                % display error message in msgbox
                set(handles.msgbox, 'String', 'Multivar 1.0: Td must be a real, finite, and non-negative value.', 'ForegroundColor', [0 0 1])                
            end
        else
            % display error message in msgbox
            set(handles.msgbox, 'String', 'Multivar 1.0: Ti must be a real and positive value.', 'ForegroundColor', [0 0 1])            
        end
    otherwise
end

if cflag == 1
    % Get value of prev loop number from an unchanged popup
    vloop = get(handles.inpop, 'Value');
    
    % Modify looppid matrix and save as figure application data
    looppid{vloop} = C;
    setappdata(handles.output, 'PIDct', looppid)
    
    % Modify tmatrix matrix and save as figure application data
    strtype = getType(C);
    ctype = find(ismember(type_list,strtype));
    tmatrix(vloop) = ctype;
    setappdata(handles.output, 'tmat', tmatrix)
    
    % Modify fmatrix matrix and save as figure application data
    cform = get(handles.formpop, 'Value');
    fmatrix(vloop) = cform;
    setappdata(handles.output, 'fmat', fmatrix)

    % Go to new loop
    % to facilitate stepping through the matrix
    [m, n] = size(looppid);
    
    % Get value of new loop number from loop popup
    vloop = get(handles.looppop, 'Value');

    % Update pop-up menu values
    set(handles.inpop, 'Value', vloop);
    set(handles.outpop, 'Value', vloop);
    set(handles.looppop, 'Value', vloop);

    % If at the beginning of the matrix turn off "PREVIOUS" button
    if vloop == 1
        set(handles.loopprevbutt, 'Enable', 'off')
    else
        set(handles.loopprevbutt, 'Enable', 'on')
    end

    % If at the end of the matrix turn off "NEXT" button
    if vloop == m
        set(handles.loopnextbutt, 'Enable', 'off')
    else
        set(handles.loopnextbutt, 'Enable', 'on')
    end

    % Display plot   
    sys = mstruct.controlmodel;
    iosys  = sys(vloop, vloop);
    
    % Get controller
    C = looppid{vloop};
    
    % Display controller type
    ctype = tmatrix(vloop);
    set(handles.typepop,'Value', ctype)
    
    % Display controller form
    cform = fmatrix(vloop);    
    set(handles.formpop,'Value', cform)
    
    % Display controller parameters based on controller form
    switch cform
        case 1 % parallel
            % Obtain parameters for parallel pid form
            [Kp,Ki,Kd,Tf] = piddata(C);        
            % set value Kp
            set(handles.pval, 'String', num2str(Kp))
            % set value Ki
            set(handles.ival, 'String', num2str(Ki))
            % set value Kd
            set(handles.dval, 'String', num2str(Kd))
            % set value Tf
            set(handles.fnval, 'String', num2str(Tf))          
        case 2 % standard
            % Obtain parameters for standard pid form        
            [Kp,Ti,Td,N]= pidstddata(C);     
            % set value Kp
            set(handles.pval, 'String', num2str(Kp))       
            % set value Ti
            set(handles.ival, 'String', num2str(Ti))       
            % set value Td
            set(handles.dval, 'String', num2str(Td))       
            % set value N
            set(handles.fnval, 'String', num2str(N))     
        otherwise
    end
  
    fpsys = iosys * C; % forward path
    fbsys = 1; % unity feedback path
    csys = feedback(fpsys,fbsys);
    csys = assin_name(iosys, csys, 'c');    
   
    cdisp = get(handles.disppop,'Value');  % get current display request 
    switch cdisp
        case 1
            % Display step response of control loop
            subplot(1,1,1); step(csys);
            title('Step Response of Control Loop');
        case 2
            % Display Bode Plot of control loop
            subplot(1,1,1); bode(csys);
            title('Bode Plot of Control Loop');                    
        case 3
            % Display Nyquist Plot of control loop
            subplot(1,1,1); nyquist(csys);
            title('Nyquist Plot of Control Loop');                    
        case 4
            % Display Nichols Plot of control loop
            subplot(1,1,1); nichols(csys);
            title('Nichols Plot of Control Loop');          
        case 5
            % Display Root Locus plot of control loop
            subplot(1,1,1); rlocus(csys);
            title('Root Locus plot of Control Loop');               
        otherwise
    end
end


% Update handles structure
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function looppop_CreateFcn(hObject, eventdata, handles)
% hObject    handle to looppop (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function msgbox_Callback(hObject, eventdata, handles)
% hObject    handle to msgbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of msgbox as text
%        str2double(get(hObject,'String')) returns contents of msgbox as a double


% --- Executes during object creation, after setting all properties.
function msgbox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to msgbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in tunebutt.
function tunebutt_Callback(hObject, eventdata, handles)
% hObject    handle to tunebutt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get values from figure/ gui application data
mstruct = getappdata(handles.output, 'gstruct');
loop_list = getappdata(handles.output, 'poploop');
in_list = getappdata(handles.output, 'popin');
out_list = getappdata(handles.output, 'popout');
type_list = getappdata(handles.output, 'poptype');

% generate tuned controller for the control loop
ctype = get(handles.typepop,'Value');
sys = mstruct.controlmodel;
vloop = str2double(loop_list{get(handles.looppop,'Value')});
iosys  = sys(vloop, vloop);

if hasInternalDelay(iosys) == 1
    % Determine number of unstable poles
    rpole = real(pole(iosys));        
    nup = sum(rpole>0);
    opt = pidtuneOptions('NumUnstablePoles',nup);
    % Tune controller
   C = pidtune(iosys,type_list{ctype}, opt);
else
    % Tune controller
    C = pidtune(iosys,type_list{ctype});
end

% Determine form selected
cform = get(handles.formpop,'Value');
% Make changes based on selection
switch cform
    case 1 % parallel
        % Obtain parameters for parallel pid form
        [Kp,Ki,Kd,Tf] = piddata(C);        
        % set value Kp
        set(handles.pval, 'String', num2str(Kp))
        % set value Ki
        set(handles.ival, 'String', num2str(Ki))
        % set value Kd
        set(handles.dval, 'String', num2str(Kd))
        % set value Tf
        set(handles.fnval, 'String', num2str(Tf))          
    case 2 % standard
        % Obtain parameters for standard pid form        
        [Kp,Ti,Td,N]= pidstddata(C);     
        % set value Kp
        set(handles.pval, 'String', num2str(Kp))       
        % set value Ti
        set(handles.ival, 'String', num2str(Ti))       
        % set value Td
        set(handles.dval, 'String', num2str(Td))       
        % set value N
        set(handles.fnval, 'String', num2str(N))     
    otherwise
end

% Update display
cdisp = get(handles.disppop,'Value');  % get current display request     
fpsys = iosys * C; % forward path
fbsys = 1; % unity feedback path
csys = feedback(fpsys,fbsys);
csys = assin_name(iosys, csys, 'c');

switch cdisp
    case 1
        % Display step response of control loop
        subplot(1,1,1); step(csys);
        title('Step Response of Control Loop');
    case 2
        % Display Bode Plot of control loop
        subplot(1,1,1); bode(csys);
        title('Bode Plot of Control Loop');                    
    case 3
        % Display Nyquist Plot of control loop
        subplot(1,1,1); nyquist(csys);
        title('Nyquist Plot of Control Loop');                    
    case 4
        % Display Nichols Plot of control loop
        subplot(1,1,1); nichols(csys);
        title('Nichols Plot of Control Loop');          
    case 5
        % Display Root Locus plot of control loop
        subplot(1,1,1); rlocus(csys);
        title('Root Locus plot of Control Loop');               
    otherwise
end




