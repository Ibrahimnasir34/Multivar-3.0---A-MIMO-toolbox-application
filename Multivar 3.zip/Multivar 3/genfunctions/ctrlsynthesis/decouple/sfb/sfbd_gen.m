function dsys = sfbd_gen(sys, F, G)
% SFBD_GENN  Applies State Feedback Decoupling to the system and returns 
% the entire system.
%
% SYNTAX
% dsys = sfbd_gen(sys, F, G) applied the F and G matrices used in State 
% Feedback Decoupling and returns the transfer function of the entire system.
%

% *************************************************************************
% Author:           Crystal Blackwell 
% Email:            Crystal.Blackwell@sta.uwi.edu
% Created:          January 2013; 
% Last revision:    29-June-2013;
% Useful websites:
%
% MATLAB VERSIONS USED IN PROGRAMMING PROCESS: 
% - MATLAB R2013a
%
% *************************************************************************
% NATIVE MATLAB FUNCTIONS USED TO CREATE THIS FUNCTION:
% dcgain            svd                 size                minreal 
% inv               error               ss                  isa
% *************************************************************************

    % to check if the system is square
    % check if F and G are the right dimensions and numerical
    
    modnum = modtyptest(sys);
    
    if (modnum == 2) || (modnum == 4) || (modnum == 4) 
        switch modnum
            case 2
                % Convert to state space
                sys = ss(sys);
            case 4
                % Do nothing
            case 6
                % Convert to state space
                sys = ss(sys);
        end
        sys = iosnames(sys);   
    
        % Evaluating the decoupled system
        Ahat = sys.a + (sys.b * F);
        Bhat = sys.b * G;
        Chat = sys.c + (sys.d * F);
        Dhat = sys.d * G;
        dsys = ss(Ahat, Bhat, Chat, Dhat);

        % Determining variable names from original system
        inname = sys.InputName;
        outname = sys.OutputName;
        if isa(sys,'ss')
            statname = sys.StateName;
        end
        % determining dimensions of decoupled system
        [md, nd] = size(dsys);
        if isa(sys,'ss')
            [a1,a2] = size(dsys.a);
            if a1 == a2
                sd = a1;
            else
                return
            end
        end

        % determining names for decoupled system
        inname = inname(1: nd); 
        outname = outname(1: md);
        if isa(sys,'ss')
            statname = statname(1:sd);
        end

        % Assigning variable names to decoupled system
        % Inputs
        for g = 1: 1: length(inname)
            inname{g} = [inname{g}, '_d'];
        end      
        dsys.InputName = inname;

        % Outputs
        dsys.OutputName = outname;

        % States
        if isa(sys,'ss')
            dsys.StateName = statname;
        end 
    else
        error('Multivar 1.0: System must not contain time delays.')
    end
end