function varargout = cbproject(varargin)
% CBPROJECT MATLAB code for cbproject.fig
%      CBPROJECT, by itself, creates a new CBPROJECT or raises the existing
%      singleton*.
%
%      H = CBPROJECT returns the handle to a new CBPROJECT or the handle to
%      the existing singleton*.
%
%      CBPROJECT('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in CBPROJECT.M with the given input arguments.
%
%      CBPROJECT('Property','Value',...) creates a new CBPROJECT or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before cbproject_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to cbproject_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help cbproject

% Last Modified by GUIDE v2.5 13-Oct-2017 04:03:48

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @cbproject_OpeningFcn, ...
                   'gui_OutputFcn',  @cbproject_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before cbproject is made visible.
function cbproject_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to cbproject (see VARARGIN)

% Choose default command line output for cbproject
handles.output = hObject;

% Get root application data
mstruct = getappdata(0, 'mlvappdata');

% Set position and size and title
set(handles.output, 'OuterPosition',mstruct.windowposition, 'Name', mstruct.gtitle);

% Set handle of previous page as gui/figure application data
setappdata(handles.output,'hprevpage',mstruct.phandlerecord(length(mstruct.phandlerecord)));

% Update the page handle record in the structure and then save structure as root application data
mstruct.phandlerecord = [mstruct.phandlerecord, handles.output];
setappdata(0, 'mlvappdata', mstruct)

% set struct from root application data as gui/figure application data
setappdata(handles.output, 'gstruct', mstruct);

% Set Defaults
% set default paths
mlvfolder = mstruct.mlvlocation;
spath = '\Projectfolders';
deffol = strcat(mlvfolder, spath);
set(handles.newloc,'String', deffol);
set(handles.savmod, 'String', [deffol,'\Case Studies\CS1.mat'])

% Set Tag of selected object.
set(handles.poptions,'SelectedObject', handles.cnproj); 

% Get handles of all the objects inside of pannew
newobj = get(handles.pannew, 'Children');

% Get handles of all the objects inside of pansav
savobj = get(handles.pansav, 'Children');

% enable objects in first panel
set(newobj, 'Enable', 'on')
% set settings of objects inside first panel
set(handles.nfolcheck, 'Value', 0);
set(handles.newfol, 'Enable', 'off')
set(handles.text6, 'Enable', 'off')

% disable objects in second panel
set(savobj, 'Enable', 'off')

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes cbproject wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = cbproject_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



% --- Executes on button press in nextbutt.
function nextbutt_Callback(hObject, eventdata, handles)
% hObject    handle to nextbutt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of nextbutt

% get struct from gui page application data
mstruct = getappdata(handles.output, 'gstruct');

% Clear error message
emessage = '';
set(handles.msgbox,'String',emessage, 'ForegroundColor', [1 0 0]) 

% Get data from textboxes depending on which radiobutton is selected
selbutt = get(handles.poptions,'SelectedObject');
switch selbutt
    case handles.cnproj %CREATE NEW PROJECT
        nlocation = get(handles.newloc,'String');
        nfolder = get(handles.newfol,'String');
        nmodel = get(handles.newmod,'String');
                
        if(exist(nlocation, 'dir')) % if directory /path exists 
            if isempty(nmodel) % if no model name is entered
                % display error message
                emessage = 'Multivar: Enter model name';
                set(handles.msgbox,'String',emessage, 'ForegroundColor', [1 0 0])
            else
                if (isempty(nfolder) && get(handles.nfolcheck, 'Value') == 1) % if no folder name is entered and the new folder checkbox was ticked
                     % display error message
                    emessage = 'Multivar: Enter the name of the Project folder';
                    set(handles.msgbox,'String',emessage, 'ForegroundColor', [1 0 0])  
                else
                    if (get(handles.nfolcheck, 'Value') == 1)  % if the new folder checkbox was ticked                          
                        fdirectory = [nlocation, '\',nfolder]; % get folder path
                        filename = [nmodel, '.mat']; % get file name
                        fpath = [fdirectory,'\', filename]; % generate file path
                        if(exist(fdirectory, 'dir')) % if folder already exists
                            % display error message
                            emessage = 'Multivar: Project folder already exists.'; 
                            set(handles.msgbox,'String',emessage, 'ForegroundColor', [1 0 0]) 
                        else
                            if(exist(fpath, 'file')) % if .MAT file exists
                                % display error message
                                emessage = 'Multivar: .MAT file already exists';
                                set(handles.msgbox,'String',emessage, 'ForegroundColor', [1 0 0]) 
                            else
                                % Display loading message in message box
                                emessage = 'Loading...';
                                set(handles.msgbox,'String',emessage, 'ForegroundColor', [0 0 1])

                                % create new project folder and add to
                                % search path
                                mkdir(fdirectory);
                                addpath(fdirectory);

                                % Save paths to structure
                                mstruct.projectpath = fdirectory;
                                mstruct.matfile = filename;
                                mstruct.savemodelpath = fpath;

                                % Get position of the current GUI window and save as application window for
                                % the next GUI window.
                                mstruct.windowposition = get(gcf,'OuterPosition');

                                % Update root application data
                                setappdata(0, 'mlvappdata', mstruct);

                                % Clear error message box
                                emessage = '';
                                set(handles.msgbox,'String',emessage, 'ForegroundColor', [0 0 1])

                                % Activate new GUI window and close the last window
                                set(modeltype, 'Visible', 'On');
                                set(handles.output, 'Visible', 'Off');
                            end
                        end                            
                    else
                        fdirectory = nlocation;
                        filename = [nmodel, '.mat']; % get file name
                        fpath = [fdirectory,'\', filename]; % generate file path
                        % check if .MAT file already exists and if so
                        % display error message
                        if(exist(fpath, 'file'))
                            emessage = 'Multivar: .MAT file already exists';
                            set(handles.msgbox,'String',emessage, 'ForegroundColor', [1 0 0]) 
                        else
                            % Display loading message in message box
                            emessage = 'Loading...';
                            set(handles.msgbox,'String',emessage, 'ForegroundColor', [0 0 1])

                            % Save path to structure
                            mstruct.projectpath = fdirectory;
                            mstruct.matfile = filename;
                            mstruct.savemodelpath = fpath;

                            % Get position of the current GUI window and save as application window for
                            % the next GUI window.
                            mstruct.windowposition = get(gcf,'OuterPosition');

                            % Update root application data
                            setappdata(0, 'mlvappdata', mstruct);

                            % Clear error message box
                            emessage = '';
                            set(handles.msgbox,'String',emessage, 'ForegroundColor', [0 0 1])

                            % Activate new GUI window and close the last window
                            set(modeltype, 'Visible', 'On');
                            set(handles.output, 'Visible', 'Off');
                        end                            
                    end                   
                end
            end
        else
            emessage = 'Multivar: Select folder location';
            set(handles.msgbox,'String',emessage, 'ForegroundColor', [1 0 0])
        end    
    case handles.bfsproj % BROWSE FOR SAVED PROJECT  
        % Get file path
        slfmpath = get(handles.savmod,'String');
        
        % verify that file path exists
        if(exist(slfmpath, 'file'))            
           
            % Import system data from file
            impfiledata = importdata(slfmpath);
            
            % determine model representation from system data
            modnum = modtyptest(impfiledata);
            
            % if model is a valid input representation execute...
            if modnum == 1 || modnum == 2 || modnum == 4 || modnum == 5 || modnum == 6
                
                % Display loading message in message box
                emessage = 'Loading...';
                set(handles.msgbox,'String',emessage, 'ForegroundColor', [0 0 1])
                
                % Save data imported from file and to structure
                impfiledata = iosnames(impfiledata); % assign names to un-named variables
                mstruct.systemmodel = impfiledata;
                
                % Save path to structure
                [fdirectory, name_noext, ext] = fileparts(slfmpath); % splits file path into the directory, name and ext
                mstruct.projectpath = fdirectory; % directory
                mstruct.matfile = [name_noext, ext]; % file name
                mstruct.savemodelpath = slfmpath; % file path
                mstruct.modnum = modnum; % saves number that identifies class of system model

                % Get position of the current GUI window and save to struct for
                % next GUI window.
                mstruct.windowposition = get(gcf,'OuterPosition');

                % Update root application data
                setappdata(0, 'mlvappdata', mstruct);
                
                % Clear error message box
                emessage = '';
                set(handles.msgbox,'String',emessage, 'ForegroundColor', [0 0 1])

                % Activate new GUI window based on model type and close the last window
                switch modnum
                    case 1 % tf with delays
                        set(tfdisplay, 'Visible', 'On');
                        set(handles.output, 'Visible', 'Off');
                    case 2 % tf without delays
                        set(tfdisplay, 'Visible', 'On');
                        set(handles.output, 'Visible', 'Off');
                    case 4 % ss without delays
                        set(ssdisplay, 'Visible', 'On');
                        set(handles.output, 'Visible', 'Off');
                    case 5 % zpk with delays
                        set(zpkdisplay, 'Visible', 'On');
                        set(handles.output, 'Visible', 'Off');
                    case 6 % zpk without delays
                        set(zpkdisplay, 'Visible', 'On');
                        set(handles.output, 'Visible', 'Off');
                end           
            else
                % if model representation is not a valid input, display
                % error message
                emessage = 'Multivar: Input models must be of type ss without time delays, or tf or zpk with or without time delays';
                set(handles.msgbox,'String',emessage, 'ForegroundColor', [1 0 0])                 
            end
        else
            % if file path does not exist, display error message
            emessage = 'Multivar: File or file path does not exist';
            set(handles.msgbox,'String',emessage, 'ForegroundColor', [1 0 0]) 
        end
        
    otherwise
end
% Update handles structure
guidata(hObject, handles);


function savmod_Callback(hObject, eventdata, handles)
% hObject    handle to savmod (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of savmod as text
%        str2double(get(hObject,'String')) returns contents of savmod as a double


% --- Executes during object creation, after setting all properties.
function savmod_CreateFcn(hObject, eventdata, handles)
% hObject    handle to savmod (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function newloc_Callback(hObject, eventdata, handles)
% hObject    handle to newloc (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of newloc as text
%        str2double(get(hObject,'String')) returns contents of newloc as a double


% --- Executes during object creation, after setting all properties.
function newloc_CreateFcn(hObject, eventdata, handles)
% hObject    handle to newloc (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function newfol_Callback(hObject, eventdata, handles)
% hObject    handle to newfol (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of newfol as text
%        str2double(get(hObject,'String')) returns contents of newfol as a double


% --- Executes during object creation, after setting all properties.
function newfol_CreateFcn(hObject, eventdata, handles)
% hObject    handle to newfol (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function newmod_Callback(hObject, eventdata, handles)
% hObject    handle to newmod (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of newmod as text
%        str2double(get(hObject,'String')) returns contents of newmod as a double


% --- Executes during object creation, after setting all properties.
function newmod_CreateFcn(hObject, eventdata, handles)
% hObject    handle to newmod (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes when selected object is changed in poptions.
function poptions_SelectionChangeFcn(hObject, eventdata, handles)
% hObject    handle to the selected object in poptions 
% eventdata  structure with the following fields (see UIBUTTONGROUP)
%	EventName: string 'SelectionChanged' (read only)
%	OldValue: handle of the previously selected object or empty if none was selected
%	NewValue: handle of the currently selected object
% handles    structure with handles and user data (see GUIDATA)

% Get handles of all the objects inside of pannew
newobj = get(handles.pannew, 'Children');

% Get handles of all the objects inside of pansav
savobj = get(handles.pansav, 'Children');

% Get Tag of selected object.
bselected = get(handles.poptions,'SelectedObject'); 
switch bselected
    %Code for when the various togglebuttons are selected
    case handles.cnproj
        % enable objects in first panel     
        set(newobj, 'Enable', 'on')
        % set settings in first panel
        if (get(handles.nfolcheck, 'Value') == 1)
            set(handles.newfol, 'Enable', 'on')
            set(handles.text6, 'Enable', 'on')
        else
            set(handles.newfol, 'Enable', 'off')
            set(handles.text6, 'Enable', 'off')
        end
        % disable objects in second panel
        set(savobj, 'Enable', 'off')
    case handles.bfsproj  
        % enable objects in second panel
        set(savobj, 'Enable', 'on')
        % disable objects in first panel  
        set(newobj, 'Enable', 'off')
end


% --- Executes during object creation, after setting all properties.
function brownew_CreateFcn(hObject, eventdata, handles)
% hObject    handle to brownew (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes on button press in brownew.
function brownew_Callback(hObject, eventdata, handles)
% hObject    handle to brownew (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Clear error message
emessage = '';
set(handles.msgbox,'String',emessage, 'ForegroundColor', [1 0 0]) 

% Get last location and open dialog box for retrieving folders
foldloc = get(handles.newloc, 'String');
get_dir = uigetdir(foldloc);

% Display selection if vaid
if get_dir ~= 0
    set(handles.newloc,'String', get_dir );
end


% --- Executes on button press in browsav.
function browsav_Callback(hObject, eventdata, handles)
% hObject    handle to browsav (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Clear error message
emessage = '';
set(handles.msgbox,'String',emessage, 'ForegroundColor', [1 0 0]) 

% Get last location and open dialog box for retrieving files
fileloc = get(handles.savmod, 'String');
[FileName,PathName] = uigetfile('*.mat','Select the MATLAB binary format (.mat) file', fileloc);

% Display selection if valid
if FileName ~= 0 
    if PathName ~= 0
        set(handles.savmod, 'String', [PathName,FileName])
    end
end

% --- Executes during object creation, after setting all properties.
function browsav_CreateFcn(hObject, eventdata, handles)
% hObject    handle to browsav (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes on button press in nfolcheck.
function nfolcheck_Callback(hObject, eventdata, handles)
% hObject    handle to nfolcheck (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of nfolcheck
if (get(handles.nfolcheck, 'Value') == 1)
    set(handles.newfol, 'Enable', 'on')
    set(handles.text6, 'Enable', 'on')
else
    set(handles.newfol, 'Enable', 'off')
    set(handles.text6, 'Enable', 'off')
end


% --- Executes when user attempts to close figure1.
function figure1_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: delete(hObject) closes the figure

% display a question dialog box 
selection = questdlg('Are you sure you want to close Multivar?','Close Request Function','Yes','No','Yes'); 

switch selection, 
    case 'Yes'     
        % delete all figures related to multivar
          mstruct = getappdata(handles.output,'gstruct');  
          delete(mstruct.phandlerecord) 
          exit_multivar
    case 'No'
       % Do nothing
end



function msgbox_Callback(hObject, eventdata, handles)
% hObject    handle to msgbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of msgbox as text
%        str2double(get(hObject,'String')) returns contents of msgbox as a double


% --- Executes during object creation, after setting all properties.
function msgbox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to msgbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
