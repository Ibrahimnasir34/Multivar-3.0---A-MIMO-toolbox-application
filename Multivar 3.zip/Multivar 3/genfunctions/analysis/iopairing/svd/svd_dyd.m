function [G,U,S,V,CN,Wm,Sel] = svd_dyd(sys, w)
% SVD_DYD  returns the maximum value of a numeric array and its index. 
% 
% SYNTAX
% [G,U,S,V,CN,Wm,Sel] = svd_dyd(sys, w)returns the steady state gain matrix
% G, SVD decomposition matrices U and V, the condition number CN, the matrix 
% containing the max values of the U and V matrices Wm and the Selection
% matrix Sel.
%
% See also SVD_IOP.

% *************************************************************************
% Author:           Crystal Blackwell 
% Email:            Crystal.Blackwell@sta.uwi.edu
% Created:          January 2013; 
% Last revision:    29-June-2013;
% Useful websites:
%
% MATLAB VERSIONS USED IN PROGRAMMING PROCESS: 
% - MATLAB R2013a
%
% *************************************************************************
% NATIVE MATLAB FUNCTIONS USED TO CREATE THIS FUNCTION:
% evalfr                    cond                        svd
% zeros                     size                        rank
% max                       abs                         sum
% length
% *************************************************************************

    % Evaluate gain at a particular frequency
    G = evalfr(sys,w); 
    
    [U,S,V] = svd(G); 
    CN = cond(S); 
    
    % prealocating matrix size
    Sel = zeros(size(G));
    Wm = zeros(size(G));
    
    q = rank(G);
    for k = 1: q
        % Determine W (product of Uk and Vk')
        W = U(:, k)* V(:, k)';
        Wa = abs(W);
        % Determine maximum elements of all Wk
        Wm = max(Wm, Wa);
    end 
    
    Wc = Wm;
    while any(any(Wc))
        % Determine maximum element
        [M, rI, cI] = maxarray(Wc); 
        
        % Initialise minimum value and index
        Amin = sum(Wc(rI(1),:))+ sum(Wc(:,cI(1)));
        Indx(1) = rI(1);
        Indx(2) = cI(1);
                
        % For multiple max values
        for n = 1: length(rI)
            % Add the values in the same row and column of Wc as the 
            % particular M value
            A = sum(Wc(rI(n),:))+ sum(Wc(:,cI(n)));
            % Retain index that is in the loop with smaller numbers
            if A < Amin 
                Indx(1) = rI(n);
                Indx(2) = cI(n);
                Amin = A;
            end                
        end
            
        
        % Set position in the selection matrix to 1
        Sel(Indx(1), Indx(2)) = 1;
        
        % Set element in same row and value as max element to 0
        Wc(Indx(1),:) = 0;
        Wc(:, Indx(2)) = 0;
    end
end