function [M, C]= m_matrix(A)
% M_MATRIX generates the M matrix for use in creating the OCF and CCF of a 
% state space system and a vector of coefficients of the characteristic 
% polymomial of A sorted in descending order.
% 
% SYNTAX
% [M, C]= m_matrix(A)generates the M matrix for use in creating the OCF and
% CCF and  C, a vector of coefficients of the characteristic polymomial of
% A sorted in descending order.

% *************************************************************************
% Author:           Crystal Blackwell 
% Email:            Crystal.Blackwell@sta.uwi.edu
% Created:          January 2013; 
% Last revision:    29-June-2013;
% Useful websites:
%
% MATLAB VERSIONS USED IN PROGRAMMING PROCESS: 
% - MATLAB R2013a
%
% *************************************************************************
% NATIVE MATLAB FUNCTIONS USED TO CREATE THIS FUNCTION:
% length                    zeros                       size                  
% *************************************************************************


    % Check that A is a square matrix of dimension greater than 1x1
    [a,b] = size(A);
    if a == b
        if a > 1 
            % Extract Coefficients of characteristic equation
            C = coefpol(A); % descending order
            % Note: the coefpol function can be replaced by poly and then
            % later charpoly in later versions of matlab
            C = C /C(length(C));
            trfcol = C;
            trfcol(1) =[]; % transpose of first column of M matrix

            % Create M matrix
            dimen = length(C) -1;
            M = zeros(dimen, dimen);

            for k = 1:1: dimen
                if k == 1
                    cdata = trfcol;        
                else
                    pad = k -1;
                    cdata = [trfcol(1 + pad:dimen),zeros(1,pad)];
                end
                colmn = cdata';
                M(:,k) = colmn;
            end
        else
            error('Multivar 1.0: "A" matrix must be of dimension greater than 1x1.')
        end
    else
        error('Multivar 1.0: "A" matrix must be a square matrix.')
    end
end
