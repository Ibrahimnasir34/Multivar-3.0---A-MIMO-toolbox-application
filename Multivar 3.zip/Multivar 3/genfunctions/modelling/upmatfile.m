function upmatfile(slfmpath)
% UPMATFILE  Updates an older version of a MATLAB file to a version 
% compatible with the currently running version of MATLAB. Running an older
% version of a mat file slows down the execution process so this function 
% updates the mat file to facilitate faster processing.
% 
% SYNTAX
% (a)   upmatfile (with no arguments) opens a standard dialog box for retrieving .mat file and 
%       then updates the .mat file. 
% (b)   upmatfile(slfmpath) updates the mat file found at the file path slfmpath.
%       slmpath must the entire file path (i.e. path string, file name
%       and extension).
% 
% See also FILEPARTS, SAVE, IMPORTDATA, UIGETFILE.

% *************************************************************************
% Author:           Crystal Blackwell 
% Email:            Crystal.Blackwell@sta.uwi.edu
% Created:          January 2013; 
% Last revision:    29-June-2013;
% Useful websites:
%
% MATLAB VERSIONS USED IN PROGRAMMING PROCESS: 
% - MATLAB R2013a
%
% *************************************************************************
% NATIVE MATLAB FUNCTIONS USED TO CREATE THIS FUNCTION:
% exist                     fileparts                      strcmp
% importdata                eval                           save
% disp                      error                          nargin
% nargout                   narginchk                      nargoutchk
% uigetfile
% *************************************************************************
    % Check for correct number of output arguments
    if nargout == 0
        % Check for correct number of input arguments
        if nargin ==1 || nargin == 0
            if nargin == 0
                [FileName,PathName] = uigetfile('*.mat','Select the .mat file');
                slfmpath = [PathName, FileName];
            end
            
            if(exist(slfmpath, 'file')) % Check if file exists

                % Separate file path into parts
                [pathstr, Name_noext, ext] = fileparts(slfmpath);

                if strcmp(ext, '.mat') == 1 % check if file is a .mat file

                    % Import system data from file
                    impfiledata = importdata(slfmpath);

                    % Save file and display message
                    eval([Name_noext, '= impfiledata;']);
                    save(slfmpath, Name_noext);        
                    disp(['Multivar 1.0: "', Name_noext, ext, '" has been updated to the version of matfile most compatible with this version of MATLAB.'])
                else
                    % Display error message
                    error('Multivar 1.0: File must have a .mat extension.')   
                end
            else
                % Display error message
                error('Multivar 1.0: File path does not exist.')
            end
        else
            % Display error if incorrect number of inputs
            narginchk(0, 1)
        end
    else
        % Display error if incorrect number of outputs
        nargoutchk(0, 0)
    end
end