function varargout = fr_rga_gui(varargin)
% FR_RGA_GUI M-file for fr_rga_gui.fig
%      FR_RGA_GUI, by itself, creates a new FR_RGA_GUI or raises the existing
%      singleton*.
%
%      H = FR_RGA_GUI returns the handle to a new FR_RGA_GUI or the handle to
%      the existing singleton*.
%
%      FR_RGA_GUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in FR_RGA_GUI.M with the given input arguments.
%
%      FR_RGA_GUI('Property','Value',...) creates a new FR_RGA_GUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before fr_rga_gui_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to fr_rga_gui_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help fr_rga_gui

% Last Modified by GUIDE v2.5 13-Nov-2013 02:27:07

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @fr_rga_gui_OpeningFcn, ...
                   'gui_OutputFcn',  @fr_rga_gui_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before fr_rga_gui is made visible.
function fr_rga_gui_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to fr_rga_gui (see VARARGIN)

% Choose default command line output for fr_rga_gui
handles.output = hObject;

% Get root application data
mstruct = getappdata(0, 'mlvappdata');

% Set position and size and title
set(handles.output, 'OuterPosition',mstruct.windowposition, 'Name', mstruct.gtitle);

% Set handle of previous page as gui/figure application data
setappdata(handles.output,'hprevpage',mstruct.phandlerecord(length(mstruct.phandlerecord)));

% Update the page handle record in the structure and then save structure as root application data
mstruct.phandlerecord = [mstruct.phandlerecord, handles.output];
setappdata(0, 'mlvappdata', mstruct)

% set struct from root application data as gui/figure application data
setappdata(handles.output, 'gstruct', mstruct);

% Setting defaults
switch mstruct.modnum
    case 1
        % tf with delays
        sys = mstruct.systemmodel;
    case 2
        % tf without delays
        sys = mstruct.systemmodel;
    case 4
        % ss without delays
        sys = mstruct.approxmodel;
    case 5
        % zpk with delays
        sys = mstruct.systemmodel;
    case 6
        % zpk without delays
        sys = mstruct.systemmodel;
end
% set appropriate model form as gui/figure application data depending on
% classification of system
setappdata(handles.output, 'formmod', sys);

% Setting values of model display
sys_text = evalc('sys');
syslines = strsplit(sys_text,'\n');
set(handles.moddisplay,'FontName', 'Monospaced', 'String',syslines);

%Display number of inputs and outputs
[m, r] = size(sys);
sm = num2str(m);
sr = num2str(r);
set(handles.noout,'String',sm);
set(handles.noin,'String',sr);


% Displaying steady state values
% Performing RGA
w = 0;
sw = num2str(w);
set(handles.frvalue,'String',sw);
set(handles.frslider,'Value',w);

% Determining gain array
G = evalfr(sys, w);
set(handles.gamatrix,'Data',G, 'BackgroundColor',[0.5 1 1]  ,'ColumnEditable', false);

emessage = 'Multivar 1.0: ';
eflag = 0;

%Perform RGA
try    
    [G,R,S, MCN] = mlv_rga(sys, w);
    sMCN = num2str(MCN);
    set(handles.mcnvalue,'String',sMCN);
    set(handles.rgamatrix,'Data',R, 'BackgroundColor',[0.5 1 0.5],'ColumnEditable', false);
    set(handles.ioselmatrix,'Data',S, 'BackgroundColor',[1 1 0.5]  ,'ColumnEditable', false);
catch err1
    set(handles.rgamatrix,'Data',[]);
    set(handles.ioselmatrix,'Data',[]);
    eflag  = 1;
    emessage = [emessage , 'Matrices cannot be determined for this particular frequency. ']; 
end

% Determine condition number
try
    [U, S, V] = svd(G);
    CN = cond(S);
    sCN = num2str(CN);
    set(handles.cnvalue,'String',sCN);
catch err2
    CN = NaN;
    sCN = num2str(CN);
    set(handles.cnvalue,'String',sCN); 
    eflag  = 1;
    emessage = [emessage , 'The condition number cannot be determined for this particular frequency. '];
end

if eflag  == 1;
    set(handles.msgbox,'String',emessage, 'ForegroundColor',[1 0 0]);
end

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes fr_rga_gui wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = fr_rga_gui_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes during object creation, after setting all properties.
function cnvalue_CreateFcn(hObject, eventdata, handles)
% hObject    handle to cnvalue (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes when user attempts to close figure1.
function figure1_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: delete(hObject) closes the figure

% display a question dialog box 
selection = questdlg('Are you sure you want to close Multivar?','Close Request Function','Yes','No','Yes'); 

switch selection, 
    case 'Yes'     
        % delete all figures related to multivar
          mstruct = getappdata(handles.output,'gstruct');  
          delete(mstruct.phandlerecord) 
          exit_multivar
    case 'No'
       % Do nothing
end


% --- Executes on button press in goback.
function goback_Callback(hObject, eventdata, handles)
% hObject    handle to goback (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get position struct from gui/figure application data.
mstruct = getappdata(handles.output, 'gstruct');

% Update/modify structure
% Get rid of the handle of the current figure
mstruct.phandlerecord = mstruct.phandlerecord(1: length(mstruct.phandlerecord) - 1);

% Get position of the current GUI window 
mstruct.windowposition = get(gcf,'OuterPosition');

% Update root application data
setappdata(0, 'mlvappdata', mstruct);

% Get handle of previous page from figure appdata
% Activate previous gui window and delete the handle of the current window
set(getappdata(handles.output,'hprevpage'), 'OuterPosition',mstruct.windowposition,'Visible', 'On');
set(handles.output, 'Visible', 'Off');
delete(handles.output)



function moddisplay_Callback(hObject, eventdata, handles)
% hObject    handle to moddisplay (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of moddisplay as text
%        str2double(get(hObject,'String')) returns contents of moddisplay as a double


% --- Executes during object creation, after setting all properties.
function moddisplay_CreateFcn(hObject, eventdata, handles)
% hObject    handle to moddisplay (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on slider movement.
function frslider_Callback(hObject, eventdata, handles)
% hObject    handle to frslider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider

% clear error message box
emessage = '';
set(handles.msgbox,'String',emessage, 'ForegroundColor',[1 0 0]);

% Get transfer function form of model from application data
sys = getappdata(handles.output,'formmod');

w = get(handles.frslider,'Value');
sw = num2str(w);
set(handles.frvalue,'String',sw);

% Determining gain array
G = evalfr(sys, w);
set(handles.gamatrix,'Data',G);

emessage = 'Multivar 1.0: ';
eflag = 0;

%Perform RGA
try    
    [G,R,S, MCN] = mlv_rga(sys, w);
    sMCN = num2str(MCN);
    set(handles.mcnvalue,'String',sMCN)
    set(handles.rgamatrix,'Data',R, 'BackgroundColor',[0.5 1 0.5],'ColumnEditable', false);
    set(handles.ioselmatrix,'Data',S, 'BackgroundColor',[1 1 0.5]  ,'ColumnEditable', false);
catch err1
    set(handles.rgamatrix,'Data',[]);
    set(handles.ioselmatrix,'Data',[]);
    eflag  = 1;
    emessage = [emessage , 'Matrices cannot be determined for this particular frequency. ']; 
end

% Determine condition number
try
    [U, S, V] = svd(G);
    CN = cond(S);
    sCN = num2str(CN);
    set(handles.cnvalue,'String',sCN);
catch err2
    CN = NaN;
    sCN = num2str(CN);
    set(handles.cnvalue,'String',sCN); 
    eflag  = 1;
    emessage = [emessage , 'The condition number cannot be determined for this particular frequency. '];
end

if eflag  == 1;
    set(handles.msgbox,'String',emessage, 'ForegroundColor',[1 0 0]);
end



% --- Executes during object creation, after setting all properties.
function frslider_CreateFcn(hObject, eventdata, handles)
% hObject    handle to frslider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on button press in ssreturn.
function ssreturn_Callback(hObject, eventdata, handles)
% hObject    handle to ssreturn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get transfer function form of model from application data
sys = getappdata(handles.output,'formmod');

% Displaying steady state values
% clear error message box
emessage = '';
set(handles.msgbox,'String',emessage, 'ForegroundColor',[1 0 0]);
    
% Performing RGA
w = 0;
sw = num2str(w);
set(handles.frvalue,'String',sw);
set(handles.frslider,'Value',w);

% Determining gain array
G = evalfr(sys, w);
set(handles.gamatrix,'Data',G);

emessage = 'Multivar 1.0: ';
eflag = 0;

%Perform RGA
try    
    [G,R,S, MCN] = mlv_rga(sys, w); 
    sMCN = num2str(MCN);
    set(handles.mcnvalue,'String',sMCN)    
    set(handles.rgamatrix,'Data',R, 'BackgroundColor',[0.5 1 0.5],'ColumnEditable', false);
    set(handles.ioselmatrix,'Data',S, 'BackgroundColor',[1 1 0.5]  ,'ColumnEditable', false);
catch err1
    set(handles.rgamatrix,'Data',[]);
    set(handles.ioselmatrix,'Data',[]);
    eflag  = 1;
    emessage = [emessage , 'Matrices cannot be determined for this particular frequency. ']; 
end

% Determine condition number
try
    [U, S, V] = svd(G);
    CN = cond(S);
    sCN = num2str(CN);
    set(handles.cnvalue,'String',sCN);
catch err2
    CN = NaN;
    sCN = num2str(CN);
    set(handles.cnvalue,'String',sCN); 
    eflag  = 1;
    emessage = [emessage , 'The condition number cannot be determined for this particular frequency. '];
end

if eflag  == 1;
    set(handles.msgbox,'String',emessage, 'ForegroundColor',[1 0 0]);
end



function frvalue_Callback(hObject, eventdata, handles)
% hObject    handle to frvalue (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of frvalue as text
%        str2double(get(hObject,'String')) returns contents of frvalue as a double

% Get transfer function form of model from application data
sys = getappdata(handles.output,'formmod');

% Displaying steady state values
% Performing RGA

sw = get(handles.frvalue,'String');
w = str2double(sw);
if w >= 0 && w <= 1000000
    % clear error message box
    emessage = '';
    set(handles.msgbox,'String',emessage);
    
    % Set values
    set(handles.frslider,'Value', w);    
    
    % Determining gain array
    G = evalfr(sys, w);
    set(handles.gamatrix,'Data',G);

    emessage = 'Multivar 1.0: ';
    eflag = 0;

    %Perform RGA
    try    
        [G,R,S, MCN] = mlv_rga(sys, w);    
        sMCN = num2str(MCN);
        set(handles.mcnvalue,'String',sMCN)        
        set(handles.rgamatrix,'Data',R, 'BackgroundColor',[0.5 1 0.5],'ColumnEditable', false);
        set(handles.ioselmatrix,'Data',S, 'BackgroundColor',[1 1 0.5]  ,'ColumnEditable', false);
    catch err1
        set(handles.rgamatrix,'Data',[]);
        set(handles.ioselmatrix,'Data',[]);
        eflag  = 1;
        emessage = [emessage , 'Matrices cannot be determined for this particular frequency. ']; 
    end

    % Determine condition number
    try
        [U, S, V] = svd(G);
        CN = cond(S);
        sCN = num2str(CN);
        set(handles.cnvalue,'String',sCN);
    catch err2
        CN = NaN;
        sCN = num2str(CN);
        set(handles.cnvalue,'String',sCN); 
        eflag  = 1;
        emessage = [emessage , 'The condition number cannot be determined for this particular frequency. '];
    end

    if eflag  == 1;
        set(handles.msgbox,'String',emessage, 'ForegroundColor',[1 0 0]);
    end
else
    emessage = 'Multivar 1.0: Frequency value must be between 1 and 100 radians / second.';
    set(handles.msgbox,'String',emessage, 'ForegroundColor',[1 0 0]);
end




function msgbox_Callback(hObject, eventdata, handles)
% hObject    handle to msgbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of msgbox as text
%        str2double(get(hObject,'String')) returns contents of msgbox as a double


% --- Executes during object creation, after setting all properties.
function msgbox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to msgbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in saveiop.
function saveiop_Callback(hObject, eventdata, handles)
% hObject    handle to saveiop (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get current selection matrix
iopdata = get(handles.ioselmatrix, 'Data');
[p, r] = find(iopdata);
mstruct2.iopairing = [p, r];

% Save to gui figure application data
setappdata(0, 'mlvanaldata', mstruct2);

% Display message
set(handles.msgbox, 'String', 'Multivar 1.0: Input-Output Pairing selection saved to application data. Saving of any other Input-Output pairing will overwrite this pairing.', 'ForegroundColor',[0 0 1])
